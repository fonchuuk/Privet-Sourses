package ru.duo.aura.modules;

import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Waypoints extends Module {

    public final Setting.Bool addHere = add(new Setting.Bool("Add here", false));
    public final Setting.Bool clear = add(new Setting.Bool("Clear all", false));
    public final Setting.Bool showDistance = add(new Setting.Bool("Distance", true));
    public final Setting.Bool deathPoint = add(new Setting.Bool("Mark death", true));
    public final Setting.Num maxDistance = add(new Setting.Num("Max distance", 512, 32, 2000, 16));

    public record Point(String name, Vec3d pos) {}

    public final List<Point> points = new ArrayList<>();
    private boolean wasAlive = true;

    public Waypoints() {
        super("Waypoints", "Метки на местности", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    private static Path path() {
        return net.minecraft.client.MinecraftClient.getInstance().runDirectory.toPath()
                .resolve("config").resolve("sunrop-waypoints.txt");
    }

    public void load() {
        try {
            Path f = path();
            if (!Files.exists(f)) return;
            points.clear();
            for (String line : Files.readAllLines(f)) {
                String s = line.trim();
                if (s.isEmpty() || s.startsWith("#")) continue;
                int i = s.indexOf('=');
                int j = s.lastIndexOf('=');
                if (i <= 0 || j <= i) continue;
                try {
                    String name = s.substring(0, i);
                    String[] xyz = s.substring(j + 1).split(",");
                    points.add(new Point(name, new Vec3d(
                            Double.parseDouble(xyz[0].trim()),
                            Double.parseDouble(xyz[1].trim()),
                            Double.parseDouble(xyz[2].trim()))));
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    public void persist() {
        try {
            StringBuilder sb = new StringBuilder("# name=x,y,z\n");
            for (Point p : points) {
                sb.append(p.name().replace('=', ' ')).append('=')
                        .append(p.pos().x).append(',').append(p.pos().y).append(',')
                        .append(p.pos().z).append('\n');
            }
            Files.createDirectories(path().getParent());
            Files.writeString(path(), sb.toString());
        } catch (Exception ignored) {}
    }

    public void addPoint(String name, Vec3d pos) {
        points.add(new Point(name, pos));
        persist();
    }

    public boolean removeByName(String name) {
        boolean ok = points.removeIf(p -> p.name().equalsIgnoreCase(name));
        if (ok) persist();
        return ok;
    }

    @Override
    public void onEnable() {
        load();
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;

        if (addHere.value) {
            addHere.value = false;
            addPoint("Метка " + (points.size() + 1), p.getEntityPos());
            p.sendMessage(Text.literal("§7[Sunrop] §aметка поставлена"), true);
        }
        if (clear.value) {
            clear.value = false;
            points.clear();
            persist();
            p.sendMessage(Text.literal("§7[Sunrop] §cметки стёрты"), true);
        }
        if (deathPoint.value) {
            boolean alive = p.isAlive();
            if (wasAlive && !alive) {
                addPoint("Смерть", p.getEntityPos());
            }
            wasAlive = alive;
        }
    }
}
