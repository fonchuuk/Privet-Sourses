package ru.duo.aura.core;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/** Память изменений мира: кто-то поставил/сломал блок рядом — запоминаем. */
public final class BlockTracker {

    public static final class Change {
        public final BlockPos pos;
        public final boolean placed;
        public final boolean broken;
        public final long time;
        public final String name;

        Change(BlockPos pos, boolean placed, boolean broken, String name) {
            this.pos = pos;
            this.placed = placed;
            this.broken = broken;
            this.time = System.currentTimeMillis();
            this.name = name;
        }
    }

    private static final LinkedHashMap<Long, Change> CHANGES = new LinkedHashMap<>();
    private static final int CAP = 1200;
    private static List<Change> cached = new ArrayList<>();
    private static long cachedAt = 0;

    private BlockTracker() {}

    public static void record(BlockPos pos, BlockState oldS, BlockState newS) {
        if (oldS == newS) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        var m = ModuleManager.baseFinder;
        if (m == null || !m.isEnabled() || !m.track.value) return;
        if (mc.player == null) return;
        double r = Math.max(48, m.range.value);
        if (pos.getSquaredDistance(mc.player.getBlockPos()) > r * r) return;

        boolean placed = oldS.isAir() && !newS.isAir();
        boolean broken = !oldS.isAir() && newS.isAir();
        if (!placed && !broken) return;

        long key = pos.asLong();
        CHANGES.remove(key);
        CHANGES.put(key, new Change(pos, placed, broken, newS.isAir() ? nameOf(oldS) : nameOf(newS)));
        while (CHANGES.size() > CAP) {
            var it = CHANGES.keySet().iterator();
            it.next();
            it.remove();
        }
    }

    private static String nameOf(BlockState s) {
        var id = net.minecraft.registry.Registries.BLOCK.getId(s.getBlock());
        return id == null ? "?" : id.getPath();
    }

    public static List<Change> get() {
        long now = System.currentTimeMillis();
        if (now - cachedAt < 250) return cached;
        cachedAt = now;
        MinecraftClient mc = MinecraftClient.getInstance();
        var m = ModuleManager.baseFinder;
        List<Change> out = new ArrayList<>(CHANGES.values());
        if (m != null) {
            long expire = (long) (m.trackTime.value * 1000);
            double r = Math.max(48, m.range.value);
            out.removeIf(c -> now - c.time > expire
                    || (mc.player != null && c.pos.getSquaredDistance(mc.player.getBlockPos()) > r * r));
        }
        cached = out;
        return out;
    }
}
