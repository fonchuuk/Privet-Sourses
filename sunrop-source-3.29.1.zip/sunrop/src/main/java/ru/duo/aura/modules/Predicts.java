package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class Predicts extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 64, 16, 128, 1));
    public final Setting.Bool others = add(new Setting.Bool("Only others", true));
    public final Setting.Bool line = add(new Setting.Bool("Line", true));
    public final Setting.Bool timer = add(new Setting.Bool("Timer", true));
    public final Setting.Bool names = add(new Setting.Bool("Names", true));

    public Predicts() {
        super("Predicts", "Куда прилетит летящая перка/стрела/трезубец + таймер", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
