package ru.duo.aura.core;

public abstract class Setting {
    public final String name;
    public final ru.duo.aura.gui.Tween anim = new ru.duo.aura.gui.Tween(0f, 16f);

    protected Setting(String name) {
        this.name = name;
    }

    public abstract String serialize();

    public abstract void deserialize(String s);

    // ---------- bool ----------
    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }

        public void toggle() { value = !value; }

        @Override public String serialize() { return Boolean.toString(value); }
        @Override public void deserialize(String s) { value = Boolean.parseBoolean(s); }
    }

    // ---------- number ----------
    public static class Num extends Setting {
        public double value;
        public final ru.duo.aura.gui.Tween knob = new ru.duo.aura.gui.Tween(0f, 18f);
        public final double min, max, step;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.value = value; this.min = min; this.max = max; this.step = step;
        }

        public int asInt() { return (int) Math.round(value); }

        public void setFromPercent(double p) {
            double raw = min + (max - min) * Math.max(0, Math.min(1, p));
            value = Math.round(raw / step) * step;
            value = Math.max(min, Math.min(max, value));
        }

        public double percent() { return (value - min) / (max - min); }

        public String display() {
            return step >= 1 ? String.valueOf(asInt()) : String.format("%.2f", value);
        }

        @Override public String serialize() { return Double.toString(value); }
        @Override public void deserialize(String s) {
            try { value = Double.parseDouble(s); } catch (NumberFormatException ignored) {}
        }
    }

    // ---------- mode ----------
    public static class Mode extends Setting {
        public final String[] modes;
        public int index;
        public final ru.duo.aura.gui.Tween slide = new ru.duo.aura.gui.Tween(0f, 14f);

        public void select(int i) {
            if (i < 0) i = modes.length - 1;
            else if (i >= modes.length) i = 0;
            index = i;
            slide.set(i);
        }

        public Mode(String name, int index, String... modes) {
            super(name);
            this.modes = modes;
            this.index = index;
        }

        public String get() { return modes[index]; }
        public boolean is(String s) { return modes[index].equalsIgnoreCase(s); }
        public void next() { index = (index + 1) % modes.length; }

        @Override public String serialize() { return get(); }
        @Override public void deserialize(String s) {
            for (int i = 0; i < modes.length; i++) if (modes[i].equalsIgnoreCase(s)) index = i;
        }
    }

    public static class Key extends Setting {
        public int value;

        public Key(String name, int value) {
            super(name);
            this.value = value;
        }

        @Override public String serialize() { return Integer.toString(value); }
        @Override public void deserialize(String s) {
            try { value = Integer.parseInt(s.trim()); } catch (Exception ignored) {}
        }

        public String display() {
            return keyName(value);
        }

        public static String keyName(int k) {
            if (k == 0 || k == -1) return "NONE";
            try {
                String n = org.lwjgl.glfw.GLFW.glfwGetKeyName(k, 0);
                if (n != null && !n.isEmpty()) return n.toUpperCase();
            } catch (Throwable ignored) {}
            return switch (k) {
                case 32 -> "SPACE";
                case 256 -> "ESC";
                case 257 -> "ENTER";
                case 258 -> "TAB";
                case 259 -> "BACKSP";
                case 262 -> "RIGHT";
                case 263 -> "LEFT";
                case 264 -> "DOWN";
                case 265 -> "UP";
                case 266 -> "PGUP";
                case 267 -> "PGDN";
                case 290 -> "F1";
                case 291 -> "F2";
                case 292 -> "F3";
                case 293 -> "F4";
                case 294 -> "F5";
                case 295 -> "F6";
                case 296 -> "F7";
                case 297 -> "F8";
                case 298 -> "F9";
                case 299 -> "F10";
                case 300 -> "F11";
                case 301 -> "F12";
                case 340 -> "LSHIFT";
                case 341 -> "LCTRL";
                case 342 -> "LALT";
                case 344 -> "RSHIFT";
                case 345 -> "RCTRL";
                case 346 -> "RALT";
                default -> ("KEY" + k);
            };
        }
    }
}
