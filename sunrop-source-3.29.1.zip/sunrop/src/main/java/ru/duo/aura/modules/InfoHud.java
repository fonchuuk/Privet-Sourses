package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Панель со служебной информацией: координаты, ФПС, пинг, скорость, сторона света. */
public class InfoHud extends Module {

    public final Setting.Bool coords = add(new Setting.Bool("Coords", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS", true));
    public final Setting.Bool nick = add(new Setting.Bool("Nick", true));
    public final Setting.Bool server = add(new Setting.Bool("Server", true));
    public final Setting.Bool tps = add(new Setting.Bool("TPS", true));
    public final Setting.Bool ping = add(new Setting.Bool("Ping", true));
    public final Setting.Bool speed = add(new Setting.Bool("Speed", true));
    public final Setting.Bool direction = add(new Setting.Bool("Direction", true));
    public final Setting.Bool netherCoords = add(new Setting.Bool("Nether coords", true));
    public final Setting.Mode corner = add(new Setting.Mode("Corner", 2, "TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"));

    public InfoHud() {
        super("InfoHud", "Координаты, ФПС, ник, сервер, TPS и скорость", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        setEnabled(true);
    }
}
