package ru.duo.aura.modules;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class AutoPotion extends Module {

    public final Setting.Bool speed = add(new Setting.Bool("Speed", true));
    public final Setting.Bool invis = add(new Setting.Bool("Invis", true));
    public final Setting.Num buffer = add(new Setting.Num("Buffer (ticks)", 2, 0, 10, 1));

    private int drink = -1;
    private int hotSlot = -1;
    private int invSlot = -1;
    private int savedSel = -1;
    private boolean swapped = false;
    private long lastUse = 0;

    public AutoPotion() {
        super("AutoPotion", "Пьёт зелья скорости/инвиза из любого слота", Category.SWORD, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        if (drink >= 0) {
            mc.options.useKey.setPressed(true);
            if (--drink <= 0) {
                mc.options.useKey.setPressed(false);
                finish();
            }
            return;
        }

        boolean needSpeed = speed.value && !has(".speed");
        boolean needInvis = invis.value && !has(".invisibility");
        if (!needSpeed && !needInvis) return;
        if (System.currentTimeMillis() - lastUse < 600) return;

        int slot = findPotion(needSpeed, needInvis);
        if (slot < 0) return;
        start(slot);
    }

    private boolean has(String suffix) {
        for (StatusEffectInstance ei : mc.player.getStatusEffects()) {
            try {
                if (String.valueOf(ei.getEffectType()).toLowerCase().contains(suffix.substring(1))) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private boolean stackHas(ItemStack st, boolean sp, boolean inv) {
        PotionContentsComponent pc = st.get(DataComponentTypes.POTION_CONTENTS);
        if (pc == null) return false;
        for (StatusEffectInstance ei : pc.getEffects()) {
            try {
                String k = String.valueOf(ei.getEffectType()).toLowerCase();
                if ((sp && k.contains("speed")) || (inv && k.contains("invisibility"))) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private int findPotion(boolean sp, boolean inv) {
        var inv0 = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack st = inv0.getStack(i);
            if (!st.isEmpty() && st.isOf(Items.POTION) && stackHas(st, sp, inv)) return i;
        }
        return -1;
    }

    private int pickHotbar() {
        var inv0 = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (i != inv0.getSelectedSlot() && inv0.getStack(i).isEmpty()) return i;
        }
        return 4;
    }

    private int handlerSlot(int i) { return i < 9 ? i + 39 : i; }

    private void start(int slot) {
        var p = mc.player;
        savedSel = p.getInventory().getSelectedSlot();
        if (slot >= 9) {
            int hot = pickHotbar();
            mc.interactionManager.clickSlot(p.currentScreenHandler.syncId,
                    handlerSlot(slot), hot, SlotActionType.SWAP, p);
            hotSlot = hot;
            swapped = true;
        } else {
            hotSlot = slot;
            swapped = false;
        }
        invSlot = slot;
        p.getInventory().setSelectedSlot(hotSlot);
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hotSlot));
        }
        drink = 32 + (int) buffer.value;
        lastUse = System.currentTimeMillis();
        p.sendMessage(Text.literal("§7[Sunrop] §aпью зелье..."), true);
    }

    private void finish() {
        var p = mc.player;
        if (p == null) return;
        if (swapped && invSlot >= 9) {
            mc.interactionManager.clickSlot(p.currentScreenHandler.syncId,
                    handlerSlot(invSlot), hotSlot, SlotActionType.SWAP, p);
        }
        swapped = false;
        if (savedSel >= 0) {
            p.getInventory().setSelectedSlot(savedSel);
            if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(savedSel));
            }
            savedSel = -1;
        }
    }

    @Override
    public void onDisable() {
        if (mc.player != null) mc.options.useKey.setPressed(false);
        if (drink >= 0) finish();
        drink = -1;
    }
}
