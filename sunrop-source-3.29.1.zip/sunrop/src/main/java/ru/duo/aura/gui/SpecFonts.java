package ru.duo.aura.gui;

import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class SpecFonts {

    private static final Identifier UI    = Identifier.of("specclient", "ui");
    private static final Identifier BOLD  = Identifier.of("specclient", "ui_bold");
    private static final Identifier TINY  = Identifier.of("specclient", "ui_tiny");
    private static final Identifier TITLE = Identifier.of("specclient", "ui_title");

    private static Text with(String s, Identifier font) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(font)));
    }

    public static Text ui(String s)    { return with(s, UI); }
    public static Text bold(String s)  { return with(s, BOLD); }
    public static Text tiny(String s)  { return with(s, TINY); }
    public static Text title(String s) { return with(s, TITLE); }

    private SpecFonts() {}
}
