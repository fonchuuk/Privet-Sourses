package ru.duo.aura.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.RotationHelper;
import ru.duo.aura.core.Setting;

public class AimAssist extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 4.5, 2, 6, 0.1));
    public final Setting.Num fov = add(new Setting.Num("FOV", 60, 10, 180, 5));
    public final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "SMOOTH", "FAST", "SNAP"));
    public final Setting.Num smoothness = add(new Setting.Num("Smoothness", 3, 1, 20, 1));
    public final Setting.Num maxStep = add(new Setting.Num("Max step", 12, 1, 90, 1));
    public final Setting.Num deadzone = add(new Setting.Num("Deadzone", 0.5, 0.0, 6.0, 0.5));
    public final Setting.Bool pitchToo = add(new Setting.Bool("Assist pitch", true));
    public final Setting.Bool onlyWhenClicking = add(new Setting.Bool("Only while clicking", true));
    public final Setting.Bool walls = add(new Setting.Bool("Through walls", false));
    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));

    private final java.util.Random rnd = new java.util.Random();
    private LivingEntity lastT;
    private float fx = 0.5f, fy = 0.5f, fz = 0.5f;
    private float tfx = 0.5f, tfy = 0.5f, tfz = 0.5f;
    private int retarget = 0;
    private float yawSm, pitSm;

    public AimAssist() {
        super("AimAssist", "Мягко подводит прицел к цели", Category.SWORD, GLFW.GLFW_KEY_UNKNOWN);
    }

    private void pickPoint() {
        tfx = 0.12f + rnd.nextFloat() * 0.76f;
        tfy = switch (rnd.nextInt(3)) {
            case 0 -> 0.12f + rnd.nextFloat() * 0.25f;
            case 1 -> 0.38f + rnd.nextFloat() * 0.3f;
            default -> 0.7f + rnd.nextFloat() * 0.25f;
        };
        tfz = 0.12f + rnd.nextFloat() * 0.76f;
        retarget = 14 + rnd.nextInt(20);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        if (onlyWhenClicking.value && !mc.options.attackKey.isPressed()) return;

        double r = range.value;
        var self = p.getEntityPos();
        Box scan = new Box(self.x - r, self.y - r, self.z - r, self.x + r, self.y + r, self.z + r);

        LivingEntity best = null;
        double bestAngle = fov.value / 2.0;
        LivingEntity curBest = null;
        double curAngle = Double.MAX_VALUE;

        for (Entity e : mc.world.getOtherEntities(p, scan)) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            if (le instanceof PlayerEntity) {
                if (!players.value) continue;
                if (ru.duo.aura.core.ModuleManager.friendManager != null
                        && ru.duo.aura.core.ModuleManager.friendManager.isEnabled()
                        && ru.duo.aura.core.ModuleManager.friendManager.protectFromAura.value
                        && ru.duo.aura.core.Friends.is(le.getName().getString())) continue;
            } else if (!mobs.value) continue;
            if (p.distanceTo(le) > range.value) continue;
            if (!walls.value && !p.canSee(le)) continue;
            float[] want = RotationHelper.angleTo(p, le);
            double diff = Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw()));
            if (diff < bestAngle) { bestAngle = diff; best = le; }
            if (le == lastT) { curAngle = diff; curBest = le; }
        }

        if (best == null) { lastT = null; return; }

        if (lastT != null && curBest != null && curAngle < fov.value / 2.0
                && bestAngle > curAngle - 12.0) {
            best = curBest;
            bestAngle = curAngle;
        }
        if (best != lastT) { lastT = best; pickPoint(); }
        if (--retarget <= 0) pickPoint();

        fx = clampBox(fx + (tfx - fx) * 0.14f + (rnd.nextFloat() - 0.5f) * 0.012f);
        fy = clampBox(fy + (tfy - fy) * 0.14f + (rnd.nextFloat() - 0.5f) * 0.012f);
        fz = clampBox(fz + (tfz - fz) * 0.14f + (rnd.nextFloat() - 0.5f) * 0.012f);

        Box b = best.getBoundingBox();
        Vec3d vel = best.getVelocity();
        Vec3d pt = new Vec3d(
                b.minX + (b.maxX - b.minX) * fx + vel.x * 0.12,
                b.minY + (b.maxY - b.minY) * fy + vel.y * 0.06,
                b.minZ + (b.maxZ - b.minZ) * fz + vel.z * 0.12);

        Vec3d eye = p.getEyePos();
        double dx = pt.x - eye.x, dy = pt.y - eye.y, dz = pt.z - eye.z;
        double hor = Math.sqrt(dx * dx + dz * dz);
        float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, hor));
        float yawErr = MathHelper.wrapDegrees(wantYaw - p.getYaw());
        float pitErr = MathHelper.wrapDegrees(wantPitch - p.getPitch());
        yawSm += (yawErr - yawSm) * 0.35f;
        pitSm += (pitErr - pitSm) * 0.35f;

        if (mode.is("SNAP")) {
            p.setYaw(p.getYaw() + yawErr);
            if (pitchToo.value) p.setPitch(MathHelper.clamp(p.getPitch() + pitErr, -90f, 90f));
            return;
        }

        boolean fast = mode.is("FAST");
        double div = fast ? smoothness.value * 0.7 : smoothness.value * 1.6;
        float factor = (float) (1.0 / Math.max(1.0, div));
        float cap = fast ? 0.26f : 0.15f;
        if (factor > cap) factor = cap;
        float stepCap = (float) maxStep.value;
        float dzv = (float) deadzone.value;

        if (Math.abs(yawSm) > dzv) {
            p.setYaw(p.getYaw() + step(yawSm, factor, stepCap, fast));
        }
        if (pitchToo.value && Math.abs(pitSm) > dzv) {
            p.setPitch(MathHelper.clamp(p.getPitch() + step(pitSm, factor, stepCap, fast), -90f, 90f));
        }
    }

    private float step(float err, float factor, float cap, boolean fast) {
        float ease = MathHelper.clamp(Math.abs(err) / 12f, 0.35f, 1f);
        float s = err * factor * ease * (0.9f + 0.2f * rnd.nextFloat());
        if (fast && Math.abs(s) < 0.15f) s = Math.copySign(0.15f, err);
        return MathHelper.clamp(s, -cap, cap);
    }

    private static float clampBox(float v) {
        return Math.max(0.05f, Math.min(0.95f, v));
    }

    @Override
    public void onDisable() {
        lastT = null;
        yawSm = 0f;
        pitSm = 0f;
    }
}
