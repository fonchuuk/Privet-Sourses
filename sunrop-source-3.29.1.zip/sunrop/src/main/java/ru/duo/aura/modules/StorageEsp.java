package ru.duo.aura.modules;

import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Подсветка хранилищ + любых блоков через .blockesp add. */
public class StorageEsp extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 40, 8, 96, 1));
    public final Setting.Bool chests = add(new Setting.Bool("Chests", true));
    public final Setting.Bool barrels = add(new Setting.Bool("Barrels", true));
    public final Setting.Bool shulkers = add(new Setting.Bool("Shulkers", true));
    public final Setting.Bool hoppers = add(new Setting.Bool("Hoppers", false));
    public final Setting.Bool furnaces = add(new Setting.Bool("Furnaces", false));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", true));
    public final Setting.Bool brewing = add(new Setting.Bool("Brewing", true));
    public final Setting.Bool dispensers = add(new Setting.Bool("Dispensers", false));
    public final Setting.Bool pots = add(new Setting.Bool("Decorated pots", false));
    public final Setting.Bool custom = add(new Setting.Bool("Custom blocks", true));
    public final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    public final Setting.Bool names = add(new Setting.Bool("Names", false));

    public static final Map<Block, Integer> CUSTOM = new HashMap<>();

    public StorageEsp() {
        super("StorageEsp", "Сундуки, ловушки, бочки, шалкеры, спавнеры + .blockesp", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    public static void addCustom(Block b, int color) { CUSTOM.put(b, color); }
    public static void removeCustom(Block b) { CUSTOM.remove(b); }
    public static void clearCustom() { CUSTOM.clear(); }
    public static Integer customColor(Block b) { return CUSTOM.get(b); }

    public static String blockName(Block b) {
        var id = Registries.BLOCK.getId(b);
        return id == null ? "?" : id.getPath();
    }

    public static String colorName(int c) {
        return String.format("#%06X", c & 0xFFFFFF);
    }

    public static String listCustom() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Block, Integer> e : CUSTOM.entrySet()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(blockName(e.getKey())).append(":").append(colorName(e.getValue()));
        }
        return sb.toString();
    }

    public static String serializeCustom() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Block, Integer> e : CUSTOM.entrySet()) {
            if (sb.length() > 0) sb.append(";");
            sb.append(blockName(e.getKey())).append(":").append(colorName(e.getValue()));
        }
        return sb.toString();
    }

    public static void deserializeCustom(String s) {
        CUSTOM.clear();
        if (s == null || s.isEmpty() || s.equals("-")) return;
        for (String part : s.split(";")) {
            int i = part.lastIndexOf(':');
            if (i <= 0) continue;
            String bn = part.substring(0, i).toLowerCase(Locale.ROOT);
            var id = net.minecraft.util.Identifier.of("minecraft", bn);
            Block b = Registries.BLOCK.get(id);
            if (b == net.minecraft.block.Blocks.AIR && !bn.equals("air")) continue;
            try {
                String cs = part.substring(i + 1);
                int c;
                if (cs.startsWith("#")) c = (int) (Long.parseLong(cs.substring(1), 16) | 0xFF000000L);
                else c = (int) (Long.parseLong(cs) | 0xFF000000L);
                CUSTOM.put(b, c);
            } catch (NumberFormatException ignored) {}
        }
    }
}
