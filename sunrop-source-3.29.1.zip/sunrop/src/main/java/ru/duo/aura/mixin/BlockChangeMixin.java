package ru.duo.aura.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = World.class, priority = 1000)
public class BlockChangeMixin {

    @Inject(method = "setBlockState(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;II)Z",
            at = @At("HEAD"), require = 0)
    private void sunrop$track(BlockPos pos, BlockState state, int flags, int depth,
                              CallbackInfoReturnable<Boolean> cir) {
        try {
            World self = (World) (Object) this;
            BlockState old = self.getBlockState(pos);
            ru.duo.aura.core.BlockTracker.record(pos, old, state);
        } catch (Throwable ignored) {
        }
    }
}
