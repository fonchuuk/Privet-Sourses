package ru.duo.aura.modules;

import net.minecraft.item.Item;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public final class FT {

    private FT() {}

    private static class Base extends Module {
        final Setting.Mode mode = add(new Setting.Mode("Mode", 1, "SILENT", "VISIBLE"));
        final Setting.Num show = add(new Setting.Num("Show (ticks)", 1, 1, 6, 1));
        private final Item item;

        Base(String name, String desc, Item item) {
            super(name, desc, Category.SWORD, GLFW.GLFW_KEY_UNKNOWN);
            this.item = item;
        }

        @Override
        public void toggle() {
            FTItems.use(item, name, mode.is("VISIBLE") ? show.asInt() : 0);
        }
    }

    public static class Pearl extends Base {
        public Pearl() { super("FTPearl", "Перка (эндер-жемчуг) с клавиши", Items.ENDER_PEARL); }
    }

    public static class Trap extends Base {
        public Trap() { super("FTTrap", "Трапка (незеритовый лом) с клавиши", Items.NETHERITE_SCRAP); }
    }

    public static class Disorient extends Base {
        public Disorient() { super("FTDisorient", "Дезориентация (око эндера) с клавиши", Items.ENDER_EYE); }
    }

    public static class Sugar extends Base {
        public Sugar() { super("FTSugar", "Явная пыль (сахар) с клавиши", Items.SUGAR); }
    }

    public static class Fireball extends Base {
        public Fireball() { super("FTFireball", "Огненный шар с клавиши", Items.FIRE_CHARGE); }
    }

    public static class Freeze extends Base {
        public Freeze() { super("FTFreeze", "Заморозка (снежок) с клавиши", Items.SNOWBALL); }
    }
}
