package ru.duo.aura.modules;

import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class AutoFish extends Module {

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 6, 2, 30, 1));
    public final Setting.Bool recast = add(new Setting.Bool("Auto recast", true));
    public final Setting.Bool autoRod = add(new Setting.Bool("Take rod", true));

    private int timer;

    public AutoFish() {
        super("AutoFish", "Сам ловит и подсекает рыбу", Category.FARM, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        if (timer > 0) { timer--; return; }

        if (!p.getMainHandStack().isOf(Items.FISHING_ROD)) {
            if (!autoRod.value) return;
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().getStack(i).isOf(Items.FISHING_ROD)) {
                    p.getInventory().setSelectedSlot(i);
                    timer = 2;
                    return;
                }
            }
            return;
        }

        var bobber = p.fishHook;
        if (bobber == null) {
            if (recast.value) {
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.swingHand(Hand.MAIN_HAND);
                timer = delay.asInt();
            }
            return;
        }

        boolean bite = bobber.getHookedEntity() != null;
        if (bite) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            timer = delay.asInt();
        }
    }

    @Override
    public void onDisable() {
        timer = 0;
    }
}
