package ru.duo.aura.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.Theme;
import ru.duo.aura.core.ProjectileSim;
import ru.duo.aura.modules.Predicts;
import ru.duo.aura.modules.Trajectories;

import java.util.HashMap;
import java.util.Map;

public final class ProjectileRenderer {

    private static final class Predict {
        Vec3d[] path;
        Vec3d land;
        int ticks;
        long time;
    }

    private static final Map<Integer, Predict> PREDICTS = new HashMap<>();
    private static final Map<Integer, Vec3d> SEEN = new HashMap<>();

    private static Vec3d[] selfPath;
    private static Vec3d selfLand;
    private static long selfKey = Long.MIN_VALUE;
    private static long selfTime;

    private static long lastScan = 0;
    private static int scanIdx = 0;

    private ProjectileRenderer() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) return;

        Trajectories tr = ModuleManager.trajectories;
        Predicts pr = ModuleManager.predicts;
        boolean trOn = tr != null && tr.isEnabled();
        boolean prOn = pr != null && pr.isEnabled();
        if (!trOn && !prOn) { PREDICTS.clear(); SEEN.clear(); selfPath = null; return; }

        EspRenderer.Projector proj = EspRenderer.Projector.of(cam,
                ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
        if (proj == null) return;

        if (trOn) drawSelf(ctx, mc, tr, proj);
        if (prOn) drawIncoming(ctx, mc, pr, proj);
    }

    // --------------------------------------------------- траектория своего броска

    private static double[] params(ItemStack st) {
        if (st.isEmpty()) return null;
        var item = st.getItem();
        if (st.isOf(net.minecraft.item.Items.ENDER_PEARL)
                || st.isOf(net.minecraft.item.Items.SNOWBALL)
                || st.isOf(net.minecraft.item.Items.EGG)) {
            return new double[]{1.5, 0.03, 0.99};
        }
        if (st.isOf(net.minecraft.item.Items.EXPERIENCE_BOTTLE)) return new double[]{0.7, 0.07, 0.99};
        if (st.isOf(net.minecraft.item.Items.SPLASH_POTION)
                || st.isOf(net.minecraft.item.Items.LINGERING_POTION)) return new double[]{0.5, 0.05, 0.99};

        String cn = item.getClass().getSimpleName();
        if (cn.contains("Bow") && !cn.contains("Cross")) {
            var p = MinecraftClient.getInstance().player;
            if (p == null || !p.isUsingItem()) return null;
            float f = MathHelper.clamp(p.getItemUseTime() / 20f, 0f, 1f);
            f = (f * f + f * 2f) / 3f;
            return new double[]{Math.max(0.35, f * 3.0), 0.05, 0.99};
        }
        if (cn.contains("Crossbow")) return new double[]{3.15, 0.05, 0.99};
        if (cn.contains("Trident")) {
            var p = MinecraftClient.getInstance().player;
            if (p != null && p.isUsingItem()) {
                float f = MathHelper.clamp(p.getItemUseTime() / 20f, 0f, 1f);
                return new double[]{Math.max(0.5, f * 2.5), 0.05, 0.99};
            }
            return new double[]{2.5, 0.05, 0.99};
        }
        return null;
    }

    private static void drawSelf(DrawContext ctx, MinecraftClient mc, Trajectories m, EspRenderer.Projector proj) {
        double[] pr = params(mc.player.getMainHandStack());
        if (pr == null) {
            selfPath = null;
            return;
        }

        long now = System.currentTimeMillis();
        long key = Math.round(mc.player.getPitch() * 2) * 100000L
                + Math.round(mc.player.getYaw() * 2) * 10L
                + Math.round(pr[0] * 100);
        if (selfPath == null || now - selfTime > 250 || key != selfKey) {
            Vec3d dir = Vec3d.fromPolar(mc.player.getPitch(), mc.player.getYaw());
            Vec3d pos = new Vec3d(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
            Vec3d vel = new Vec3d(dir.x * pr[0], dir.y * pr[0], dir.z * pr[0]);
            ProjectileSim.Result r = ProjectileSim.simulate(pos, vel, pr[1], pr[2], 90);
            selfPath = r.path.toArray(new Vec3d[0]);
            selfLand = r.land;
            selfKey = key;
            selfTime = now;
        }
        if (selfPath == null || selfLand == null) return;

        int col = m.color.is("WHITE") ? 0xFFFFFFFF
                : m.color.is("RAINBOW") ? rainbow() : Theme.accent();
        drawPath(ctx, proj, selfPath, col, m.width.asInt(), false);
        if (m.mark.value) drawMark(ctx, mc, proj, selfLand, col, null);
        if (m.info.value) {
            double dist = mc.player.getEntityPos().distanceTo(selfLand);
            drawLabel(ctx, proj, selfLand, String.format("%.1f м", dist), col);
        }
    }

    // --------------------------------------------------- чужие снаряды

    private static void drawIncoming(DrawContext ctx, MinecraftClient mc, Predicts m, EspRenderer.Projector proj) {
        long now = System.currentTimeMillis();
        if (now - lastScan > 400) {
            lastScan = now;
            double r = m.range.value;
            SEEN.clear();
            for (Entity e : mc.world.getOtherEntities(mc.player, new net.minecraft.util.math.Box(
                    mc.player.getX() - r, mc.player.getY() - r, mc.player.getZ() - r,
                    mc.player.getX() + r, mc.player.getY() + r, mc.player.getZ() + r))) {
                if (e instanceof ProjectileEntity) SEEN.put(e.getId(), e.getEntityPos());
            }
            PREDICTS.keySet().retainAll(SEEN.keySet());
        }

        int budget = 2;
        int drawn = 0;
        for (Map.Entry<Integer, Vec3d> en : SEEN.entrySet()) {
            if (drawn++ > 16) break;
            Predict p = PREDICTS.get(en.getKey());
            Entity e = mc.world.getEntityById(en.getKey());
            if (!(e instanceof ProjectileEntity pe)) continue;
            if (m.others.value && pe.getOwner() == mc.player) continue;

            Vec3d vel = e.getVelocity();
            if (vel.lengthSquared() < 1.0E-4) continue;

            if (p == null || now - p.time > 250 && budget > 0) {
                double g = gravityOf(pe);
                double drag = explosive(pe) ? 1.0 : 0.99;
                Vec3d pos = new Vec3d(e.getX(), e.getY(), e.getZ());
                ProjectileSim.Result r = ProjectileSim.simulate(pos, vel, g, drag, 90);
                p = new Predict();
                p.path = r.path.toArray(new Vec3d[0]);
                p.land = r.land;
                p.ticks = r.ticks;
                p.time = now;
                PREDICTS.put(en.getKey(), p);
                budget--;
            }
            if (p == null || p.land == null) continue;

            int col = pe.getOwner() == mc.player ? 0xFF9AA0B0 : 0xFFFF5A5A;
            if (m.line.value) drawPath(ctx, proj, p.path, col, 1, true);
            drawMark(ctx, mc, proj, p.land, col, null);
            String label = "";
            if (m.timer.value) label += String.format("%.1fs", p.ticks / 20.0);
            if (m.names.value) {
                String n = pe.getName().getString();
                label = label.isEmpty() ? n : label + " · " + n;
            }
            if (!label.isEmpty()) drawLabel(ctx, proj, p.land, label, col);
        }
    }

    private static int rainbow() {
        float hue = ((System.currentTimeMillis() / 12) % 3600) / 3600.0f;
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(hue, 0.65f, 1.0f) & 0xFFFFFF);
    }

    private static boolean explosive(ProjectileEntity e) {
        String cn = e.getClass().getSimpleName();
        return cn.contains("Fireball") || cn.contains("Skull") || cn.contains("DragonFireball")
                || cn.contains("WitherSkull");
    }

    private static double gravityOf(ProjectileEntity e) {
        if (explosive(e)) return 0;
        String cn = e.getClass().getSimpleName();
        if (cn.contains("Trident") || cn.contains("Arrow") || cn.contains("Spectral")) return 0.05;
        if (cn.contains("ExperienceBottle")) return 0.07;
        if (cn.contains("Potion")) return 0.05;
        return 0.03;
    }

    // --------------------------------------------------- отрисовка

    private static void drawPath(DrawContext ctx, EspRenderer.Projector proj, Vec3d[] path,
                                 int col, int width, boolean dashed) {
        if (path == null || path.length < 2) return;
        int stride = dashed ? 3 : 1;
        for (int i = 0; i + 1 < path.length; i += stride) {
            Vec3d a = path[i], b = path[Math.min(i + 1, path.length - 1)];
            float[] sa = proj.project(a.x, a.y, a.z);
            float[] sb = proj.project(b.x, b.y, b.z);
            if (sa == null || sb == null) continue;
            int fade = 255 - (int) (110.0 * i / path.length);
            Draw.tracer(ctx, (int) sa[0], (int) sa[1], (int) sb[0], (int) sb[1],
                    (Math.max(0, Math.min(255, fade)) << 24) | (col & 0xFFFFFF), width);
        }
    }

    private static void drawMark(DrawContext ctx, MinecraftClient mc, EspRenderer.Projector proj,
                                 Vec3d land, int col, String name) {
        float[] r = proj.cornerBox(new Vec3d(land.x, land.y, land.z), 0.4f, 0.7f);
        if (r == null) return;
        int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
        if (x2 - x1 < 2 || y2 - y1 < 2) return;
        int pulse = (int) (150 + 80 * Math.sin(System.currentTimeMillis() / 160.0));
        int c = (Math.max(0, Math.min(255, pulse)) << 24) | (col & 0xFFFFFF);
        Draw.corners(ctx, x1, y1, x2, y2, c, false);
        ctx.fill(x1, y2, x2, y2 + 1, c);
    }

    private static void drawLabel(DrawContext ctx, EspRenderer.Projector proj, Vec3d pos, String text, int col) {
        float[] s = proj.project(pos.x, pos.y + 1.1, pos.z);
        if (s == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int tw = mc.textRenderer.getWidth(text);
        int x = (int) s[0], y = (int) s[1];
        Draw.round(ctx, x - tw / 2 - 3, y - 6, x + tw / 2 + 3, y + 5, 2, 0xA0101018);
        ctx.drawText(mc.textRenderer, text, x - tw / 2, y - 4, 0xFF000000 | (col & 0xFFFFFF), false);
    }
}
