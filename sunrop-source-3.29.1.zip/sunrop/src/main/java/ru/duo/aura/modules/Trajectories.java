package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class Trajectories extends Module {

    public final Setting.Mode color = add(new Setting.Mode("Color", 0, "ACCENT", "RAINBOW", "WHITE"));
    public final Setting.Num width = add(new Setting.Num("Width", 1, 1, 3, 1));
    public final Setting.Bool mark = add(new Setting.Bool("Landing mark", true));
    public final Setting.Bool info = add(new Setting.Bool("Distance", true));

    public Trajectories() {
        super("Trajectories", "Траектория полёта предмета из руки", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
