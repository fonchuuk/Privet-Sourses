package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class Animations extends Module {

    public final Setting.Mode style = add(new Setting.Mode("Style", 1,
            "VANILLA", "SMOOTH", "TAP", "SLIDE", "PUNCH", "WAVE"));
    public final Setting.Num power = add(new Setting.Num("Power", 1, 0.2, 2, 0.05));

    public Animations() {
        super("Animations", "Анимация удара рукой", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
