package ru.duo.aura.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

public final class FTItems {

    private static long lastUse = 0;
    private static int restoreSlot = -1;
    private static int restoreIn = 0;
    private static int swapScreen = -1;
    private static int swapButton = -1;
    private static int savedSyncId = -1;

    private FTItems() {}

    public static void use(Item item, String label, int visibleTicks) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        long now = System.currentTimeMillis();
        if (now - lastUse < 220) return;

        int invSlot = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!st.isEmpty() && st.isOf(item)) { invSlot = i; break; }
        }
        if (invSlot == -1) {
            p.sendMessage(Text.literal("§7[FT] §cнет предмета: " + label), true);
            return;
        }
        lastUse = now;

        int cur = p.getInventory().getSelectedSlot();

        if (invSlot < 9) {
            p.getInventory().setSelectedSlot(invSlot);
            if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(
                        new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(invSlot));
            }
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            if (visibleTicks <= 0) {
                p.getInventory().setSelectedSlot(cur);
                if (mc.getNetworkHandler() != null) {
                    mc.getNetworkHandler().sendPacket(
                            new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(cur));
                }
            } else {
                restoreSlot = cur;
                restoreIn = visibleTicks;
                savedSyncId = p.currentScreenHandler.syncId;
            }
        } else {
            int srcScreen = invSlot;
            mc.interactionManager.clickSlot(p.currentScreenHandler.syncId, srcScreen, cur, SlotActionType.SWAP, p);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            if (visibleTicks <= 0) {
                mc.interactionManager.clickSlot(p.currentScreenHandler.syncId, srcScreen, cur, SlotActionType.SWAP, p);
            } else {
                restoreSlot = -2;
                restoreIn = visibleTicks;
                swapScreen = srcScreen;
                swapButton = cur;
                savedSyncId = p.currentScreenHandler.syncId;
            }
        }
    }

    public static void tick(MinecraftClient mc) {
        if (restoreIn <= 0) return;
        if (--restoreIn > 0) return;
        restoreIn = 0;
        if (mc.player == null || mc.interactionManager == null) { restoreSlot = -1; return; }
        if (restoreSlot >= 0) {
            mc.player.getInventory().setSelectedSlot(restoreSlot);
        } else if (restoreSlot == -2) {
            if (mc.currentScreen == null && mc.player.currentScreenHandler.syncId == savedSyncId) {
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, swapScreen, swapButton,
                        SlotActionType.SWAP, mc.player);
            }
        }
        restoreSlot = -1;
    }
}
