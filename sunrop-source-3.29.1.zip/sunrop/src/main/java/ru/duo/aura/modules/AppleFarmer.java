package ru.duo.aura.modules;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.ShearsItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.FarmModule;
import ru.duo.aura.core.Setting;

/** Рубит дубовую листву (яблоки, саженцы) и при желании сам ствол. */
public class AppleFarmer extends FarmModule {

    public final Setting.Bool leaves = add(new Setting.Bool("Leaves", true));
    public final Setting.Bool logs = add(new Setting.Bool("Logs", true));
    public final Setting.Bool oakOnly = add(new Setting.Bool("Oak only", true));
    public final Setting.Bool autoTool = add(new Setting.Bool("Auto tool", true));
    public final Setting.Bool leavesByHand = add(new Setting.Bool("Leaves by hand", false));
    public final Setting.Bool replant = add(new Setting.Bool("Replant saplings", true));
    private final java.util.LinkedHashSet<BlockPos> stumps = new java.util.LinkedHashSet<>();
    private int replantCd = 0;

    public AppleFarmer() {
        super("AppleFarmer", "Рубит дубы: яблоки, саженцы, брёвна", Category.FARM, GLFW.GLFW_KEY_UNKNOWN);
        radius.value = 8;
        vertical.value = 8;
    }

    @Override
    protected boolean matches(BlockPos pos) {
        if (mc.world == null) return false;
        BlockState st = mc.world.getBlockState(pos);

        if (logs.value && isLog(st)) return true;
        if (!leaves.value) return false;
        if (!(st.getBlock() instanceof LeavesBlock)) return false;
        if (st.getFluidState() != null && !st.getFluidState().isEmpty()) return false;
        if (!oakOnly.value) return true;
        return st.isOf(Blocks.OAK_LEAVES) || st.isOf(Blocks.DARK_OAK_LEAVES);
    }

    private boolean isLog(BlockState st) {
        if (oakOnly.value) {
            return st.isOf(Blocks.OAK_LOG) || st.isOf(Blocks.DARK_OAK_LOG)
                    || st.isOf(Blocks.OAK_WOOD) || st.isOf(Blocks.DARK_OAK_WOOD);
        }
        return st.isIn(net.minecraft.registry.tag.BlockTags.LOGS);
    }

    @Override
    protected void beforeBreak(BlockPos pos) {
        if (mc.world != null && replant.value && isLog(mc.world.getBlockState(pos))) {
            stumps.add(pos.toImmutable());
            while (stumps.size() > 8) stumps.remove(stumps.iterator().next());
        }
        if (!autoTool.value || mc.player == null || mc.world == null) return;
        BlockState st = mc.world.getBlockState(pos);

        if (st.getBlock() instanceof LeavesBlock) {
            if (leavesByHand.value) { selectEmptyish(); return; }
            // листва: мотыга и ножницы ломают её мгновенно, топор — нет
            if (selectBest(st)) return;
            selectEmptyish();
            return;
        }

        // брёвна — топором
        if (selectBest(st)) return;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                select(i);
                return;
            }
        }
    }

    /**
     * Берём из хотбара предмет, который реально быстрее всего ломает этот блок:
     * для листвы это мотыга или ножницы, для брёвен — топор. Сама игра считает
     * скорость, поэтому отдельные списки инструментов не нужны.
     */
    private boolean selectBest(BlockState state) {
        int best = -1;
        float bestSpeed = 1.5f; // рука = 1.0, берём инструмент только если заметно быстрее
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            float sp = stack.getMiningSpeedMultiplier(state);
            if (stack.getItem() instanceof ShearsItem || stack.getItem() instanceof HoeItem) sp += 0.1f;
            if (sp > bestSpeed) { bestSpeed = sp; best = i; }
        }
        if (best >= 0) { select(best); return true; }
        return false;
    }

    /** Берём слот без инструмента, чтобы не тратить прочность на листву. */
    private void selectEmptyish() {
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) { select(i); return; }
        }
        for (int i = 0; i < 9; i++) {
            var st = mc.player.getInventory().getStack(i);
            var item = st.getItem();
            // любой предмет, который не изнашивается от удара по листве
            if (!(item instanceof AxeItem) && !(item instanceof ShearsItem)
                    && !(item instanceof net.minecraft.item.ShovelItem)
                    && !st.isDamageable()) {
                select(i);
                return;
            }
        }
    }

    private void select(int slot) {
        if (mc.player.getInventory().getSelectedSlot() != slot) {
            mc.player.getInventory().setSelectedSlot(slot);
        }
    }

    @Override
    protected void idle() {
        if (!replant.value || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (--replantCd > 0) return;
        java.util.Iterator<BlockPos> it = stumps.iterator();
        while (it.hasNext()) {
            BlockPos p = it.next();
            if (p.getSquaredDistance(mc.player.getBlockPos()) > 256) { it.remove(); continue; }
            if (mc.world.getBlockState(p).isAir()
                    && mc.world.getBlockState(p.down()).isOf(Blocks.GRASS_BLOCK)
                    && mc.world.getBlockState(p.up()).isAir()) {
                if (plant(p)) { it.remove(); replantCd = 14; return; }
            } else if (!mc.world.getBlockState(p).isAir()) {
                it.remove();
            }
        }
    }

    private boolean plant(BlockPos p) {
        var inv = mc.player.getInventory();
        int slot = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack st = inv.getStack(i);
            if (st.isOf(Items.OAK_SAPLING) || st.isOf(Items.DARK_OAK_SAPLING)) { slot = i; break; }
        }
        if (slot < 0) return false;
        int cur = inv.getSelectedSlot();
        boolean swapped = false;
        if (slot >= 9) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId,
                    slot + 39, 0, SlotActionType.SWAP, mc.player);
            swapped = true;
        } else {
            inv.setSelectedSlot(slot);
        }
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(new Vec3d(p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5),
                        Direction.UP, p, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        if (swapped) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId,
                    slot + 39, 0, SlotActionType.SWAP, mc.player);
        }
        inv.setSelectedSlot(cur);
        return true;
    }
}
