package ru.duo.aura.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

public final class R2 {

    public static final Identifier BLOB = Identifier.of("specclient", "textures/gui/blob.png");
    public static float globalAlpha = 1f;
    private static final float TEXT_DY = -2f;

    private R2() {}

    public static int alpha(int color, float mul) {
        int a = (int) ((color >>> 24 & 0xFF) * Tween.clamp01(mul) + 0.5f);
        return a << 24 | color & 0xFFFFFF;
    }

    public static int c(int color) {
        return globalAlpha >= 0.999f ? color : alpha(color, globalAlpha);
    }

    public static int c(int color, float mul) {
        return alpha(color, mul * globalAlpha);
    }

    public static int mix(int a, int b, float t) {
        t = Tween.clamp01(t);
        int aa = (int) Tween.lerp(a >>> 24 & 0xFF, b >>> 24 & 0xFF, t);
        int ar = (int) Tween.lerp(a >> 16 & 0xFF, b >> 16 & 0xFF, t);
        int ag = (int) Tween.lerp(a >> 8 & 0xFF, b >> 8 & 0xFF, t);
        int ab = (int) Tween.lerp(a & 0xFF, b & 0xFF, t);
        return aa << 24 | ar << 16 | ag << 8 | ab;
    }

    private static void span(DrawContext ctx, float x0, float x1, int y, int h, int color) {
        if (x1 <= x0 || h <= 0 || color >>> 24 == 0) return;
        int a0 = (int) Math.ceil(x0);
        int a1 = (int) Math.floor(x1);
        if (a1 <= a0) {
            int px = (int) Math.floor((x0 + x1) * 0.5f);
            ctx.fill(px, y, px + 1, y + h, alpha(color, x1 - x0));
            return;
        }
        ctx.fill(a0, y, a1, y + h, color);
    }

    public static void rect(DrawContext ctx, float x0, float y0, float x1, float y1, int color) {
        if (x1 <= x0 || y1 <= y0 || color >>> 24 == 0) return;
        int b0 = (int) Math.ceil(y0);
        int b1 = (int) Math.floor(y1);
        if (b1 <= b0) {
            int py = (int) Math.floor((y0 + y1) * 0.5f);
            span(ctx, x0, x1, py, 1, alpha(color, y1 - y0));
            return;
        }
        span(ctx, x0, x1, b0, b1 - b0, color);
    }

    public static void rectWH(DrawContext ctx, float x, float y, float w, float h, int color) {
        rect(ctx, x, y, x + w, y + h, color);
    }

    public static void round(DrawContext ctx, float x, float y, float w, float h, float r, int color) {
        if (w <= 0f || h <= 0f || color >>> 24 == 0) return;
        r = Math.max(0f, Math.min(r, Math.min(w, h) * 0.5f));
        if (r < 0.5f) {
            rectWH(ctx, x, y, w, h, color);
            return;
        }
        int x0 = Math.round(x), y0 = Math.round(y), x1 = Math.round(x + w), y1 = Math.round(y + h);
        int ri = Math.min(4, Math.max(2, Math.round(r * 0.55f)));
        ctx.fill(x0, y0 + ri, x1, y1 - ri, color);
        ctx.fill(x0 + ri, y0, x1 - ri, y0 + ri, color);
        ctx.fill(x0 + ri, y1 - ri, x1 - ri, y1, color);
        corners(ctx, y0, x0, x1, r, color, true, ri);
        corners(ctx, y1 - ri, x0, x1, r, color, false, ri);
    }

    private static void corners(DrawContext ctx, int from, int x0, int x1,
                                float r, int color, boolean top, int ri) {
        float cy = top ? from + ri : from;
        for (int i = 0; i < ri; i++) {
            float dy = top ? (cy - (from + i) - 0.5f) : ((from + i) + 0.5f - cy);
            float dx = r - (float) Math.sqrt(Math.max(0f, r * r - dy * dy));
            int ins = Math.round(dx);
            int y = from + i;
            ctx.fill(x0, y, x0 + ri - ins, y + 1, color);
            ctx.fill(x1 - ri + ins, y, x1, y + 1, color);
        }
    }

    public static void panel(DrawContext ctx, float x, float y, float w, float h, float r,
                             int fill, int border, float thickness) {
        if (border >>> 24 != 0) {
            round(ctx, x, y, w, h, r, border);
            round(ctx, x + thickness, y + thickness, w - 2f * thickness, h - 2f * thickness,
                    Math.max(0f, r - thickness), fill);
        } else {
            round(ctx, x, y, w, h, r, fill);
        }
    }

    public static void circle(DrawContext ctx, float cx, float cy, float r, int color) {
        round(ctx, cx - r, cy - r, r * 2f, r * 2f, r, color);
    }

    public static void ring(DrawContext ctx, float cx, float cy, float r, float thickness, int color, int inside) {
        circle(ctx, cx, cy, r, color);
        circle(ctx, cx, cy, Math.max(0f, r - thickness), inside);
    }

    public static void rotRect(DrawContext ctx, float cx, float cy, float w, float h, float angleRad, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        m.rotate(angleRad);
        rect(ctx, -w * 0.5f, -h * 0.5f, w * 0.5f, h * 0.5f, color);
        m.popMatrix();
    }

    public static void glow(DrawContext ctx, float cx, float cy, float radius, int color) {
        int d = Math.max(2, Math.round(radius * 2f));
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BLOB,
                Math.round(cx - radius), Math.round(cy - radius), 0f, 0f, d, d, d, d, color);
    }

    public static void shadow(DrawContext ctx, float x, float y, float w, float h, float spread, int color) {
        int steps = 3;
        for (int i = steps; i >= 1; i--) {
            float g = spread * i / (float) steps;
            float a = (1f - i / (float) (steps + 1)) * 0.5f;
            round(ctx, x - g, y - g + 1.5f, w + g * 2f, h + g * 2f, 10f + g, alpha(color, a));
        }
    }

    public static void text(DrawContext ctx, Text txt, float x, float y, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y + TEXT_DY);
        ctx.drawText(MinecraftClient.getInstance().textRenderer, txt, 0, 0, color, false);
        m.popMatrix();
    }

    public static void textCentered(DrawContext ctx, Text txt, float cx, float y, int color) {
        text(ctx, txt, cx - width(txt) * 0.5f, y, color);
    }

    public static void textRight(DrawContext ctx, Text txt, float right, float y, int color) {
        text(ctx, txt, right - width(txt), y, color);
    }

    public static int width(Text txt) {
        return MinecraftClient.getInstance().textRenderer.getWidth(txt);
    }

    public static boolean hover(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
