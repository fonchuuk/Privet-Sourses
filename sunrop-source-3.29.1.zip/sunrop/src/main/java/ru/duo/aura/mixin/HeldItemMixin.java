package ru.duo.aura.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.block.MovingBlockRenderState;
import net.minecraft.client.render.command.ModelCommandRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.command.RenderCommandQueue;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.modules.Animations;
import ru.duo.aura.modules.HandPos;
import ru.duo.aura.modules.HandsShader;

import java.util.List;

@Mixin(value = HeldItemRenderer.class, priority = 900)
public class HeldItemMixin {

    private static final String FP_RENDER =
            "renderItem(FLnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;"
                    + "Lnet/minecraft/client/network/ClientPlayerEntity;I)V";

    private static final String ENT_RENDER =
            "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;"
                    + "Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V";

    @Inject(method = FP_RENDER, at = @At("HEAD"), require = 0)
    private void sunrop$handPush(float tickProgress, MatrixStack matrices,
                                 OrderedRenderCommandQueue queue, ClientPlayerEntity player,
                                 int light, CallbackInfo ci) {
        HandPos hp = ModuleManager.handPos;
        if (hp == null || !hp.isEnabled()) return;
        matrices.push();
        float bob = (float) hp.bob.value;
        float bobY = bob > 0.01f
                ? (float) Math.sin(System.currentTimeMillis() / 260.0) * 0.05f * bob : 0f;
        matrices.translate((float) hp.offX.value, (float) hp.offY.value + bobY, (float) hp.offZ.value);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) hp.rotZ.value));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) hp.rotX.value));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) hp.rotY.value));
        float s = (float) hp.scale.value;
        matrices.scale(s, s, s);
    }

    @Inject(method = FP_RENDER, at = @At("RETURN"), require = 0)
    private void sunrop$handPop(float tickProgress, MatrixStack matrices,
                                OrderedRenderCommandQueue queue, ClientPlayerEntity player,
                                int light, CallbackInfo ci) {
        HandPos hp = ModuleManager.handPos;
        if (hp == null || !hp.isEnabled()) return;
        matrices.pop();
    }

    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true, require = 0)
    private void sunrop$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        Animations an = ModuleManager.animations;
        if (an == null || !an.isEnabled() || an.style.is("VANILLA")) return;
        ci.cancel();
        int i = arm == Arm.RIGHT ? 1 : -1;
        float k = (float) an.power.value;
        float s = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        float xAmp, yAmp, zAmp, transX;
        switch (an.style.get()) {
            case "SMOOTH" -> { xAmp = 45f; yAmp = -12f; zAmp = -10f; transX = 0f; }
            case "TAP" -> { xAmp = 88f; yAmp = -24f; zAmp = -26f; transX = 0f; }
            case "SLIDE" -> { xAmp = 50f; yAmp = -14f; zAmp = -16f; transX = 0.20f; }
            case "PUNCH" -> { xAmp = 102f; yAmp = -18f; zAmp = -22f; transX = 0.04f; }
            case "WAVE" -> { xAmp = 32f; yAmp = -10f; zAmp = -34f; transX = 0.10f; }
            default -> { xAmp = 80f; yAmp = -20f; zAmp = -20f; transX = 0f; }
        }
        matrices.translate(i * transX * g, 0.03f * g * k, 0f);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (45f + s * yAmp * k)));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * g * zAmp * k));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * xAmp * k));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45f));
        if (an.style.is("WAVE")) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(
                    i * MathHelper.sin(swingProgress * (float) Math.PI * 2f) * 16f * k));
        }
    }

    @ModifyVariable(method = ENT_RENDER, at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private OrderedRenderCommandQueue sunrop$tintQueue(OrderedRenderCommandQueue queue) {
        HandsShader hs = ModuleManager.handsShader;
        if (hs == null || !hs.isEnabled() || hs.strength.value < 0.02) return queue;
        float[] c = hs.rgb();
        return new TintQueue(queue, c[0], c[1], c[2], (float) hs.strength.value);
    }

    private static final class TintQueue implements OrderedRenderCommandQueue {
        private final OrderedRenderCommandQueue d;
        private final float tr, tg, tb, ta;

        TintQueue(OrderedRenderCommandQueue d, float tr, float tg, float tb, float ta) {
            this.d = d;
            this.tr = tr; this.tg = tg; this.tb = tb; this.ta = ta;
        }

        private int tint(int c) {
            int a = (c >>> 24) & 0xFF;
            int r = (c >>> 16) & 0xFF;
            int g = (c >>> 8) & 0xFF;
            int b = c & 0xFF;
            return (a << 24)
                    | ((int) (r * (1 - ta + ta * tr * 1.8f)) << 16)
                    | ((int) (g * (1 - ta + ta * tg * 1.8f)) << 8)
                    | (int) (b * (1 - ta + ta * tb * 1.8f));
        }

        @Override
        public void submitItem(MatrixStack matrices, ItemDisplayContext ctx, int light, int overlay,
                               int color, int[] tints, List<BakedQuad> quads,
                               RenderLayer layer, ItemRenderState.Glint glint) {
            int[] t = tints;
            if (tints != null && tints.length > 0) {
                t = tints.clone();
                for (int i = 0; i < t.length; i++) t[i] = tint(t[i]);
            }
            d.submitItem(matrices, ctx, light, overlay, color, t, quads, layer, glint);
        }

        @Override
        public RenderCommandQueue getBatchingQueue(int i) { return d.getBatchingQueue(i); }

        @Override
        public void submitShadowPieces(MatrixStack matrices, float f, List<EntityRenderState.ShadowPiece> l) {
            d.submitShadowPieces(matrices, f, l);
        }

        @Override
        public void submitLabel(MatrixStack matrices, Vec3d pos, int color, Text text,
                                boolean shadow, int background, double scale, CameraRenderState cam) {
            d.submitLabel(matrices, pos, color, text, shadow, background, scale, cam);
        }

        @Override
        public void submitText(MatrixStack matrices, float x, float y, net.minecraft.text.OrderedText text,
                               boolean shadow, TextRenderer.TextLayerType type,
                               int color, int outlineColor, int light, int backgroundColor) {
            d.submitText(matrices, x, y, text, shadow, type, color, outlineColor, light, backgroundColor);
        }

        @Override
        public void submitFire(MatrixStack matrices, EntityRenderState state, Quaternionf rotation) {
            d.submitFire(matrices, state, rotation);
        }

        @Override
        public void submitLeash(MatrixStack matrices, EntityRenderState.LeashData data) {
            d.submitLeash(matrices, data);
        }

        @Override
        public <S> void submitModel(Model<? super S> model, S state, MatrixStack matrices,
                                    RenderLayer layer, int light, int overlay, int color,
                                    Sprite sprite, int i, ModelCommandRenderer.CrumblingOverlayCommand crumbling) {
            d.submitModel(model, state, matrices, layer, light, overlay, color, sprite, i, crumbling);
        }

        @Override
        public void submitModelPart(ModelPart part, MatrixStack matrices, RenderLayer layer,
                                    int light, int overlay, Sprite sprite, boolean b1, boolean b2,
                                    int color, ModelCommandRenderer.CrumblingOverlayCommand crumbling, int i) {
            d.submitModelPart(part, matrices, layer, light, overlay, sprite, b1, b2, color, crumbling, i);
        }

        @Override
        public void submitBlock(MatrixStack matrices, BlockState state, int i1, int i2, int i3) {
            d.submitBlock(matrices, state, i1, i2, i3);
        }

        @Override
        public void submitMovingBlock(MatrixStack matrices, MovingBlockRenderState state) {
            d.submitMovingBlock(matrices, state);
        }

        @Override
        public void submitBlockStateModel(MatrixStack matrices, RenderLayer layer,
                                          net.minecraft.client.render.model.BlockStateModel model,
                                          float f1, float f2, float f3, int i1, int i2, int i3) {
            d.submitBlockStateModel(matrices, layer, model, f1, f2, f3, i1, i2, i3);
        }

        @Override
        public void submitCustom(MatrixStack matrices, RenderLayer layer, OrderedRenderCommandQueue.Custom custom) {
            d.submitCustom(matrices, layer, custom);
        }

        @Override
        public void submitCustom(OrderedRenderCommandQueue.LayeredCustom custom) {
            d.submitCustom(custom);
        }
    }
}
