package ru.duo.aura.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import ru.duo.aura.core.BlockTracker;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.modules.BaseFinder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Отрисовка BaseFinder: блоки, изменения, мобы-индикаторы, метки «баз». */
public final class BaseFinderRenderer {

    private static final Map<Long, Object[]> FOUNDS = new LinkedHashMap<>();
    private static final List<Entity> MOBS = new ArrayList<>();
    private static BlockPos scanCenter = null;
    private static int scanIdx = 0;
    private static int frame = 0;
    private static long lastClean = 0;
    private static long lastMobScan = 0;

    private BaseFinderRenderer() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        BaseFinder m = ModuleManager.baseFinder;
        if (m == null || !m.isEnabled()) { FOUNDS.clear(); MOBS.clear(); return; }

        if ((frame++ & 1) == 0) scanChunk(mc, m);
        clean(mc, m);
        if (m.mobs.value) scanMobs(mc, m);

        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) return;
        EspRenderer.Projector proj = EspRenderer.Projector.of(cam,
                ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
        if (proj == null) return;

        if (m.highlight.value) {
            for (Object[] o : FOUNDS.values()) {
                drawBox(ctx, proj, (BlockPos) o[0], (Integer) o[1]);
            }
        }

        drawChanges(ctx, mc, m, proj);
        drawMobs(ctx, mc, m, proj);

        if (m.labels.value) drawClusters(ctx, mc, m, proj);
    }

    private static void drawBox(DrawContext ctx, EspRenderer.Projector proj, BlockPos pos, int color) {
        float[] r = proj.cornerBox(new Vec3d(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5), 1f, 1f);
        if (r == null) return;
        int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
        if (x2 - x1 < 1 || y2 - y1 < 1) return;
        Draw.corners(ctx, x1, y1, x2, y2, color, false);
    }

    private static void drawChanges(DrawContext ctx, MinecraftClient mc, BaseFinder m,
                                    EspRenderer.Projector proj) {
        List<BlockTracker.Change> changes = BlockTracker.get();
        int drawn = 0;
        for (BlockTracker.Change c : changes) {
            if (drawn++ > 260) break;
            int col = c.placed ? 0xFF4CFF88 : 0xFFFF4C5A;
            drawBox(ctx, proj, c.pos, col);
        }
    }

    private static void scanMobs(MinecraftClient mc, BaseFinder m) {
        long now = System.currentTimeMillis();
        if (now - lastMobScan < 400) return;
        lastMobScan = now;
        MOBS.clear();
        double r = m.range.value;
        for (Entity e : mc.world.getOtherEntities(mc.player, new net.minecraft.util.math.Box(
                mc.player.getX() - r, mc.player.getY() - r, mc.player.getZ() - r,
                mc.player.getX() + r, mc.player.getY() + r, mc.player.getZ() + r))) {
            if (isIndicatorMob(e)) MOBS.add(e);
            if (MOBS.size() >= 40) break;
        }
    }

    private static boolean isIndicatorMob(Entity e) {
        String cn = e.getClass().getSimpleName();
        if (cn.equals("VillagerEntity") || cn.equals("WanderingTraderEntity")
                || cn.equals("CatEntity") || cn.equals("ArmorStandEntity")
                || cn.equals("AllayEntity") || cn.equals("OcelotEntity")) return true;
        if (e instanceof net.minecraft.entity.passive.TameableEntity t && t.getOwner() != null) return true;
        return e.getCustomName() != null;
    }

    private static String mobLabel(Entity e) {
        String cn = e.getClass().getSimpleName();
        switch (cn) {
            case "VillagerEntity": return "Житель";
            case "WanderingTraderEntity": return "Торговец";
            case "CatEntity", "OcelotEntity": return "Кот";
            case "ArmorStandEntity": return "Стойка";
            case "AllayEntity": return "Эллей";
            default:
                if (e.getCustomName() != null) return e.getCustomName().getString();
                return e.getName().getString();
        }
    }

    private static void drawMobs(DrawContext ctx, MinecraftClient mc, BaseFinder m,
                                 EspRenderer.Projector proj) {
        if (!m.mobs.value || MOBS.isEmpty()) return;
        long now = System.currentTimeMillis();
        float pulse = 0.7f + 0.3f * (float) Math.sin(now / 260.0);
        for (Entity e : MOBS) {
            if (e.isRemoved()) continue;
            Vec3d pos = e.getEntityPos();
            float[] r = proj.cornerBox(pos, e.getWidth(), e.getHeight());
            if (r != null) {
                int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
                if (x2 - x1 >= 1 && y2 - y1 >= 1) {
                    int col = ((int) (220 * pulse) << 24) | 0x4CE0FF;
                    Draw.corners(ctx, x1, y1, x2, y2, col, false);
                }
            }
            float[] s = proj.project(pos.x, pos.y + e.getHeight() + 0.4, pos.z);
            if (s == null) continue;
            String label = mobLabel(e);
            int tw = mc.textRenderer.getWidth(label);
            int x = (int) s[0], y = (int) s[1];
            Draw.round(ctx, x - tw / 2 - 3, y - 6, x + tw / 2 + 3, y + 5, 2, 0xA0101018);
            ctx.drawText(mc.textRenderer, label, x - tw / 2, y - 4, 0xFF4CE0FF, false);
        }
    }

    private static void drawClusters(DrawContext ctx, MinecraftClient mc, BaseFinder m,
                                     EspRenderer.Projector proj) {
        Map<Long, int[]> clusters = new HashMap<>();
        for (Object[] o : FOUNDS.values()) {
            BlockPos pos = (BlockPos) o[0];
            long key = ChunkPos.toLong(pos.getX() >> 4, pos.getZ() >> 4);
            int[] c = clusters.computeIfAbsent(key, k -> new int[4]);
            c[0]++;
            c[1] += pos.getX();
            c[2] += pos.getY();
            c[3] += pos.getZ();
        }

        long now = System.currentTimeMillis();
        float pulse = 0.75f + 0.25f * (float) Math.sin(now / 300.0);
        for (int[] c : clusters.values()) {
            if (c[0] < m.minCount.asInt()) continue;
            double cx = (double) c[1] / c[0] + 0.5;
            double cy = (double) c[2] / c[0];
            double cz = (double) c[3] / c[0] + 0.5;
            float[] s = proj.project(cx, cy + 1.6, cz);
            if (s == null) continue;
            double d = mc.player.getEntityPos().distanceTo(new Vec3d(cx, cy, cz));
            String label = "База · " + c[0] + " бл. · " + (int) d + " м";
            int tw = mc.textRenderer.getWidth(label);
            int x = (int) s[0], y = (int) s[1];
            int col = (int) (255 * pulse) << 24 | 0xFF5A5A;
            Draw.round(ctx, x - tw / 2 - 4, y - 7, x + tw / 2 + 4, y + 6, 3, 0xB0141420);
            ctx.drawText(mc.textRenderer, label, x - tw / 2, y - 5, col, false);
        }
    }

    private static void scanChunk(MinecraftClient mc, BaseFinder m) {
        BlockPos self = mc.player.getBlockPos();
        if (scanCenter == null || scanCenter.getSquaredDistance(self) > 28 * 28) {
            scanCenter = self;
            scanIdx = 0;
        }
        int rr = m.range.asInt();
        int cr = Math.max(1, rr / 16 + 1);
        int side = cr * 2 + 1;
        int total = side * side;
        if (FOUNDS.size() >= m.maxMarks.asInt()) return;

        int cx0 = (self.getX() >> 4) - cr;
        int cz0 = (self.getZ() >> 4) - cr;
        int idx = scanIdx++ % total;
        int cx = cx0 + idx % side;
        int cz = cz0 + idx / side;
        WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
        if (chunk == null) return;

        ChunkSection[] sections = chunk.getSectionArray();
        if (sections == null) return;
        int bottomSection = mc.world.getBottomY() >> 4;
        double rSq = (double) rr * rr;
        int color = m.mode.is("MANUAL") ? 0xFFFF4DE8 : m.mode.is("MANMADE") ? 0xFFFF5A5A : 0xFFFFC04D;

        for (int si = 0; si < sections.length; si++) {
            ChunkSection sec = sections[si];
            if (sec == null || sec.isEmpty()) continue;
            int yBase = (bottomSection + si) * 16;
            for (int sy = 0; sy < 16; sy++) {
                int wy = yBase + sy;
                if (Math.abs(wy - self.getY()) > rr) continue;
                for (int x = 0; x < 16; x++) {
                    int wx = (cx << 4) + x;
                    if (Math.abs(wx - self.getX()) > rr + 1) continue;
                    for (int z = 0; z < 16; z++) {
                        int wz = (cz << 4) + z;
                        if (Math.abs(wz - self.getZ()) > rr + 1) continue;
                        var st = sec.getBlockState(x, sy, z);
                        if (!m.matches(st.getBlock())) continue;
                        BlockPos pos = new BlockPos(wx, wy, wz);
                        if (pos.getSquaredDistance(self) > rSq) continue;
                        FOUNDS.putIfAbsent(pos.asLong(), new Object[]{pos, color});
                        if (FOUNDS.size() >= m.maxMarks.asInt()) return;
                    }
                }
            }
        }
    }

    private static void clean(MinecraftClient mc, BaseFinder m) {
        long now = System.currentTimeMillis();
        if (now - lastClean < 1000) return;
        lastClean = now;
        BlockPos self = mc.player.getBlockPos();
        double rSq = (double) m.range.asInt() * m.range.asInt();
        FOUNDS.values().removeIf(o -> {
            BlockPos pos = (BlockPos) o[0];
            return pos.getSquaredDistance(self) > rSq
                    || !m.matches(mc.world.getBlockState(pos).getBlock());
        });
    }
}
