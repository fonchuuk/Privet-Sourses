package ru.duo.aura.core;

import java.util.HashMap;
import java.util.Map;

/** Перевод подписей в ClickGUI. Переключается модулем Interface. */
public class Lang {

    public static boolean russian = false;

    private static final Map<String, String> RU = new HashMap<>();

    static {
        // категории
        put("Sword", "Меч");
        put("Crystal", "Кристаллы");
        put("Optimizer", "Оптимизация");
        put("Farm", "Фермы");
        put("Client", "Клиент");
        put("Render", "Отрисовка");
        put("Misc", "Разное");

        // модули
        put("KillAura", "Килл-аура");
        put("TriggerBot", "Триггер-бот");
        put("AutoTotem", "Авто-тотем");
        put("ESP", "Подсветка");
        put("SeeInvis", "Видеть невидимых");
        put("Fullbright", "Яркость");
        put("HUD", "Интерфейс");
        put("AutoFarm", "Авто-ферма");
        put("AppleFarmer", "Фарм яблок");
        put("SandFarmer", "Фарм песка");
        put("Interface", "Настройки клиента");

        // общие настройки
        put("AutoCrystal", "Авто-кристалл");
        put("AutoHitCrystal", "Подрыв кристаллов");
        put("ShieldDisabler", "Сбив щита");
        put("FasterXP", "Быстрый опыт");
        put("Target range", "Радиус цели");
        put("Place range", "Радиус постановки");
        put("Break range", "Радиус подрыва");
        put("Min damage", "Мин. урон");
        put("Max self damage", "Макс. урон себе");
        put("Place", "Ставить");
        put("Break", "Взрывать");
        put("Throws per tick", "Бросков за тик");
        put("Only while holding use", "Только с зажатой ПКМ");
        put("Skip own placements", "Пропускать свежие");
        put("AimAssist", "Доводчик прицела");
        put("Strength", "Сила");
        put("Only while clicking", "Только при клике");
        put("FOV", "Угол обзора");
        put("модулей", "модулей");
        put("Бинд", "Бинд");
        put("Нажми клавишу для", "Нажми клавишу для");
        put("Style", "Стиль");
        put("Bottom line", "Нижняя строка");
        put("XRay", "Рентген");
        put("Freecam", "Свободная камера");
        put("Friends", "Друзья");
        put("InventoryMove", "Ходьба в инвентаре");
        put("Waypoints", "Метки");
        put("Ores", "Руды");
        put("Ancient debris", "Древние обломки");
        put("Portals", "Порталы");
        put("Lava/water", "Лава и вода");
        put("Force fullbright", "Включать яркость");
        put("Through blocks", "Сквозь блоки");
        put("Protect from aura", "Не бить друзей");
        put("Green in ESP", "Зелёные в ESP");
        put("Add by crosshair", "Добавлять по прицелу");
        put("Also in chat", "И в чате");
        put("Sneak", "Красться");
        put("Add here", "Поставить метку");
        put("Clear all", "Стереть все");
        put("Mark death", "Метка смерти");
        put("Max distance", "Макс. дистанция");
        put("Редактор HUD", "Редактор HUD");
        put("AutoHeal", "Авто-лечение");
        put("AutoShield", "Авто-щит");
        put("CreeperAlert", "Защита от крипперов");
        put("VeinMiner", "Копка жилы");
        put("TreeFarmer", "Лесоруб");
        put("AutoBreed", "Разведение животных");
        put("AutoShear", "Стрижка овец");
        put("Butcher", "Забой скота");
        put("AutoBoneMeal", "Костная мука");
        put("AutoTorch", "Авто-факелы");
        put("SafeWalk", "Безопасный шаг");
        put("HP below", "Лечиться при HP <");
        put("Golden apple", "Золотые яблоки");
        put("Potions", "Зелья");
        put("Mob range", "Радиус мобов");
        put("Block arrows", "Блокировать стрелы");
        put("Not while attacking", "Не при атаке");
        put("Warn in chat", "Писать в чат");
        put("Run away", "Отбегать");
        put("Pause KillAura", "Пауза килл-ауры");
        put("Any ore", "Любая руда");
        put("Also leaves", "И листву");
        put("Replant saplings", "Сажать саженцы");
        put("Keep babies", "Не трогать детёнышей");
        put("Keep breeding", "Не трогать влюблённых");
        put("Keep tamed", "Не трогать прирученных");
        put("Crops", "Посевы");
        put("Saplings", "Саженцы");
        put("Light below", "Свет ниже");
        put("Only on ground", "Только на земле");
        put("Silent rotations", "Тихий доворот");
        put("AntiAFK", "Анти-АФК");
        put("AutoEat", "Авто-еда");
        put("AutoArmor", "Авто-броня");
        put("InventoryCleaner", "Чистка инвентаря");
        put("AutoReconnect", "Авто-реконнект");
        put("AutoLogin", "Авто-вход");
        put("Spammer", "Автосообщения");
        put("AutoClicker", "Автокликер");
        put("NoFall", "Без урона с падения");
        put("AntiKnockback", "Анти-отбрасывание");
        put("SprintReset", "Сброс спринта");
        put("Step", "Шаг на блок");
        put("AutoWalk", "Авто-ходьба");
        put("FastBreak", "Быстрая копка");
        put("Nuker", "Нюкер");
        put("DeathCoords", "Координаты смерти");
        put("PlayerAlert", "Оповещение об игроках");
        put("ServerHud", "Инфо о сервере");
        put("AutoFish", "Авто-рыбалка");
        put("Scaffold", "Мост под ногами");
        put("Interval (sec)", "Интервал (сек)");
        put("Delay (sec)", "Задержка (сек)");
        put("Eat below", "Есть при голоде <");
        put("Or HP below", "Или при HP <");
        put("Restore slot", "Вернуть слот");
        put("Button", "Кнопка");
        put("Min CPS", "Мин. CPS");
        put("Max CPS", "Макс. CPS");
        put("Only while holding", "Только при зажатой");
        put("Min fall", "Мин. падение");
        put("Horizontal %", "Горизонталь %");
        put("Vertical %", "Вертикаль %");
        put("Off ticks", "Тиков без спринта");
        put("Height", "Высота");
        put("Packets per tick", "Пакетов за тик");
        put("Keep floor", "Не копать под собой");
        put("Only ores", "Только руда");
        put("Print to chat", "Писать в чат");
        put("Show on HUD", "Показывать на HUD");
        put("Notify on leave", "Сообщать об уходе");
        put("Players online", "Онлайн");
        put("Address", "Адрес");
        put("Auto cast", "Авто-заброс");
        put("Recast delay", "Задержка заброса");
        put("Auto switch", "Сам менять слот");
        put("Only when moving", "Только в движении");
        put("Random order", "Случайный порядок");
        put("Anti-spam suffix", "Суффикс от антиспама");
        put("Between (ticks)", "Между (тики)");
        put("Swing hand", "Махать рукой");
        put("Jump", "Прыгать");
        put("Rotate", "Крутить камеру");
        put("Sprint", "Спринт");
        put("Jump on wall", "Прыгать у стены");
        put("Rotten flesh", "Гниль и мусор");
        put("Seeds", "Семена");
        put("Dirt/cobble", "Земля/булыжник");
        put("Almost broken tools", "Сломанные инструменты");
        put("Only with closed GUI", "Только с закрытым GUI");
        put("Sound", "Звук");
        put("Utility", "Утилиты");
        put("NoHurtCam", "Без тряски урона");
        put("Zoom", "Зум");
        put("TimeChanger", "Время суток");
        put("WeatherChanger", "Погода");
        put("KeyStrokes", "Клавиши на экране");
        put("InfoHud", "Инфо-панель");
        put("ArmorHud", "Броня");
        put("TargetHud", "Карточка цели");
        put("Crosshair", "Прицел");
        put("Breadcrumbs", "След");
        put("StorageEsp", "Подсветка сундуков");
        put("AutoSprint", "Авто-спринт");
        put("AutoTool", "Авто-инструмент");
        put("ChestStealer", "Авто-сундук");
        put("AutoRespawn", "Авто-возрождение");
        put("Factor", "Кратность");
        put("Custom time", "Своё время");
        put("Weather", "Погода");
        put("Mouse keys", "Кнопки мыши");
        put("Space bar", "Пробел");
        put("Size", "Размер");
        put("Coords", "Координаты");
        put("Ping", "Пинг");
        put("Direction", "Сторона света");
        put("Nether coords", "Координаты ада");
        put("Corner", "Угол экрана");
        put("Durability", "Прочность");
        put("Main hand", "Предмет в руке");
        put("Offset Y", "Отступ Y");
        put("Health bar", "Полоса здоровья");
        put("Distance", "Дистанция до цели");
        put("Style", "Стиль");
        put("Gap", "Зазор");
        put("Length", "Длина");
        put("Thickness", "Толщина");
        put("Accent color", "Цвет акцента");
        put("Points", "Точек");
        put("Every ticks", "Раз в N тиков");
        put("Chests", "Сундуки");
        put("Barrels", "Бочки");
        put("Shulkers", "Шалкеры");
        put("Hoppers", "Воронки");
        put("Furnaces", "Печи");
        put("Spawners", "Спавнеры");
        put("Only while mining", "Только при копке");
        put("Save low durability", "Беречь инструменты");
        put("Min durability", "Мин. прочность");
        put("Close when done", "Закрывать сундук");
        put("Shulker boxes", "Шалкеры");
        put("Even when hungry", "Даже голодным");
        put("Smooth camera", "Плавная камера");
        put("No shake", "Без тряски");
        put("Активно", "Активно");
        put("Reveal models", "Показывать модели");
        put("Debug chat", "Отладка в чат");
        put("SILENT", "ТИХИЙ");
        put("Reach", "Дистанция");
        put("Targets", "Целей за удар");
        put("Delay (ticks)", "Задержка (тики)");
        put("Crits", "Криты");
        put("Unsprint", "Гасить спринт");
        put("Vanilla cooldown", "Ждать перезарядку");
        put("Rotations", "Поворот камеры");
        put("Rot speed", "Скорость поворота");
        put("Hit only when aimed", "Бить только при наводке");
        put("Lock target", "Держать одну цель");
        put("Switch delay", "Задержка смены цели");
        put("Sort", "Приоритет цели");
        put("Mobs", "Мобы");
        put("Animals", "Животные");
        put("Players", "Игроки");
        put("Items", "Предметы");
        put("Through walls", "Сквозь стены");
        put("Rotate", "Поворачиваться");
        put("Health", "Здоровье");

        // ESP / HUD
        put("Boxes", "Рамки");
        put("Tracers", "Трассеры");
        put("Target marker", "Метка цели");
        put("Health bar", "Полоска HP");
        put("Names", "Имена");
        put("Range", "Дальность");
        put("Watermark", "Логотип");
        put("ArrayList", "Список модулей");
        put("Target info", "Инфо о цели");
        put("Coords + FPS", "Координаты и ФПС");
        put("Rainbow", "Радуга");
        put("Glow outline", "Светящийся контур");

        // фермы
        put("Radius", "Радиус");
        put("Height", "Высота");
        put("Replant", "Сажать заново");
        put("Crops", "Посевы");
        put("Nether wart", "Адский нарост");
        put("Melon/Pumpkin", "Арбузы и тыквы");
        put("Sugar cane", "Тростник");
        put("Oak only", "Только дуб");
        put("Log too", "Ломать и брёвна");
        put("Sand", "Песок");
        put("Red sand", "Красный песок");
        put("Gravel", "Гравий");
        put("Auto shovel", "Авто-лопата");
        put("Auto tool", "Авто-инструмент");
        put("Auto walk", "Ходить к блокам");
        put("Leaves", "Листва");
        put("Logs", "Брёвна");
        put("Box mode", "Тип рамки");
        put("Mode", "Режим");
        put("Gamma", "Гамма");

        // интерфейс
        put("Language", "Язык");
        put("Accent", "Акцент");
        put("Theme", "Тема");
        put("Leaves by hand", "Листву рукой");
        put("Chat feedback", "Сообщения в чат");
        put("Bind: ", "Клавиша: ");
        put("Категории клиентов", "Категории клиентов");
        put("Все", "Все");
        put("Настройки", "Настройки");
        put("Конфигурации", "Конфигурации");
        put("Друзья", "Друзья");
        put("Путевые точки", "Путевые точки");
        put("Поиск", "Поиск");
        put("Горячая клавиша", "Горячая клавиша");
        put("Нажмите, затем выберите клавишу", "Нажмите, затем выберите клавишу");
        put("Акцентный цвет", "Акцентный цвет");
        put("Цвет интерфейса, обводок и HUD", "Цвет интерфейса, обводок и HUD");
        put("Нажми клавишу для", "Нажми клавишу для");
        put("Категории", "Категории");
        put("Клавиша", "Клавиша");
        put("Сохранить конфиг", "Сохранить конфиг");
        put("Сохранить", "Сохранить");
        put("Загрузить конфиг", "Загрузить конфиг");
        put("Загрузить", "Загрузить");
        put("Перечитать файл с диска", "Перечитать файл с диска");
        put("Сбросить настройки", "Сбросить настройки");
        put("Выключить все модули", "Выключить все модули");
        put("Сброс", "Сброс");
        put("Состояние", "Состояние");
        put("включено", "включено");
        put("модулей", "модулей");
        put("Добавить по прицелу", "Добавить по прицелу");
        put("Наведись на игрока и нажми клавишу модуля Friends", "Наведись на игрока и нажми клавишу модуля Friends");
        put("Список пуст", "Список пуст");
        put("Не трогает аура", "Не трогает аура");
        put("Удалить", "Удалить");
        put("удалён", "удалён");
        put("Поставить здесь", "Поставить здесь");
        put("Метка в текущей точке", "Метка в текущей точке");
        put("Добавить", "Добавить");
        put("Очистить все", "Очистить все");
        put("Очистить", "Очистить");
        put("меток", "меток");
        put("Метка поставлена", "Метка поставлена");
        put("Метки стёрты", "Метки стёрты");
        put("Конфиг сохранён", "Конфиг сохранён");
        put("Конфиг загружен", "Конфиг загружен");
        put("Все модули выключены", "Все модули выключены");
        put("Fill", "Заливка");
        put("Tracer width", "Толщина трассера");
        put("Max tracers", "Максимум трассеров");
        put("Logo in watermark", "Логотип в ватермарке");
        put("Logo size", "Размер логотипа");
        put("GUI font", "Шрифт интерфейса");
        put("VANILLA", "Ванильный");
        put("CUSTOM", "Свой");
        put("Smoothness", "Плавность");
        put("Max step", "Макс. шаг за тик");
        put("Deadzone", "Мёртвая зона");
        put("Assist pitch", "Вести и по вертикали");
        put("Reaction min (ms)", "Реакция мин. (мс)");
        put("Reaction max (ms)", "Реакция макс. (мс)");
        put("Line of sight", "Не бить сквозь блоки");
        put("Max range", "Макс. дистанция");
        put("Weapon only", "Только с оружием");
        put("ANY", "Любой предмет");
        put("SWORD", "Только меч");
        put("SWORD+AXE", "Меч или топор");
        put("ANY WEAPON", "Любое оружие");
        put("Wall reach", "Радиус сквозь стены");
        put("Delay jitter", "Разброс паузы");
        put("Min charge", "Мин. заряд удара");
        put("Aim tolerance", "Допуск прицела");
        put("Invisible targets", "Невидимые цели");
        put("Armor stands", "Стойки для брони");
        put("Pause in GUI", "Пауза в меню");
        put("Pause while using item", "Пауза при использовании предмета");
        put("Panic", "Паника");
        put("Выключает все модули одной клавишей", "Выключает все модули одной клавишей");
        put("Keep HUD", "Оставить HUD");
        put("Keep visuals", "Оставить визуалы");
        put("Chat message", "Сообщение в чат");
        put("ClickGUI", "Меню клиента");
        put("Клавиша открытия меню клиента", "Клавиша открытия меню клиента");
        put("Open HUD editor instead", "Открывать редактор HUD");
        put("Клавиши", "Клавиши");
        put("Нажми клавишу", "Жми кнопку");
        put("Открывает меню клиента", "Открывает меню клиента");
        put("NONE", "НЕТ");

        // меню по макету specclient_menu.html
        put("Import", "Импорт");
        put("Export", "Экспорт");
        put("Search modules...", "Поиск модулей...");
        put("Key", "Клавиша");
        put("Press a key", "Жми кнопку");
        put("Binds", "Клавиши");
        put("Configs", "Конфигурации");
        put("Esc — back", "Esc — назад");
    }

    private static void put(String en, String ru) {
        RU.put(en, ru);
    }

    public static String t(String en) {
        if (!russian) return en;
        return RU.getOrDefault(en, en);
    }

    public static String hint() {
        return russian
                ? "ЛКМ — вкл/выкл  |  ПКМ — настройки  |  Клавиша: клик, затем кнопка (Esc — снять)"
                : "LMB — toggle  |  RMB — settings  |  Bind: click, then press a key (Esc — clear)";
    }

    /** Подпись под меню — как в макете specclient_menu.html. */
    public static String menuHint() {
        return russian
                ? "ЛКМ — вкл/выкл модуль · ПКМ — настройки · Esc — закрыть"
                : "LMB — toggle module · RMB — settings · Esc — close";
    }
}
