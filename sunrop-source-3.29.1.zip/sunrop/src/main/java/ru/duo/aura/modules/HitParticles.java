package ru.duo.aura.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

import java.util.HashMap;
import java.util.Map;

public class HitParticles extends Module {

    public final Setting.Mode style = add(new Setting.Mode("Style", 0,
            "CRIT", "MAGIC", "SPARK", "HEART"));
    public final Setting.Num count = add(new Setting.Num("Count", 6, 1, 20, 1));
    public final Setting.Num range = add(new Setting.Num("Range", 16, 4, 48, 1));

    private final Map<Integer, Integer> hurt = new HashMap<>();

    public HitParticles() {
        super("HitParticles", "Красивые частицы при попадании", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null) return;

        for (Entity e : mc.world.getOtherEntities(p, p.getBoundingBox().expand(range.value))) {
            if (!(e instanceof LivingEntity le)) continue;
            int prev = hurt.getOrDefault(le.getId(), 0);
            if (le.hurtTime == 9 && prev != 9) {
                spawn(le);
            }
            hurt.put(le.getId(), le.hurtTime);
        }
    }

    private void spawn(LivingEntity le) {
        var type = switch (style.get()) {
            case "MAGIC" -> ParticleTypes.ENCHANT;
            case "SPARK" -> ParticleTypes.ELECTRIC_SPARK;
            case "HEART" -> ParticleTypes.HEART;
            default -> ParticleTypes.CRIT;
        };
        int n = count.asInt();
        for (int i = 0; i < n; i++) {
            mc.particleManager.addParticle(type,
                    le.getX() + (Math.random() - 0.5) * le.getWidth(),
                    le.getY() + le.getHeight() * (0.3 + Math.random() * 0.6),
                    le.getZ() + (Math.random() - 0.5) * le.getWidth(),
                    (Math.random() - 0.5) * 0.12,
                    Math.random() * 0.12,
                    (Math.random() - 0.5) * 0.12);
        }
    }

    @Override
    public void onDisable() {
        hurt.clear();
    }
}
