package ru.duo.aura.modules;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Мгновенное ускорение игры: видео-настройки снижаются, при выключении восстанавливаются. */
public class GameOptimizer extends Module {

    public final Setting.Num viewDist = add(new Setting.Num("Max render distance", 8, 4, 16, 1));
    public final Setting.Bool fastGraphics = add(new Setting.Bool("Fast graphics", true));
    public final Setting.Bool clouds = add(new Setting.Bool("Disable clouds", true));
    public final Setting.Bool shadows = add(new Setting.Bool("Disable entity shadows", true));
    public final Setting.Bool particles = add(new Setting.Bool("Minimal particles", true));
    public final Setting.Bool ao = add(new Setting.Bool("Disable smooth lighting", true));
    public final Setting.Bool biome = add(new Setting.Bool("No biome blend", true));
    public final Setting.Bool entityDist = add(new Setting.Bool("Closer entity render", true));

    private Integer oldView;
    private GraphicsMode oldGraphics;
    private CloudRenderMode oldClouds;
    private Boolean oldShadows;
    private ParticlesMode oldParticles;
    private Boolean oldAo;
    private Integer oldBiome;
    private Double oldEntityDist;

    public GameOptimizer() {
        super("Optimizer", "Ускорение игры: графика/частицы/дальность", Category.CLIENT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onEnable() {
        var o = mc.options;
        if (oldView != null) return;
        oldView = o.getViewDistance().getValue();
        if (viewDist.value < oldView) o.getViewDistance().setValue((int) viewDist.value);

        if (fastGraphics.value && oldGraphics == null) {
            oldGraphics = o.getPreset().getValue();
            o.getPreset().setValue(GraphicsMode.FAST);
        }
        if (clouds.value && oldClouds == null) {
            oldClouds = o.getCloudRenderMode().getValue();
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        }
        if (shadows.value && oldShadows == null) {
            oldShadows = o.getEntityShadows().getValue();
            o.getEntityShadows().setValue(false);
        }
        if (particles.value && oldParticles == null) {
            oldParticles = o.getParticles().getValue();
            o.getParticles().setValue(ParticlesMode.MINIMAL);
        }
        if (ao.value && oldAo == null) {
            oldAo = o.getAo().getValue();
            o.getAo().setValue(false);
        }
        if (biome.value && oldBiome == null) {
            oldBiome = o.getBiomeBlendRadius().getValue();
            o.getBiomeBlendRadius().setValue(0);
        }
        if (entityDist.value && oldEntityDist == null) {
            oldEntityDist = o.getEntityDistanceScaling().getValue();
            o.getEntityDistanceScaling().setValue(0.5);
        }
    }

    @Override
    public void onDisable() {
        var o = mc.options;
        if (oldView != null) { o.getViewDistance().setValue(oldView); oldView = null; }
        if (oldGraphics != null) { o.getPreset().setValue(oldGraphics); oldGraphics = null; }
        if (oldClouds != null) { o.getCloudRenderMode().setValue(oldClouds); oldClouds = null; }
        if (oldShadows != null) { o.getEntityShadows().setValue(oldShadows); oldShadows = null; }
        if (oldParticles != null) { o.getParticles().setValue(oldParticles); oldParticles = null; }
        if (oldAo != null) { o.getAo().setValue(oldAo); oldAo = null; }
        if (oldBiome != null) { o.getBiomeBlendRadius().setValue(oldBiome); oldBiome = null; }
        if (oldEntityDist != null) { o.getEntityDistanceScaling().setValue(oldEntityDist); oldEntityDist = null; }
    }
}
