package ru.duo.aura.modules;

import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

import java.util.HashMap;
import java.util.Map;

public final class FTHelper extends Module {

    public final Setting.Mode mode = add(new Setting.Mode("Mode", 1, "SILENT", "VISIBLE"));
    public final Setting.Num show = add(new Setting.Num("Show (ticks)", 1, 1, 6, 1));
    public final Setting.Key pearl = add(new Setting.Key("Key: Pearl", GLFW.GLFW_KEY_UNKNOWN));
    public final Setting.Key trap = add(new Setting.Key("Key: Trap", GLFW.GLFW_KEY_UNKNOWN));
    public final Setting.Key disorient = add(new Setting.Key("Key: Disorient", GLFW.GLFW_KEY_UNKNOWN));
    public final Setting.Key sugar = add(new Setting.Key("Key: Sugar", GLFW.GLFW_KEY_UNKNOWN));
    public final Setting.Key fireball = add(new Setting.Key("Key: Fireball", GLFW.GLFW_KEY_UNKNOWN));
    public final Setting.Key freeze = add(new Setting.Key("Key: Freeze", GLFW.GLFW_KEY_UNKNOWN));

    private final Map<Integer, Boolean> down = new HashMap<>();

    public FTHelper() {
        super("FTHelper", "Предметы FunTime по клавишам", Category.SWORD, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        check(pearl.value, Items.ENDER_PEARL, "Перка");
        check(trap.value, Items.NETHERITE_SCRAP, "Трапка");
        check(disorient.value, Items.ENDER_EYE, "Дезориентация");
        check(sugar.value, Items.SUGAR, "Явная пыль");
        check(fireball.value, Items.FIRE_CHARGE, "Огненный шар");
        check(freeze.value, Items.SNOWBALL, "Заморозка");
    }

    private void check(int key, Item item, String label) {
        if (key == 0 || key == -1 || key == GLFW.GLFW_KEY_UNKNOWN) return;
        boolean pressed = InputUtil.isKeyPressed(mc.getWindow(), key);
        Boolean was = down.get(key);
        if (pressed && !Boolean.TRUE.equals(was)) {
            FTItems.use(item, label, mode.is("VISIBLE") ? show.asInt() : 0);
        }
        down.put(key, pressed);
    }

    @Override
    public void onDisable() { down.clear(); }

    @Override
    public String hudSuffix() { return " §7[" + bound() + "]"; }

    private int bound() {
        int n = 0;
        for (Setting.Key k : new Setting.Key[]{pearl, trap, disorient, sugar, fireball, freeze}) {
            if (k.value != 0 && k.value != -1 && k.value != GLFW.GLFW_KEY_UNKNOWN) n++;
        }
        return n;
    }
}
