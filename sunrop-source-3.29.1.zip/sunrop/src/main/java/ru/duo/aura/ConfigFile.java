package ru.duo.aura;

import net.fabricmc.loader.api.FabricLoader;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.HudLayout;
import ru.duo.aura.core.Setting;
import ru.duo.aura.modules.StorageEsp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Сохранение модулей/настроек/биндов в .minecraft/config/sunrop[-имя].txt */
public class ConfigFile {

    private static Path path() {
        return path(null);
    }

    private static Path path(String name) {
        Path dir = FabricLoader.getInstance().getConfigDir();
        if (name == null || name.isEmpty()) return dir.resolve("sunrop.txt");
        return dir.resolve(fileName(name));
    }

    public static String fileName(String name) {
        if (name == null || name.isEmpty()) return "sunrop.txt";
        return "sunrop-" + name.toLowerCase().replaceAll("[^a-z0-9_-]", "") + ".txt";
    }

    public static boolean exists(String name) {
        return Files.exists(path(name));
    }

    public static String dir() {
        return FabricLoader.getInstance().getConfigDir().toString();
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(FabricLoader.getInstance().getConfigDir())) {
            s.filter(p -> p.getFileName().toString().startsWith("sunrop")
                            && p.getFileName().toString().endsWith(".txt"))
                    .sorted()
                    .forEach(p -> out.add(p.getFileName().toString()));
        } catch (IOException ignored) {}
        return out;
    }

    public static void reset() {
        try {
            Files.deleteIfExists(path());
        } catch (IOException ignored) {}
        HudLayout.reset();
        ModuleManager.init();
        ru.specclient.module.ModuleManager.rebuild();
        save();
    }

    public static void save() {
        save(null);
    }

    public static void save(String name) {
        List<String> lines = new ArrayList<>();
        lines.add("# Sunrop config — правится и руками, но проще через ClickGUI");
        for (Module m : ModuleManager.MODULES) {
            lines.add(m.name + ".enabled=" + m.isEnabled());
            lines.add(m.name + ".key=" + m.key);
            for (Setting s : m.settings) {
                lines.add(m.name + "." + s.name + "=" + s.serialize());
            }
        }
        lines.add("blockesp.custom=" + StorageEsp.serializeCustom());
        lines.add("basefinder.custom=" + ru.duo.aura.modules.BaseFinder.serializeManual());
        lines.addAll(HudLayout.serialize());
        try {
            Files.createDirectories(path(name).getParent());
            Files.write(path(name), lines);
        } catch (IOException e) {
            System.err.println("[Sunrop] не смог сохранить конфиг: " + e.getMessage());
        }
    }

    public static void load() {
        load(null);
    }

    public static void load(String name) {
        Path p = path(name);
        if (!Files.exists(p)) return;
        try {
            for (String line : Files.readAllLines(p)) {
                String s = line.trim();
                if (s.isEmpty() || s.startsWith("#")) continue;
                int eq = s.indexOf('=');
                int dot = s.indexOf('.');
                if (eq < 0 || dot < 0 || dot > eq) continue;

                String modName = s.substring(0, dot);
                String key = s.substring(dot + 1, eq);
                String value = s.substring(eq + 1);

                if (modName.equals("hud")) { HudLayout.deserialize(key, value); continue; }
                if (modName.equals("blockesp")) {
                    if (key.equals("custom")) StorageEsp.deserializeCustom(value);
                    continue;
                }
                if (modName.equals("basefinder")) {
                    if (key.equals("custom")) ru.duo.aura.modules.BaseFinder.deserializeManual(value);
                    continue;
                }

                Module m = ModuleManager.byName(modName);
                if (m == null) continue;

                if (key.equals("enabled")) {
                    m.setEnabled(Boolean.parseBoolean(value));
                } else if (key.equals("key")) {
                    try {
                        int k = Integer.parseInt(value);
                        if (m == ru.duo.aura.core.ModuleManager.guiBind
                                && k == org.lwjgl.glfw.GLFW.GLFW_KEY_GRAVE_ACCENT) {
                            k = org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT;
                        }
                        m.key = k;
                    } catch (NumberFormatException ignored) {}
                } else {
                    for (Setting st : m.settings) {
                        if (st.name.equals(key)) { st.deserialize(value); break; }
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("[Sunrop] не смог прочитать конфиг: " + e.getMessage());
        }
    }
}
