package ru.duo.aura.modules;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * BaseFinder в духе VelkaDLC/Wurst:
 * SAFE — только «невозможные» блоки; ALL — всё рукотворное;
 * MANMADE — как в Wurst: всё, кроме природных блоков (инвертированный список);
 * MANUAL — «особенные блоки» (свои через .basefinder add).
 * Плюс детект мобов-индикаторов (жители, коты, стойки, питомцы) и
 * трекинг недавних изменений (кто-то ставил/ломал блоки рядом).
 */
public class BaseFinder extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 64, 16, 128, 1));
    public final Setting.Num minCount = add(new Setting.Num("Min blocks", 6, 1, 64, 1));
    public final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "SAFE", "ALL", "MANMADE", "MANUAL"));
    public final Setting.Bool highlight = add(new Setting.Bool("Highlight", true));
    public final Setting.Bool labels = add(new Setting.Bool("Base labels", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mob detect", true));
    public final Setting.Bool track = add(new Setting.Bool("Track changes", true));
    public final Setting.Num trackTime = add(new Setting.Num("Track time (s)", 60, 10, 600, 10));
    public final Setting.Num maxMarks = add(new Setting.Num("Max marks", 220, 20, 600, 10));

    public static final Set<Block> SAFE = new LinkedHashSet<>();
    public static final Set<Block> ALL = new LinkedHashSet<>();
    public static final Set<Block> NATURAL = new LinkedHashSet<>();
    public static final Map<Block, Integer> MANUAL = new LinkedHashMap<>();

    static {
        Set<String> safeIds = new HashSet<>(List.of(
                "coal_block", "iron_block", "gold_block", "diamond_block", "emerald_block",
                "lapis_block", "redstone_block", "netherite_block", "beacon", "tnt",
                "slime_block", "honey_block", "jukebox", "note_block", "crafting_table",
                "enchanting_table", "ender_chest", "lodestone", "respawn_anchor",
                "scaffolding", "target", "dropper", "daylight_detector", "observer",
                "iron_bars", "chain", "lantern", "soul_lantern"));

        Set<String> naturalIds = new HashSet<>(List.of(
                "air", "cave_air", "void_air", "water", "lava", "stone", "granite", "diorite",
                "andesite", "deepslate", "tuff", "calcite", "dripstone_block", "pointed_dripstone",
                "dirt", "grass_block", "podzol", "coarse_dirt", "rooted_dirt", "mud", "clay",
                "gravel", "sand", "red_sand", "sandstone", "red_sandstone", "suspicious_sand",
                "suspicious_gravel", "snow", "snow_block", "powder_snow", "ice", "packed_ice",
                "blue_ice", "frosted_ice", "moss_block", "moss_carpet", "mycelium",
                "netherrack", "soul_sand", "soul_soil", "basalt", "smooth_basalt", "blackstone",
                "magma_block", "glowstone", "nether_wart_block", "warped_wart_block",
                "shroomlight", "crimson_nylium", "warped_nylium", "crimson_stem", "warped_stem",
                "end_stone", "obsidian", "crying_obsidian", "bedrock",
                "amethyst_block", "budding_amethyst", "amethyst_cluster", "small_amethyst_bud",
                "medium_amethyst_bud", "large_amethyst_bud",
                "sculk", "sculk_catalyst", "sculk_shrieker", "sculk_sensor", "sculk_vein",
                "prismarine", "prismarine_bricks", "dark_prismarine", "sea_lantern",
                "purpur_block", "purpur_pillar", "end_stone_bricks",
                "nether_bricks", "red_nether_bricks", "cracked_nether_bricks", "chiseled_nether_bricks",
                "polished_blackstone", "polished_blackstone_bricks", "gilded_blackstone",
                "chiseled_deepslate", "polished_deepslate", "deepslate_bricks", "deepslate_tiles",
                "cracked_deepslate_bricks", "cracked_deepslate_tiles",
                "short_grass", "tall_grass", "fern", "large_fern", "dead_bush", "seagrass",
                "tall_seagrass", "kelp", "kelp_plant", "vine", "glow_lichen", "lily_pad",
                "sugar_cane", "cactus", "bamboo", "pumpkin", "melon", "brown_mushroom",
                "red_mushroom", "brown_mushroom_block", "red_mushroom_block", "mushroom_stem",
                "crimson_fungus", "warped_fungus", "nether_sprouts", "weeping_vines",
                "weeping_vines_plant", "twisting_vines", "twisting_vines_plant",
                "cave_vines", "cave_vines_plant", "spore_blossom", "hanging_roots",
                "big_dripleaf", "small_dripleaf", "cobweb", "farmland",
                "dandelion", "poppy", "blue_orchid", "allium", "azure_bluet", "red_tulip",
                "orange_tulip", "white_tulip", "pink_tulip", "oxeye_daisy", "cornflower",
                "lily_of_the_valley", "wither_rose", "sunflower", "lilac", "rose_bush", "peony",
                "torchflower", "pitcher_plant", "closed_eyeblossom", "open_eyeblossom",
                "pale_hanging_moss", "pale_moss_block", "pale_moss_carpet",
                "infested_stone", "infested_cobblestone", "infested_stone_bricks",
                "infested_mossy_stone_bricks", "infested_cracked_stone_bricks",
                "infested_chiseled_stone_bricks", "infested_deepslate", "budding_amethyst",
                "spawner", "trial_spawner", "vault"));

        Set<String> allExtra = new HashSet<>(List.of(
                "glass", "bricks", "bookshelf", "furnace", "chest", "trapped_chest", "barrel",
                "brewing_stand", "hopper", "anvil", "chipped_anvil", "damaged_anvil",
                "dispenser", "piston", "sticky_piston", "crafting_table"));

        for (Block b : Registries.BLOCK) {
            String p = Registries.BLOCK.getId(b).getPath();
            if (safeIds.contains(p)) SAFE.add(b);
            if (naturalIds.contains(p)
                    || p.endsWith("_log") || p.endsWith("_wood") || p.endsWith("_leaves")
                    || p.endsWith("_stem") || p.endsWith("_nylium") || p.endsWith("_ore")
                    || p.endsWith("_terracotta") || p.endsWith("_coral_block")
                    || p.endsWith("_coral") || p.endsWith("_coral_fan")
                    || p.endsWith("_sandstone") || p.endsWith("_sapling") || p.endsWith("_flower")
                    || p.endsWith("_infested")) {
                NATURAL.add(b);
            }
            if (allExtra.contains(p) || p.endsWith("_planks") || p.endsWith("_wool")
                    || p.endsWith("_concrete") || p.endsWith("_concrete_powder")
                    || p.endsWith("_stained_glass") || p.endsWith("_glazed_terracotta")
                    || p.endsWith("_carpet")) {
                ALL.add(b);
            }
        }
        ALL.addAll(SAFE);
        NATURAL.add(Blocks.AIR);

        for (String id : List.of("spawner", "trial_spawner", "vault", "ender_chest", "beacon",
                "enchanting_table", "anvil", "chest", "trapped_chest", "barrel", "brewing_stand",
                "shulker_box", "netherite_block", "diamond_block", "emerald_block", "tnt")) {
            Block b = Registries.BLOCK.get(Identifier.of("minecraft", id));
            if (b == Blocks.AIR) continue;
            MANUAL.put(b, switch (id) {
                case "spawner", "trial_spawner", "vault" -> 0xFF4DFFC4;
                case "ender_chest", "beacon" -> 0xFFB84DFF;
                case "netherite_block", "diamond_block", "emerald_block" -> 0xFFFFD700;
                case "tnt" -> 0xFFFF4D5A;
                default -> 0xFFFFC04D;
            });
        }
    }

    public BaseFinder() {
        super("BaseFinder", "Ищет игрокские базы: блоки, мобы, изменения", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    public boolean matches(Block b) {
        switch (mode.get()) {
            case "ALL": return ALL.contains(b);
            case "MANMADE": return !NATURAL.contains(b);
            case "MANUAL": return MANUAL.containsKey(b);
            default: return SAFE.contains(b);
        }
    }

    public static void addManual(Block b, int color) { MANUAL.put(b, color); }
    public static void removeManual(Block b) { MANUAL.remove(b); }
    public static void clearManual() { MANUAL.clear(); }

    public static String blockName(Block b) {
        var id = Registries.BLOCK.getId(b);
        return id == null ? "?" : id.getPath();
    }

    public static Block parseBlock(String s) {
        String n = s.toLowerCase(Locale.ROOT).replace("minecraft:", "").replace(' ', '_');
        switch (n) {
            case "spawner", "mob_spawner", "monster_spawner" -> n = "spawner";
            case "trap", "trapped", "trappedchest" -> n = "trapped_chest";
            case "brewing", "brew", "stand" -> n = "brewing_stand";
            case "shulker", "shulkerbox" -> n = "shulker_box";
            default -> { }
        }
        Block b = Registries.BLOCK.get(Identifier.of("minecraft", n));
        return b == Blocks.AIR && !n.equals("air") ? null : b;
    }

    public static String serializeManual() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Block, Integer> e : MANUAL.entrySet()) {
            if (sb.length() > 0) sb.append(";");
            sb.append(blockName(e.getKey())).append(":")
                    .append(String.format("#%06X", e.getValue() & 0xFFFFFF));
        }
        return sb.toString();
    }

    public static void deserializeManual(String s) {
        MANUAL.clear();
        if (s == null || s.isEmpty() || s.equals("-")) return;
        for (String part : s.split(";")) {
            int i = part.lastIndexOf(':');
            if (i <= 0) continue;
            Block b = parseBlock(part.substring(0, i));
            if (b == null) continue;
            try {
                String cs = part.substring(i + 1);
                int c = cs.startsWith("#")
                        ? (int) (Long.parseLong(cs.substring(1), 16) | 0xFF000000L)
                        : (int) (Long.parseLong(cs) | 0xFF000000L);
                MANUAL.put(b, c);
            } catch (NumberFormatException ignored) {}
        }
    }
}
