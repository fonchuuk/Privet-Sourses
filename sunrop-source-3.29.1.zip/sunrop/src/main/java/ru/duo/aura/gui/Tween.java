package ru.duo.aura.gui;

public final class Tween {
    private float value;
    private float target;
    private final float speed;

    public Tween(float v) { this(v, 14f); }

    public Tween(float v, float speed) {
        this.value = v;
        this.target = v;
        this.speed = speed;
    }

    public void set(float t) { this.target = t; }

    public void snap(float v) { this.value = v; this.target = v; }

    public float get() { return this.value; }

    public float getTarget() { return this.target; }

    public void update(float dt) {
        if (dt <= 0f) return;
        float f = 1f - (float) Math.exp(-this.speed * Math.min(dt, 0.2f));
        this.value += (this.target - this.value) * f;
        if (Math.abs(this.target - this.value) < 8e-4f) this.value = this.target;
    }

    public static float easeOutCubic(float t) {
        float u = 1f - clamp01(t);
        return 1f - u * u * u;
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }
}
