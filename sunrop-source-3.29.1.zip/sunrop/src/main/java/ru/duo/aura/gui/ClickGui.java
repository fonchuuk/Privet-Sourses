package ru.duo.aura.gui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.ConfigFile;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Friends;
import ru.duo.aura.core.Lang;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.Setting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class ClickGui extends Screen {

    private static final float PAD_X = 22f;
    private static final float HEADER_H = 88f;
    private static final float FOOTER_H = 52f;
    private static final float CARD_H = 22f;
    private static final float CARD_GAP = 6.5f;
    private static final float RADIUS = 9f;
    private static final float TOGGLE_W = 20f;
    private static final float TOGGLE_H = 10f;

    private float panelX, panelY, panelW, panelH;
    private float contentTop, contentBottom, colPitch, cardW;
    private float searchX, searchY, searchW, searchH;
    private float importX, importW, exportX, exportW, langX, langW;
    private float btnY, btnH;

    private final Tween openAnim = new Tween(0f, 12f);
    private boolean closing;
    private float time, dt;
    private long lastFrame;

    private String query = "";
    private boolean searchFocused;
    private final Tween searchAnim = new Tween(0f, 16f);

    private final Tween[] scrollAnim = new Tween[Category.values().length];
    private final float[] scrollTarget = new float[Category.values().length];
    private final float[] contentH = new float[Category.values().length];

    private final Tween importHover = new Tween(0f, 17f);
    private final Tween exportHover = new Tween(0f, 17f);
    private final Tween langSlide = new Tween(0f, 17f);

    private Setting.Num dragging;
    private float dragTrackX, dragTrackW;

    private String toastText = "";
    private float toastLife;
    private final Tween toastAnim = new Tween(0f, 14f);

    private int mouseX, mouseY;
    private final List<CardRect> cards = new ArrayList<>();

    private Module binding;
    private Page page = Page.MODULES;

    private enum Page { MODULES, BINDS, FRIENDS }

    private static final class CardRect {
        final Module module;
        final int col;
        final float x, y, w, h;
        CardRect(Module module, int col, float x, float y, float w, float h) {
            this.module = module; this.col = col; this.x = x; this.y = y; this.w = w; this.h = h;
        }
    }

    public ClickGui() {
        super(Text.literal("Sunrop"));
        for (int i = 0; i < scrollAnim.length; i++) scrollAnim[i] = new Tween(0f, 15f);
    }

    private static String tr(String en, String ruTxt) {
        return Lang.russian ? ruTxt : en;
    }

    @Override
    protected void init() {
        this.lastFrame = 0L;
        this.openAnim.set(1f);
        this.langSlide.snap(Lang.russian ? 1f : 0f);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        if (!this.closing) {
            this.closing = true;
            this.openAnim.set(0f);
            this.searchFocused = false;
            ConfigFile.save();
        }
    }

    private void tickTime() {
        long now = System.nanoTime();
        if (this.lastFrame == 0L) this.lastFrame = now;
        this.dt = Math.min(0.1f, (float) (now - this.lastFrame) / 1.0E9f);
        this.lastFrame = now;
        this.time += this.dt;
    }

    private List<Module> visible(Category category) {
        ArrayList<Module> out = new ArrayList<>();
        String q = this.query.trim().toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.MODULES) {
            if (m.category != category) continue;
            if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(m);
        }
        return out;
    }

    private float settingH(Setting s) {
        if (s instanceof Setting.Bool) return 9f;
        if (s instanceof Setting.Num) return 18f;
        return 23f;
    }

    private float settingsHeight(Module m) {
        if (m.settings.isEmpty()) return 0f;
        float h = 4f;
        for (Setting s : m.settings) h += settingH(s) + 6f;
        return h + 16f;
    }

    private void layout() {
        this.panelW = clamp(this.width * 0.92f, 300f, 900f);
        this.panelH = clamp(this.height * 0.86f, 196f, 350f);
        this.panelX = Math.round((this.width - this.panelW) * 0.5f);
        this.panelY = Math.round((this.height - this.panelH) * 0.5f);
        this.contentTop = this.panelY + HEADER_H;
        this.contentBottom = this.panelY + this.panelH - FOOTER_H;
        Category[] cats = Category.values();
        this.colPitch = (this.panelW - PAD_X * 2f) / cats.length;
        this.cardW = this.colPitch - 10f;
        this.searchW = clamp(this.panelW * 0.35f, 150f, 240f);
        this.searchH = 18f;
        this.searchX = this.panelX + (this.panelW - this.searchW) * 0.5f;
        this.searchY = this.panelY + this.panelH - 42f;
        this.btnY = this.panelY + 48f;
        this.btnH = 15f;
        this.langW = 42f;
        this.langX = this.panelX + this.panelW - PAD_X - this.langW;
        this.exportW = R2.width(SpecFonts.ui(tr("Export", "Экспорт"))) + 13f;
        this.exportX = this.langX - 7f - this.exportW;
        this.importW = R2.width(SpecFonts.ui(tr("Import", "Импорт"))) + 13f;
        this.importX = this.exportX - 6f - this.importW;

        this.cards.clear();
        for (int i = 0; i < cats.length; i++) {
            float colX = this.panelX + PAD_X + i * this.colPitch;
            float y = this.contentTop - this.scrollAnim[i].get();
            float total = 0f;
            for (Module m : visible(cats[i])) {
                float h = CARD_H + m.expandA.get() * settingsHeight(m);
                this.cards.add(new CardRect(m, i, colX, y, this.cardW, h));
                y += h + CARD_GAP;
                total += h + CARD_GAP;
            }
            this.contentH[i] = Math.max(0f, total - CARD_GAP);
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private float maxScroll(int col) {
        return Math.max(0f, this.contentH[col] - (this.contentBottom - this.contentTop));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        this.mouseX = mx;
        this.mouseY = my;
        try {
            this.renderGui(ctx, mx, my, delta);
        } catch (Throwable error) {
            R2.globalAlpha = 1f;
            System.err.println("[Sunrop] ошибка отрисовки меню: " + error);
            if (this.client != null) this.client.setScreen(null);
        }
    }

    private void renderGui(DrawContext ctx, int mx, int my, float delta) {
        this.tickTime();
        this.updateAnimations();
        this.layout();
        if (this.closing && this.openAnim.get() < 0.015f) {
            if (this.client != null) this.client.setScreen(null);
            return;
        }
        this.renderBackground(ctx, mx, my, delta);
        float t = Tween.easeOutCubic(this.openAnim.get());
        R2.globalAlpha = Tween.clamp01(this.openAnim.get() * 1.25f);
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        float cx = this.panelX + this.panelW * 0.5f;
        float cy = this.panelY + this.panelH * 0.5f;
        float scale = 0.95f + 0.05f * t;
        m.translate(cx, cy);
        m.scale(scale, scale);
        m.translate(-cx, -cy);
        m.translate(0f, (1f - t) * 12f);
        this.drawPanel(ctx);
        m.popMatrix();
        R2.globalAlpha = 1f;
    }

    private void updateAnimations() {
        this.openAnim.update(this.dt);
        this.searchAnim.set(this.searchFocused ? 1f : 0f);
        this.searchAnim.update(this.dt);
        this.importHover.update(this.dt);
        this.exportHover.update(this.dt);
        this.langSlide.update(this.dt);
        this.toastAnim.update(this.dt);
        for (int i = 0; i < this.scrollAnim.length; i++) {
            this.scrollAnim[i].set(this.scrollTarget[i]);
            this.scrollAnim[i].update(this.dt);
        }
        for (Module m : ModuleManager.MODULES) {
            m.toggleA.set(m.isEnabled() ? 1f : 0f);
            m.expandA.set(m.expanded && !m.settings.isEmpty() ? 1f : 0f);
            m.enableGlowA.set(m.isEnabled() ? 1f : 0f);
            m.toggleA.update(this.dt);
            m.expandA.update(this.dt);
            m.hoverA.update(this.dt);
            m.enableGlowA.update(this.dt);
            for (Setting s : m.settings) {
                s.anim.update(this.dt);
                if (s instanceof Setting.Bool b) b.anim.set(b.value ? 1f : 0f);
                if (s instanceof Setting.Num n) n.knob.set((float) n.percent());
                if (s instanceof Setting.Mode mo) mo.slide.set(mo.index);
                if (s instanceof Setting.Num n2) n2.knob.update(this.dt);
                if (s instanceof Setting.Mode mo2) mo2.slide.update(this.dt);
            }
        }
        if (this.toastLife > 0f) {
            this.toastLife -= this.dt;
            if (this.toastLife <= 0f) this.toastAnim.set(0f);
        }
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        float a = Tween.clamp01(this.openAnim.get() * 1.2f);
        boolean inGame = this.client != null && this.client.world != null;
        float dim = inGame ? 0.42f : 0.92f;
        ctx.fill(0, 0, this.width, this.height, R2.alpha(-16513525, dim * a));
        ctx.fillGradient(0, 0, this.width, (int) (this.height * 0.3f), R2.alpha(-16645110, 0.35f * a), 0);
        ctx.fillGradient(0, (int) (this.height * 0.7f), this.width, this.height, 0, R2.alpha(-16645110, 0.45f * a));
    }

    private void drawAmbience(DrawContext ctx) {
        float r = 9f;
        this.clipBlobs(ctx, this.panelX + r, this.panelY + 2f, this.panelX + this.panelW - r, this.panelY + r);
        this.clipBlobs(ctx, this.panelX + 2f, this.panelY + r, this.panelX + this.panelW - 2f, this.panelY + this.panelH - r);
        this.clipBlobs(ctx, this.panelX + r, this.panelY + this.panelH - r, this.panelX + this.panelW - r, this.panelY + this.panelH - 2f);
    }

    private void clipBlobs(DrawContext ctx, float x0, float y0, float x1, float y1) {
        if (x1 - x0 < 1f || y1 - y0 < 1f) return;
        ctx.enableScissor((int) Math.floor(x0), (int) Math.floor(y0), (int) Math.ceil(x1), (int) Math.ceil(y1));
        this.blob(ctx, 0.18f + 0.09f * this.sin(0.19f), 0.22f + 0.1f * this.cos(0.15f), 0.85f, 3900150, 0.3f);
        this.blob(ctx, 0.82f + 0.08f * this.cos(0.13f), 0.18f + 0.1f * this.sin(0.17f), 0.7f, 2450411, 0.26f);
        this.blob(ctx, 0.66f + 0.1f * this.sin(0.11f), 0.86f + 0.08f * this.cos(0.14f), 0.95f, 1920728, 0.24f);
        this.blob(ctx, 0.12f + 0.09f * this.cos(0.1f), 0.88f + 0.07f * this.sin(0.12f), 0.65f, 8141549, 0.22f);
        this.blob(ctx, 0.5f + 0.12f * this.sin(0.07f), 0.5f + 0.09f * this.cos(0.09f), 0.8f, 1982639, 0.18f);
        this.dust(ctx);
        ctx.disableScissor();
    }

    private float sin(float speed) { return (float) Math.sin(this.time * speed); }
    private float cos(float speed) { return (float) Math.cos(this.time * speed); }

    private void blob(DrawContext ctx, float fx, float fy, float fr, int rgb, float alpha) {
        float r = Math.max(this.panelW, this.panelH) * fr * 0.5f;
        int color = (int) (Tween.clamp01(alpha) * R2.globalAlpha * 255f) << 24 | rgb & 0xFFFFFF;
        R2.glow(ctx, this.panelX + this.panelW * fx, this.panelY + this.panelH * fy, r, color);
    }

    private void dust(DrawContext ctx) {
        for (int i = 0; i < 14; i++) {
            float seedX = (float) i * 73.13f % 1f;
            float seedY = (float) i * 37.77f % 1f;
            float speed = 0.006f + (float) (i * 13 % 7) * 0.0022f;
            float x = this.panelX + (seedX + (float) Math.sin(this.time * 0.08f + i) * 0.012f) * this.panelW;
            float y = this.panelY + ((seedY - this.time * speed) % 1f + 1f) % 1f * this.panelH;
            float rr = 0.5f + (float) (i * 17 % 5) * 0.2f;
            float alpha = 0.07f + (float) (i * 29 % 9) * 0.016f;
            R2.circle(ctx, x, y, rr, R2.c(-5256705, alpha));
        }
    }

    private void drawPanel(DrawContext ctx) {
        R2.shadow(ctx, this.panelX, this.panelY, this.panelW, this.panelH, 9f, R2.c(-16777216, 0.55f));
        R2.round(ctx, this.panelX, this.panelY, this.panelW, this.panelH, 9f, R2.c(-15064784));
        R2.round(ctx, this.panelX + 1f, this.panelY + 1f, this.panelW - 2f, this.panelH - 2f, 8f, R2.c(0x14FFFFFF));
        R2.round(ctx, this.panelX + 2f, this.panelY + 2f, this.panelW - 4f, this.panelH - 4f, 7f, R2.c(-603452655));
        this.drawAmbience(ctx);
        R2.round(ctx, this.panelX + 2f, this.panelY + 2f, this.panelW - 4f, 78f, 7f, R2.c(-1978920679, 0.5f));
        this.drawTitle(ctx);
        this.drawTopButtons(ctx);
        if (this.page == Page.MODULES) this.drawColumns(ctx);
        else this.drawPage(ctx);
        this.drawFooterLinks(ctx);
        this.drawSearch(ctx);
        this.drawToast(ctx);
    }

    private void drawTitle(DrawContext ctx) {
        Text spec = SpecFonts.title("Spec");
        Text client = SpecFonts.title("Client");
        float total = R2.width(spec) + R2.width(client);
        float tx = this.panelX + (this.panelW - total) * 0.5f;
        float ty = this.panelY + 42f;
        float pulse = 0.65f + 0.35f * (float) Math.sin(this.time * 1.1f);
        R2.glow(ctx, this.panelX + this.panelW * 0.5f, ty + 5f, 54f, R2.c(540771062, pulse));
        R2.text(ctx, spec, tx, ty, R2.c(-12877066));
        R2.text(ctx, client, tx + R2.width(spec), ty, R2.c(-1446410));
    }

    private void drawTopButtons(DrawContext ctx) {
        boolean impHover = R2.hover(this.mouseX, this.mouseY, this.importX, this.btnY, this.importW, this.btnH);
        boolean expHover = R2.hover(this.mouseX, this.mouseY, this.exportX, this.btnY, this.exportW, this.btnH);
        this.importHover.set(impHover ? 1f : 0f);
        this.exportHover.set(expHover ? 1f : 0f);
        this.drawButton(ctx, this.importX, this.importW, tr("Import", "Импорт"), this.importHover.get());
        this.drawButton(ctx, this.exportX, this.exportW, tr("Export", "Экспорт"), this.exportHover.get());
        R2.panel(ctx, this.langX, this.btnY, this.langW, this.btnH, 5f, R2.c(-15722975), R2.c(-14472390), 1f);
        float half = (this.langW - 2f) * 0.5f;
        float sel = this.langSlide.get();
        R2.round(ctx, this.langX + 1f + sel * half, this.btnY + 1f, half, this.btnH - 2f, 4f, R2.c(-12877066));
        int enColor = R2.c(R2.mix(-6774349, -1, 1f - sel));
        int ruColor = R2.c(R2.mix(-6774349, -1, sel));
        R2.textCentered(ctx, SpecFonts.tiny("EN"), this.langX + 1f + half * 0.5f, this.btnY + 4.8f, enColor);
        R2.textCentered(ctx, SpecFonts.tiny("RU"), this.langX + 1f + half * 1.5f, this.btnY + 4.8f, ruColor);
    }

    private void drawButton(DrawContext ctx, float x, float w, String label, float hover) {
        int bg = R2.mix(-15722975, -15130321, hover);
        int border = R2.mix(-14472390, -14326805, hover * 0.75f);
        R2.panel(ctx, x, this.btnY, w, this.btnH, 5f, R2.c(bg), R2.c(border), 1f);
        int color = R2.c(R2.mix(-6774349, -1446410, hover));
        R2.textCentered(ctx, SpecFonts.ui(label), x + w * 0.5f, this.btnY + 4.5f, color);
    }

    private void drawColumns(DrawContext ctx) {
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            float colX = this.panelX + PAD_X + i * this.colPitch;
            R2.text(ctx, SpecFonts.tiny(cats[i].title), colX + 1f, this.contentTop - 13f, R2.c(-8156003));
            if (i >= cats.length - 1) continue;
            this.vSeparator(ctx, colX + this.colPitch - 7.5f, this.contentTop - 17f, this.contentBottom);
        }
        if (this.cards.isEmpty()) {
            R2.textCentered(ctx, SpecFonts.ui(tr("Nothing found", "Ничего не найдено")),
                    this.panelX + this.panelW * 0.5f, this.contentTop + 26f, R2.c(-11774619));
            return;
        }
        int top = (int) Math.floor(this.contentTop - 4f);
        int bottom = (int) Math.ceil(this.contentBottom + 4f);
        ctx.enableScissor((int) this.panelX + 2, top, (int) (this.panelX + this.panelW) - 2, bottom);
        for (CardRect card : this.cards) {
            if (card.y > this.contentBottom + 8f || card.y + card.h < this.contentTop - 8f) {
                card.module.hoverA.set(0f);
                continue;
            }
            this.drawCard(ctx, card);
        }
        ctx.disableScissor();
    }

    private void vSeparator(DrawContext ctx, float x, float y0, float y1) {
        float fade = 16f;
        int steps = 6;
        for (int i = 0; i < steps; i++) {
            float a = ((float) i + 0.5f) / steps;
            float h = fade / steps;
            R2.rect(ctx, x, y0 + i * h, x + 0.9f, y0 + (i + 1) * h, R2.c(-15328217, a));
            R2.rect(ctx, x, y1 - (i + 1) * h, x + 0.9f, y1 - i * h, R2.c(-15328217, a));
        }
        R2.rect(ctx, x, y0 + fade, x + 0.9f, y1 - fade, R2.c(-15328217));
    }

    private void drawCard(DrawContext ctx, CardRect card) {
        Module m = card.module;
        float x = card.x, y = card.y, w = card.w;
        boolean hovered = R2.hover(this.mouseX, this.mouseY, x, y, w, CARD_H)
                && this.mouseY >= this.contentTop - 4f && this.mouseY <= this.contentBottom + 4f;
        m.hoverA.set(hovered ? 1f : 0f);
        float hv = m.hoverA.get();
        float en = m.enableGlowA.get();
        float ex = m.expandA.get();
        int bgOff = R2.mix(-15986666, -15591131, hv);
        int bgOn = R2.mix(-15656147, -15326405, hv);
        int bg = R2.mix(bgOff, bgOn, en);
        int border = R2.mix(-15262423, -14204049, en);
        if (en > 0.01f) {
            R2.glow(ctx, x + w * 0.5f, y + 11f, w * 0.72f, R2.c(507216630, en));
        }
        R2.panel(ctx, x, y, w, card.h, 5f, R2.c(bg), R2.c(border), 1f);
        int nameColor = R2.c(R2.mix(-3747874, -1446410, Math.max(en, hv * 0.6f)));
        R2.text(ctx, SpecFonts.bold(ftrim(m.name, (int) (w - 32f))), x + 7f, y + 7f, nameColor);
        float tx = x + w - 8f - TOGGLE_W;
        float ty = y + 6f;
        this.drawToggle(ctx, tx, ty, TOGGLE_W, TOGGLE_H, m.toggleA.get(), hv);
        float chevVisible = Math.max(hv, ex);
        if (!m.settings.isEmpty() && chevVisible > 0.01f) {
            int chevColor = R2.c(R2.mix(-11774619, -6774349, chevVisible), chevVisible);
            this.chevron(ctx, tx - 10f, y + 11f - 0.5f, ex, chevColor);
        }
        if (ex > 0.004f) {
            this.drawSettings(ctx, card, ex);
        }
    }

    private void drawToggle(DrawContext ctx, float x, float y, float w, float h, float t, float hv) {
        int off = R2.mix(-13946307, -13024945, hv);
        int track = R2.mix(off, -12877066, t);
        if (t > 0.02f) {
            R2.glow(ctx, x + w * 0.5f, y + h * 0.5f, 16f, R2.c(1429963510, t * 0.8f));
        }
        R2.round(ctx, x, y, w, h, h * 0.5f, R2.c(track));
        float knobR = h * 0.5f - 1.5f;
        float knobX = x + h * 0.5f + t * (w - h);
        R2.circle(ctx, knobX, y + h * 0.5f + 0.35f, knobR, R2.c(-16777216, 0.25f));
        R2.circle(ctx, knobX, y + h * 0.5f, knobR, R2.c(R2.mix(-3945770, -722948, t)));
    }

    private void chevron(DrawContext ctx, float cx, float cy, float t, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        m.rotate((float) Math.PI * Tween.easeOutCubic(t));
        R2.rotRect(ctx, -1.25f, 0f, 3.9f, 1.15f, 0.7853982f, color);
        R2.rotRect(ctx, 1.25f, 0f, 3.9f, 1.15f, -0.7853982f, color);
        m.popMatrix();
    }

    private void drawSettings(DrawContext ctx, CardRect card, float ex) {
        Module m = card.module;
        float x = card.x, w = card.w;
        float clipTop = card.y + CARD_H;
        float clipBottom = card.y + card.h;
        ctx.enableScissor((int) Math.floor(x), (int) Math.floor(clipTop), (int) Math.ceil(x + w), (int) Math.ceil(clipBottom));
        float sy = card.y + CARD_H + 4f;
        int index = 0;
        for (Setting s : m.settings) {
            float stagger = Tween.clamp01((ex - index * 0.055f) / 0.55f);
            float a = Tween.easeOutCubic(stagger);
            float rowY = sy - (1f - a) * (7f + index * 1.5f);
            if (s instanceof Setting.Mode mode) {
                this.drawMode(ctx, mode, x, rowY, w, a);
            } else if (s instanceof Setting.Num number) {
                this.drawSlider(ctx, number, x, rowY, w, a);
            } else if (s instanceof Setting.Bool bool) {
                this.drawCheckbox(ctx, bool, x, rowY, w, a);
            }
            sy += settingH(s) + 6f;
            index++;
        }
        float bStag = Tween.clamp01((ex - index * 0.055f) / 0.55f);
        float bA = Tween.easeOutCubic(bStag);
        float by = sy - (1f - bA) * (7f + index * 1.5f);
        String keyLbl = this.binding == m
                ? tr("Press a key...", "Нажми клавишу...")
                : tr("Key", "Клавиша") + ": " + keyName(m.key);
        R2.text(ctx, SpecFonts.ui(keyLbl), x + 7f, by + 3f, R2.c(this.binding == m ? -8540417 : -8156003, bA));
        ctx.disableScissor();
    }

    private void drawMode(DrawContext ctx, Setting.Mode s, float x, float y, float w, float a) {
        R2.text(ctx, SpecFonts.tiny(s.name), x + 7f, y, R2.c(-8156003, a));
        float bx = x + 7f;
        float by = y + 10f;
        float bw = w - 14f;
        float bh = 13f;
        R2.panel(ctx, bx, by, bw, bh, 4f, R2.c(-16184044, a), R2.c(-14998992, a), 1f);
        int count = s.modes.length;
        float segW = (bw - 2f) / count;
        float sel = s.slide.get();
        R2.round(ctx, bx + 1f + sel * segW, by + 1f, segW, bh - 2f, 3f, R2.c(-12877066, a));
        for (int i = 0; i < count; i++) {
            float strength = Tween.clamp01(1f - Math.abs(sel - i));
            int color = R2.c(R2.mix(-6774349, -1, strength), a);
            R2.textCentered(ctx, SpecFonts.tiny(ftrimT(s.modes[i], (int) (segW - 2f))),
                    bx + 1f + segW * (i + 0.5f), by + 4f, color);
        }
    }

    private void drawSlider(DrawContext ctx, Setting.Num s, float x, float y, float w, float a) {
        R2.text(ctx, SpecFonts.tiny(s.name), x + 7f, y, R2.c(-8156003, a));
        R2.textRight(ctx, SpecFonts.tiny(s.display()), x + w - 7f, y, R2.c(-8540417, a));
        float tx = x + 7f;
        float tw = w - 14f;
        float ty = y + 14f;
        float th = 3f;
        R2.round(ctx, tx, ty, tw, th, th * 0.5f, R2.c(-14538185, a));
        float p = Tween.clamp01(s.knob.get());
        R2.round(ctx, tx, ty, Math.max(th, tw * p), th, th * 0.5f, R2.c(-12877066, a));
        float kx = tx + tw * p;
        boolean active = this.dragging == s;
        float r = active ? 3.9f : 3.3f;
        R2.circle(ctx, kx, ty + th * 0.5f, r + 2f, R2.c(1429963510, a * 0.45f));
        R2.circle(ctx, kx, ty + th * 0.5f + 0.4f, r, R2.c(-16777216, a * 0.3f));
        R2.circle(ctx, kx, ty + th * 0.5f, r, R2.c(-722948, a));
    }

    private void drawCheckbox(DrawContext ctx, Setting.Bool s, float x, float y, float w, float a) {
        float v = s.anim.get();
        float bx = x + 7f;
        float by = y + 0.5f;
        float size = 7.5f;
        int fill = R2.mix(-16118251, -12877066, v);
        int border = R2.mix(-14011582, -12877066, v);
        R2.panel(ctx, bx, by, size, size, 2.2f, R2.c(fill, a), R2.c(border, a), 1f);
        if (v > 0.03f) {
            this.check(ctx, bx + size * 0.5f, by + size * 0.5f, 3.8f * v, R2.c(-1, a * v));
        }
        int color = R2.c(R2.mix(-6774349, -1446410, 0.25f + 0.75f * v), a);
        R2.text(ctx, SpecFonts.ui(s.name), bx + size + 5f, y + 1f, color);
    }

    private void check(DrawContext ctx, float cx, float cy, float s, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy - 0.3f);
        m.rotate(-0.7853982f);
        float th = 1.15f;
        R2.rect(ctx, -s * 0.55f, s * 0.18f, s * 0.75f, s * 0.18f + th, color);
        R2.rect(ctx, -s * 0.55f, -s * 0.6f, -s * 0.55f + th, s * 0.18f + th, color);
        m.popMatrix();
    }

    private void drawFooterLinks(DrawContext ctx) {
        float lx = this.panelX + PAD_X;
        float ly = this.panelY + this.panelH - 20f;
        drawLink(ctx, tr("Keys", "Клавиши"), lx, ly, this.page == Page.BINDS);
        lx += R2.width(SpecFonts.tiny(tr("Keys", "Клавиши"))) + 14f;
        drawLink(ctx, tr("Friends", "Друзья"), lx, ly, this.page == Page.FRIENDS);
        float hud = R2.width(SpecFonts.tiny("HUD editor")) + 10f;
        drawLink(ctx, "HUD editor", this.panelX + this.panelW - PAD_X - hud, ly, false);
    }

    private void drawLink(DrawContext ctx, String s, float x, float y, boolean active) {
        boolean hov = R2.hover(this.mouseX, this.mouseY, x, y - 3f, R2.width(SpecFonts.tiny(s)) + 4f, 12f);
        int col = active ? -8540417 : (hov ? -1446410 : -11774619);
        R2.text(ctx, SpecFonts.tiny(s), x, y, R2.c(col));
    }

    private void drawPage(DrawContext ctx) {
        float x = this.panelX + PAD_X;
        float y = this.contentTop - 4f;
        float w = this.panelW - PAD_X * 2f;
        float h = this.contentBottom - this.contentTop + 8f;
        R2.panel(ctx, x, y, w, h, 6f, R2.c(-16118251, 0.55f), R2.c(-15064784, 0.6f), 1f);
        String title = this.page == Page.BINDS ? tr("Module binds", "Клавиши модулей")
                : tr("Friends", "Друзья");
        R2.text(ctx, SpecFonts.bold(title), x + 10f, y + 8f, R2.c(-1446410));
        R2.textRight(ctx, SpecFonts.tiny(tr("RMB — clear / remove", "ПКМ — снять / удалить")),
                x + w - 10f, y + 9f, R2.c(-11774619));
        float ry = y + 24f;
        if (this.page == Page.BINDS) {
            for (Module m : ModuleManager.MODULES) {
                if (ry > y + h - 12f) break;
                boolean hov = R2.hover(this.mouseX, this.mouseY, x + 8f, ry - 3f, w - 16f, 13f);
                String right = this.binding == m ? tr("Press a key...", "Нажми клавишу...") : keyName(m.key);
                R2.text(ctx, SpecFonts.ui(m.name), x + 14f, ry, R2.c(hov ? -1446410 : -6774349));
                R2.textRight(ctx, SpecFonts.tiny(right), x + w - 14f, ry, R2.c(this.binding == m ? -8540417 : -11774619));
                ry += 14f;
            }
        } else {
            List<String> all = new ArrayList<>(Friends.all());
            for (String n : all) {
                if (ry > y + h - 12f) break;
                boolean hov = R2.hover(this.mouseX, this.mouseY, x + 8f, ry - 3f, w - 16f, 13f);
                R2.text(ctx, SpecFonts.ui(n), x + 14f, ry, R2.c(hov ? -1446410 : -6774349));
                R2.textRight(ctx, SpecFonts.tiny(tr("remove", "удалить")), x + w - 14f, ry, R2.c(-11774619));
                ry += 14f;
            }
            if (all.isEmpty()) {
                R2.text(ctx, SpecFonts.ui(tr("List is empty — type a name below and Enter",
                        "Список пуст — введи ник снизу и Enter")), x + 14f, ry, R2.c(-11774619));
            }
        }
    }

    private void drawSearch(DrawContext ctx) {
        float focus = this.searchAnim.get();
        int border = R2.mix(-15065044, -13672530, focus);
        if (focus > 0.02f) {
            R2.glow(ctx, this.searchX + this.searchW * 0.5f, this.searchY + this.searchH * 0.5f,
                    this.searchW * 0.55f, R2.c(1429963510, focus * 0.35f));
        }
        R2.panel(ctx, this.searchX, this.searchY, this.searchW, this.searchH, 6f, R2.c(-16184045), R2.c(border), 1f);
        float icx = this.searchX + 12f;
        float icy = this.searchY + this.searchH * 0.5f - 0.6f;
        int iconColor = R2.c(R2.mix(-11774619, -6774349, focus));
        R2.circle(ctx, icx, icy, 2.9f, iconColor);
        R2.circle(ctx, icx, icy, 2f, R2.c(-16184045));
        R2.rotRect(ctx, icx + 2.9f, icy + 2.9f, 3f, 1f, 0.7853982f, iconColor);
        boolean empty = this.query.isEmpty();
        String ph = this.page == Page.FRIENDS ? tr("nick + Enter", "ник + Enter")
                : tr("Search modules...", "Поиск модулей...");
        Text shown = SpecFonts.ui(empty ? ph : this.query);
        int color = R2.c(empty ? -11774619 : -1446410);
        R2.text(ctx, shown, this.searchX + 20f, this.searchY + 6f, color);
        if (this.searchFocused && (int) (this.time * 2f) % 2 == 0) {
            float caretX = this.searchX + 20f + (empty ? 0f : R2.width(shown)) + 1.5f;
            R2.rect(ctx, caretX, this.searchY + 4.5f, caretX + 0.9f, this.searchY + this.searchH - 4.5f, R2.c(-8540417));
        }
    }

    private void drawToast(DrawContext ctx) {
        float a = this.toastAnim.get();
        if (a < 0.01f || this.toastText.isEmpty()) return;
        Text text = SpecFonts.ui(this.toastText);
        float w = R2.width(text) + 20f;
        float h = 17f;
        float x = this.panelX + this.panelW - PAD_X - w;
        float y = this.panelY + this.panelH - 66f + (1f - a) * 10f;
        R2.panel(ctx, x, y, w, h, 5f, R2.c(-15985886, a), R2.c(-14326805, a * 0.8f), 1f);
        R2.circle(ctx, x + 9f, y + h * 0.5f, 2.2f, R2.c(-12877066, a));
        R2.text(ctx, text, x + 15f, y + 5.5f, R2.c(-1446410, a));
    }

    private void toast(String message) {
        this.toastText = message;
        this.toastLife = 2.4f;
        this.toastAnim.snap(0f);
        this.toastAnim.set(1f);
    }

    private static String keyName(int k) {
        if (k == GLFW.GLFW_KEY_UNKNOWN) return "—";
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RShift";
        if (k == GLFW.GLFW_KEY_LEFT_SHIFT) return "LShift";
        if (k == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCtrl";
        if (k == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCtrl";
        if (k == GLFW.GLFW_KEY_RIGHT_ALT) return "RAlt";
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase(Locale.ROOT) : ("KEY" + k);
    }

    private static final HashMap<String, String> TRIMC = new HashMap<>();
    private static final HashMap<String, String> TRIMT = new HashMap<>();

    private String ftrim(String s, int max) {
        String k = s + "\u0001" + max;
        String cv = TRIMC.get(k);
        if (cv != null) return cv;
        String out;
        int w = R2.width(SpecFonts.bold(s));
        if (w <= max) out = s;
        else {
            int keep = Math.max(1, (int) ((long) s.length() * (max - 6) / Math.max(1, w)));
            out = s.substring(0, Math.min(s.length(), keep));
            while (out.length() > 1 && R2.width(SpecFonts.bold(out + "...")) > max) out = out.substring(0, out.length() - 1);
            out = out.length() >= s.length() ? s : out + "...";
        }
        TRIMC.put(k, out);
        return out;
    }

    private String ftrimT(String s, int max) {
        String k = s + "\u0001" + max;
        String cv = TRIMT.get(k);
        if (cv != null) return cv;
        String out;
        int w = R2.width(SpecFonts.tiny(s));
        if (w <= max) out = s;
        else {
            int keep = Math.max(1, (int) ((long) s.length() * (max - 4) / Math.max(1, w)));
            out = s.substring(0, Math.min(s.length(), keep));
            while (out.length() > 1 && R2.width(SpecFonts.tiny(out + "..")) > max) out = out.substring(0, out.length() - 1);
            out = out.length() >= s.length() ? s : out + "..";
        }
        TRIMT.put(k, out);
        return out;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int button = click.button();
        this.layout();

        if (R2.hover(mx, my, this.searchX, this.searchY, this.searchW, this.searchH)) {
            this.searchFocused = true;
            if (button == 1) this.query = "";
            return true;
        }
        this.searchFocused = false;

        if (R2.hover(mx, my, this.importX, this.btnY, this.importW, this.btnH)) { this.doImport(); return true; }
        if (R2.hover(mx, my, this.exportX, this.btnY, this.exportW, this.btnH)) { this.doExport(); return true; }
        if (R2.hover(mx, my, this.langX, this.btnY, this.langW, this.btnH)) {
            boolean en = mx < this.langX + this.langW * 0.5f;
            Lang.russian = !en;
            this.langSlide.set(en ? 0f : 1f);
            ConfigFile.save();
            return true;
        }

        float lx = this.panelX + PAD_X;
        float ly = this.panelY + this.panelH - 20f;
        if (R2.hover(mx, my, lx - 2f, ly - 3f, R2.width(SpecFonts.tiny(tr("Keys", "Клавиши"))) + 8f, 12f)) {
            this.page = this.page == Page.BINDS ? Page.MODULES : Page.BINDS;
            this.binding = null;
            return true;
        }
        lx += R2.width(SpecFonts.tiny(tr("Keys", "Клавиши"))) + 14f;
        if (R2.hover(mx, my, lx - 2f, ly - 3f, R2.width(SpecFonts.tiny(tr("Friends", "Друзья"))) + 8f, 12f)) {
            this.page = this.page == Page.FRIENDS ? Page.MODULES : Page.FRIENDS;
            this.binding = null;
            return true;
        }
        float hudW = R2.width(SpecFonts.tiny("HUD editor")) + 10f;
        if (R2.hover(mx, my, this.panelX + this.panelW - PAD_X - hudW - 2f, ly - 3f, hudW + 8f, 12f)) {
            if (this.client != null) this.client.setScreen(new HudEditor());
            return true;
        }

        if (this.page == Page.BINDS) {
            float x = this.panelX + PAD_X;
            float y = this.contentTop - 4f;
            float w = this.panelW - PAD_X * 2f;
            float ry = y + 24f;
            for (Module m : ModuleManager.MODULES) {
                if (ry > y + (this.contentBottom - this.contentTop + 8f) - 12f) break;
                if (R2.hover(mx, my, x + 8f, ry - 3f, w - 16f, 13f)) {
                    if (button == 1) {
                        m.key = GLFW.GLFW_KEY_UNKNOWN;
                        this.binding = null;
                    } else {
                        this.binding = m;
                    }
                    return true;
                }
                ry += 14f;
            }
            return true;
        }
        if (this.page == Page.FRIENDS) {
            float x = this.panelX + PAD_X;
            float y = this.contentTop - 4f;
            float w = this.panelW - PAD_X * 2f;
            float ry = y + 24f;
            List<String> all = new ArrayList<>(Friends.all());
            for (String n : all) {
                if (ry > y + (this.contentBottom - this.contentTop + 8f) - 12f) break;
                if (R2.hover(mx, my, x + 8f, ry - 3f, w - 16f, 13f)) {
                    Friends.toggle(n);
                    toast(tr("Friend removed: ", "Друг удалён: ") + n);
                    return true;
                }
                ry += 14f;
            }
            return true;
        }

        if (my < this.contentTop - 6f || my > this.contentBottom + 4f) return true;
        for (CardRect card : this.cards) {
            if (mx < card.x || mx > card.x + card.w) continue;
            Module m = card.module;
            if (my >= card.y && my <= card.y + CARD_H) {
                float toggleX = card.x + card.w - 8f - TOGGLE_W;
                boolean onChevron = !m.settings.isEmpty() && mx >= toggleX - 16f && mx < toggleX - 3f;
                if (button == 1 || onChevron) {
                    m.expanded = !m.expanded && !m.settings.isEmpty();
                } else if (button == 0) {
                    m.toggle();
                }
                return true;
            }
            if (m.expanded && my > card.y + CARD_H && my <= card.y + card.h) {
                this.handleSettingClick(card, mx, my, button);
                return true;
            }
        }
        return true;
    }

    private void handleSettingClick(CardRect card, double mx, double my, int button) {
        Module m = card.module;
        float x = card.x, w = card.w;
        float sy = card.y + CARD_H + 4f;
        for (Setting s : m.settings) {
            float h = settingH(s);
            if (my >= sy - 2f && my <= sy + h + 2f) {
                if (s instanceof Setting.Mode mode) {
                    float bx = x + 7f;
                    float bw = w - 14f;
                    if (my >= sy + 9f && mx >= bx && mx <= bx + bw) {
                        int index = (int) ((mx - bx - 1f) / ((bw - 2f) / mode.modes.length));
                        mode.select(MathHelper.clamp(index, 0, mode.modes.length - 1));
                    } else {
                        mode.select(button == 1 ? mode.index - 1 : mode.index + 1);
                    }
                } else if (s instanceof Setting.Num number) {
                    float tx = x + 7f;
                    float tw = w - 14f;
                    this.dragging = number;
                    this.dragTrackX = tx;
                    this.dragTrackW = tw;
                    number.setFromPercent((mx - tx) / tw);
                } else if (s instanceof Setting.Bool bool) {
                    bool.toggle();
                }
                return;
            }
            sy += h + 6f;
        }
        if (my >= sy - 2f && my <= sy + 18f) {
            this.binding = m;
        }
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (this.dragging != null) {
            this.dragging.setFromPercent((this.mouseX - this.dragTrackX) / this.dragTrackW);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (this.dragging != null) {
            this.dragging = null;
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        this.layout();
        if (this.page == Page.MODULES
                && my >= this.contentTop - 14f && my <= this.contentBottom + 8f) {
            int col = (int) Math.floor((mx - this.panelX - PAD_X) / this.colPitch);
            if (col >= 0 && col < this.scrollTarget.length) {
                this.scrollTarget[col] = clamp(this.scrollTarget[col] - (float) vertical * 18f, 0f, this.maxScroll(col));
            }
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (this.binding != null) {
            this.binding.key = (key == GLFW.GLFW_KEY_ESCAPE) ? GLFW.GLFW_KEY_UNKNOWN : key;
            this.binding = null;
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT || key == GLFW.GLFW_KEY_ESCAPE) {
            if (this.page != Page.MODULES && key == GLFW.GLFW_KEY_ESCAPE) {
                this.page = Page.MODULES;
                return true;
            }
            this.removed();
            return true;
        }
        if (this.searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!this.query.isEmpty()) this.query = this.query.substring(0, this.query.length() - 1);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                if (this.page == Page.FRIENDS && !this.query.trim().isEmpty()) {
                    Friends.toggle(this.query.trim());
                    toast(tr("Friend added: ", "Друг добавлен: ") + this.query.trim());
                    this.query = "";
                } else {
                    this.searchFocused = false;
                }
                return true;
            }
            if (key == GLFW.GLFW_KEY_V && (input.modifiers() & 2) != 0 && this.client != null) {
                this.query += this.client.keyboard.getClipboard();
                return true;
            }
        }
        if (key == GLFW.GLFW_KEY_SLASH && !this.searchFocused) {
            this.searchFocused = true;
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (this.searchFocused && input.isValidChar()) {
            this.query += input.asString();
            return true;
        }
        return super.charTyped(input);
    }

    private void doExport() {
        if (this.client == null) return;
        StringBuilder sb = new StringBuilder("# sunrop-clipboard:1\n");
        for (Module m : ModuleManager.MODULES) {
            sb.append("M;").append(m.name).append(';').append(m.isEnabled() ? 1 : 0)
                    .append(';').append(m.key).append('\n');
            for (Setting s : m.settings) {
                sb.append("S;").append(m.name).append(';').append(s.name).append(';')
                        .append(s.serialize()).append('\n');
            }
        }
        this.client.keyboard.setClipboard(sb.toString());
        ConfigFile.save();
        toast(tr("Config copied", "Конфиг скопирован"));
    }

    private void doImport() {
        if (this.client == null) return;
        String clip = this.client.keyboard.getClipboard();
        if (clip == null || !clip.startsWith("# sunrop-clipboard:1")) {
            toast(tr("Import failed", "Ошибка импорта"));
            return;
        }
        for (String line : clip.split("\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] p = line.split(";", 4);
            if (p.length < 3) continue;
            Module m = findModule(p[1]);
            if (m == null) continue;
            if (p[0].equals("M") && p.length >= 4) {
                try { m.key = Integer.parseInt(p[3].trim()); } catch (NumberFormatException ignored) {}
                boolean on = p[2].equals("1");
                if (on != m.isEnabled()) m.toggle();
            } else if (p[0].equals("S") && p.length == 4) {
                for (Setting s : m.settings) {
                    if (s.name.equals(p[2])) { s.deserialize(p[3]); break; }
                }
            }
        }
        toast(tr("Imported", "Импортирован"));
        ConfigFile.save();
    }

    private Module findModule(String name) {
        for (Module m : ModuleManager.MODULES) if (m.name.equals(name)) return m;
        return null;
    }
}
