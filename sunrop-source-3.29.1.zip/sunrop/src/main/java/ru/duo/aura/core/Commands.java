package ru.duo.aura.core;

import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import ru.duo.aura.ConfigFile;
import ru.duo.aura.modules.StorageEsp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public final class Commands {

    private Commands() {}

    public static void init() {
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            if (msg != null && msg.startsWith(".")) {
                dispatch(msg.trim());
                return false;
            }
            return true;
        });
    }

    private static void send(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), false);
    }

    private static void dispatch(String msg) {
        String[] a = msg.substring(1).split("\\s+");
        String cmd = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "";
        switch (cmd) {
            case "help", "?" -> help();
            case "cfg", "config" -> cfg(a);
            case "blockesp", "esp" -> blockesp(a);
            case "basefinder", "bf" -> basefinder(a);
            case "friend", "f" -> friend(a);
            case "wp", "waypoint", "wps" -> wp(a);
            default -> send("§7[Sunrop] §cнеизвестная команда: §f." + cmd + " §7— смотри §f.help");
        }
    }

    private static void help() {
        send("§7[Sunrop] §f.cfg save [имя] §7— сохранить конфиг");
        send("§7[Sunrop] §f.cfg load <имя> §7— загрузить");
        send("§7[Sunrop] §f.cfg list §7— список, §f.cfg dir §7— папка, §f.cfg reset §7— сброс");
        send("§7[Sunrop] §f.blockesp add <блок> [цвет] §7— напр. §f.blockesp add chest green");
        send("§7[Sunrop] §f.blockesp remove <блок> §7| §flist §7| §fclear");
        send("§7[Sunrop] §f.basefinder add <блок> [цвет] §7— особенные блоки (режим MANUAL)");
        send("§7[Sunrop] §f.basefinder remove|list|clear");
        send("§7[Sunrop] §f.friend add <ник> §7| §fremove <ник> §7| §flist §7| §fclear");
        send("§7[Sunrop] §f.wp add [имя] §7| §fremove <имя> §7| §flist §7| §fclear");
    }

    private static void friend(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "add", "a" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.friend add <ник>"); return; }
                Friends.set(a[2], true);
                send("§7[Sunrop] §aдруг добавлен: §f" + a[2]);
            }
            case "remove", "del", "r" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.friend remove <ник>"); return; }
                Friends.set(a[2], false);
                send("§7[Sunrop] §aдруг удалён: §f" + a[2]);
            }
            case "list" -> {
                var all = Friends.all();
                send(all.isEmpty() ? "§7[Sunrop] §7список друзей пуст" : "§7[Sunrop] §f" + String.join("§7, §f", all));
            }
            case "clear" -> {
                Friends.clear();
                send("§7[Sunrop] §aсписок друзей очищен");
            }
            default -> send("§7[Sunrop] §c.friend add|remove|list|clear");
        }
    }

    private static void wp(String[] a) {
        var m = ru.duo.aura.core.ModuleManager.waypoints;
        if (m == null) { send("§7[Sunrop] §cмодуль Waypoints не найден"); return; }
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        var mc = MinecraftClient.getInstance();
        switch (sub) {
            case "add", "a" -> {
                if (mc.player == null) return;
                String name = a.length > 2
                        ? String.join(" ", java.util.Arrays.copyOfRange(a, 2, a.length))
                        : ("Метка " + (m.points.size() + 1));
                m.addPoint(name, mc.player.getEntityPos());
                send("§7[Sunrop] §aметка поставлена: §f" + name);
            }
            case "remove", "del", "r" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.wp remove <имя>"); return; }
                String name = String.join(" ", java.util.Arrays.copyOfRange(a, 2, a.length));
                boolean ok = m.removeByName(name);
                send(ok ? "§7[Sunrop] §aметка удалена: §f" + name : "§7[Sunrop] §cнет метки: §f" + name);
            }
            case "list" -> {
                if (m.points.isEmpty()) { send("§7[Sunrop] §7меток нет"); return; }
                for (var w : m.points) {
                    double d = mc.player != null ? mc.player.getEntityPos().distanceTo(w.pos()) : -1;
                    send("§7[Sunrop] §f" + w.name() + " §7— §f"
                            + (int) w.pos().x + " " + (int) w.pos().y + " " + (int) w.pos().z
                            + (d >= 0 ? " §7(" + (int) d + " м)" : ""));
                }
            }
            case "clear" -> {
                m.points.clear();
                m.persist();
                send("§7[Sunrop] §aметки стёрты");
            }
            default -> send("§7[Sunrop] §c.wp add|remove|list|clear");
        }
    }

    private static void basefinder(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "add" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.basefinder add <блок> [цвет]"); return; }
                Block b = parseBlock(a[2]);
                if (b == null) { send("§7[Sunrop] §cнеизвестный блок: §f" + a[2]); return; }
                int color = a.length > 3 ? parseColor(a[3]) : 0xFFFF4DE8;
                ru.duo.aura.modules.BaseFinder.addManual(b, color);
                send("§7[Sunrop] §a" + ru.duo.aura.modules.BaseFinder.blockName(b) + " §7→ §f"
                        + String.format("#%06X", color & 0xFFFFFF));
            }
            case "remove", "del" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.basefinder remove <блок>"); return; }
                Block b = parseBlock(a[2]);
                if (b == null) { send("§7[Sunrop] §cнеизвестный блок: §f" + a[2]); return; }
                ru.duo.aura.modules.BaseFinder.removeManual(b);
                send("§7[Sunrop] §aубрано: §f" + ru.duo.aura.modules.BaseFinder.blockName(b));
            }
            case "list" -> {
                StringBuilder sb = new StringBuilder();
                for (var e : ru.duo.aura.modules.BaseFinder.MANUAL.entrySet()) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append(ru.duo.aura.modules.BaseFinder.blockName(e.getKey())).append(":")
                            .append(String.format("#%06X", e.getValue() & 0xFFFFFF));
                }
                send(sb.length() == 0 ? "§7[Sunrop] §7список пуст" : "§7[Sunrop] §f" + sb);
            }
            case "clear" -> {
                ru.duo.aura.modules.BaseFinder.clearManual();
                send("§7[Sunrop] §aсписок очищен");
            }
            default -> send("§7[Sunrop] §c.basefinder add|remove|list|clear");
        }
    }

    private static void cfg(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "save" -> {
                String name = a.length > 2 ? a[2] : null;
                ConfigFile.save(name);
                send("§7[Sunrop] §aконфиг сохранён: §f" + ConfigFile.fileName(name));
            }
            case "load" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.cfg load <имя>"); return; }
                String name = a[2];
                if (!ConfigFile.exists(name)) { send("§7[Sunrop] §cнет файла: §f" + ConfigFile.fileName(name)); return; }
                ConfigFile.load(name);
                send("§7[Sunrop] §aконфиг загружен: §f" + ConfigFile.fileName(name));
            }
            case "reset" -> {
                ConfigFile.reset();
                send("§7[Sunrop] §aконфиг сброшен к дефолту");
            }
            case "list" -> {
                List<String> names = ConfigFile.list();
                if (names.isEmpty()) send("§7[Sunrop] §7конфигов нет");
                else send("§7[Sunrop] §f" + String.join("§7, §f", names));
            }
            case "dir" -> send("§7[Sunrop] §f" + ConfigFile.dir());
            default -> send("§7[Sunrop] §c.cfg save|load|reset|list|dir");
        }
    }

    private static void blockesp(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "add" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.blockesp add <блок> [цвет]"); return; }
                Block b = parseBlock(a[2]);
                if (b == null) { send("§7[Sunrop] §cнеизвестный блок: §f" + a[2]); return; }
                int color = a.length > 3 ? parseColor(a[3]) : 0xFF4DFFC4;
                StorageEsp.addCustom(b, color);
                send("§7[Sunrop] §a" + StorageEsp.blockName(b) + " §7→ §f" + StorageEsp.colorName(color));
            }
            case "remove", "del" -> {
                if (a.length < 3) { send("§7[Sunrop] §c.blockesp remove <блок>"); return; }
                Block b = parseBlock(a[2]);
                if (b == null) { send("§7[Sunrop] §cнеизвестный блок: §f" + a[2]); return; }
                StorageEsp.removeCustom(b);
                send("§7[Sunrop] §aубрано: §f" + StorageEsp.blockName(b));
            }
            case "list" -> {
                String s = StorageEsp.listCustom();
                send(s.isEmpty() ? "§7[Sunrop] §7кастомных блоков нет" : "§7[Sunrop] §f" + s);
            }
            case "clear" -> {
                StorageEsp.clearCustom();
                send("§7[Sunrop] §aкастомный список очищен");
            }
            default -> send("§7[Sunrop] §c.blockesp add|remove|list|clear");
        }
    }

    public static Block parseBlock(String s) {
        String n = s.toLowerCase(Locale.ROOT).replace("minecraft:", "").replace(' ', '_');
        switch (n) {
            case "spawner", "mob_spawner", "monster_spawner" -> n = "spawner";
            case "trap", "trapped", "trappedchest" -> n = "trapped_chest";
            case "brewing", "brew", "stand" -> n = "brewing_stand";
            case "dispenser", "dropper" -> { }
            case "shulker", "shulkerbox" -> n = "shulker_box";
            default -> { }
        }
        Block b = Registries.BLOCK.get(Identifier.of("minecraft", n));
        return b == Blocks.AIR && !n.equals("air") ? null : b;
    }

    public static int parseColor(String s) {
        s = s.toLowerCase(Locale.ROOT);
        switch (s) {
            case "green": return 0xFF4DFF6A;
            case "lime": return 0xFFA8FF4D;
            case "red": return 0xFFFF4D5A;
            case "blue": return 0xFF4D8CFF;
            case "aqua", "cyan": return 0xFF4DE8FF;
            case "yellow": return 0xFFFFE24D;
            case "orange": return 0xFFFF9A4D;
            case "purple", "violet": return 0xFFB84DFF;
            case "pink", "magenta": return 0xFFFF4DE8;
            case "white": return 0xFFF5F5FF;
            case "gray", "grey": return 0xFF9AA0B0;
            case "black": return 0xFF202028;
            case "gold": return 0xFFFFC04D;
            default: break;
        }
        try {
            if (s.startsWith("#")) {
                return (int) (Long.parseLong(s.substring(1), 16) | 0xFF000000L);
            }
            return (int) (Long.parseLong(s) | 0xFF000000L);
        } catch (NumberFormatException ignored) {
            return 0xFF4DFFC4;
        }
    }
}
