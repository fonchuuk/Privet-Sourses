package ru.duo.aura.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = InGameHud.class, priority = 1000)
public class HudCrosshairMixin {

    @Inject(method = "renderCrosshair(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void sunrop$hideVanilla(DrawContext ctx, RenderTickCounter tick, CallbackInfo ci) {
        try {
            var m = ru.duo.aura.core.ModuleManager.crosshair;
            if (m != null && m.isEnabled()) ci.cancel();
        } catch (Throwable ignored) {
        }
    }
}
