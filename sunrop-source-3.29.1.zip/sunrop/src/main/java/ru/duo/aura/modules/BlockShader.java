package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class BlockShader extends Module {

    public final Setting.Mode style = add(new Setting.Mode("Style", 2,
            "BOX", "CORNERS", "GLOW", "FILL"));
    public final Setting.Mode color = add(new Setting.Mode("Color", 0,
            "ACCENT", "RAINBOW", "WHITE", "RED", "GREEN", "BLUE", "PURPLE"));
    public final Setting.Num pulse = add(new Setting.Num("Pulse", 0.5, 0.0, 1.0, 0.05));
    public final Setting.Num width = add(new Setting.Num("Line width", 2, 1, 4, 1));
    public final Setting.Num fill = add(new Setting.Num("Fill alpha", 0.25, 0.0, 0.8, 0.05));
    public final Setting.Num hueSpeed = add(new Setting.Num("Rainbow speed", 0.6, 0.1, 3.0, 0.1));

    public BlockShader() {
        super("BlockShader", "Красивая подсветка блока под прицелом", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    public int colorAt(long time) {
        if (color.is("RAINBOW")) {
            double period = 6000 / Math.max(0.1, hueSpeed.value);
            float h = (float) ((time % (long) period) / period);
            float r = Math.abs(h * 6 - 3) - 1;
            float g = 2 - Math.abs(h * 6 - 2);
            float b = 2 - Math.abs(h * 6 - 4);
            return 0xFF000000 | ((int) (clamp01(r) * 255) << 16) | ((int) (clamp01(g) * 255) << 8) | (int) (clamp01(b) * 255);
        }
        return switch (color.get()) {
            case "WHITE" -> 0xFFFFFFFF;
            case "RED" -> 0xFFFF4040;
            case "GREEN" -> 0xFF4CFF5A;
            case "BLUE" -> 0xFF4C7FFF;
            case "PURPLE" -> 0xFFCC59FF;
            default -> 0xFF7FB8FF;
        };
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
