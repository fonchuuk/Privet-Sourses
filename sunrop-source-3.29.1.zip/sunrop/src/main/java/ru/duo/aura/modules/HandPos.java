package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class HandPos extends Module {

    public final Setting.Num offX = add(new Setting.Num("Offset X", 0, -1.5, 1.5, 0.05));
    public final Setting.Num offY = add(new Setting.Num("Offset Y", 0, -1.5, 1.5, 0.05));
    public final Setting.Num offZ = add(new Setting.Num("Offset Z", 0, -1.5, 1.5, 0.05));
    public final Setting.Num scale = add(new Setting.Num("Scale", 1.0, 0.3, 1.8, 0.05));
    public final Setting.Num rotX = add(new Setting.Num("Rotate X", 0, -180, 180, 5));
    public final Setting.Num rotY = add(new Setting.Num("Rotate Y", 0, -180, 180, 5));
    public final Setting.Num rotZ = add(new Setting.Num("Rotate Z", 0, -180, 180, 5));
    public final Setting.Num bob = add(new Setting.Num("Bob (up-down)", 0.0, 0.0, 1.0, 0.05));

    public HandPos() {
        super("HandPos", "Меняет положение и поворот рук", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
