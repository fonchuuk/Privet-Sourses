package ru.duo.aura.gui;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.HudLayout;
import ru.duo.aura.core.Theme;

import java.util.List;

public class HudRenderer {

    private static final Identifier LOGO = Identifier.of("sunrop", "textures/logo.png");

    public static void register() {
        HudElementRegistry.addLast(Identifier.of("sunrop", "hud"), (ctx, tick) -> render(ctx));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        EspRenderer.render(ctx);
        VisualRenderer.render(ctx);
        ProjectileRenderer.render(ctx);
        BaseFinderRenderer.render(ctx);

        if (mc.player == null || mc.options.hudHidden) return;
        if (mc.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen) { /* рисуем всё равно */ }

        var hud = ModuleManager.hudList;
        if (hud == null || !hud.isEnabled()) return;

        int w = ctx.getScaledWindowWidth();
        int y = 2;

        boolean system = hud.style.is("SYSTEM");

        if (hud.bottomLine.value && system) {
            String left = "Sunrop  |  " + mc.player.getName().getString();
            ctx.drawText(mc.textRenderer, left, 3, ctx.getScaledWindowHeight() - 10,
                    Theme.accent(), false);
            String rightTxt = "Items:" + mc.player.getInventory().getStack(
                    mc.player.getInventory().getSelectedSlot()).getCount();
            ctx.drawText(mc.textRenderer, rightTxt,
                    w - mc.textRenderer.getWidth(rightTxt) - 3, ctx.getScaledWindowHeight() - 10,
                    Theme.accent(), false);
        }

        if (hud.watermark.value) {
            String name = "Sunrop";
            int ls = hud.logo.value ? hud.logoSize.asInt() : 0;
            int ww = mc.textRenderer.getWidth(name + " 1.21.11") + 4 + (ls > 0 ? ls + 3 : 0);
            int wx = HudLayout.x(HudLayout.WATERMARK, 3, ww, Math.max(11, ls));
            int wy = HudLayout.y(HudLayout.WATERMARK, 3);
            int tx = wx;
            if (ls > 0) {
                ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, LOGO,
                        wx, wy - (ls - 8) / 2, 0.0f, 0.0f, ls, ls, 64, 64, 64, 64);
                tx = wx + ls + 3;
            }
            ctx.drawText(mc.textRenderer, name, tx, wy, Theme.accent(), true);
            ctx.drawText(mc.textRenderer, "1.21.11", tx + 3 + mc.textRenderer.getWidth(name), wy, 0xFFFFFFFF, true);
        }

        if (hud.arrayList.value) {
            List<Module> list = ModuleManager.enabledSorted(mc);
            int widest = 0;
            for (Module m : list) widest = Math.max(widest, mc.textRenderer.getWidth(m.name + m.hudSuffix()) + 6);
            int ax = HudLayout.x(HudLayout.ARRAYLIST, Math.max(0, w - widest), widest, Math.max(10, list.size() * 10));
            int ay = HudLayout.y(HudLayout.ARRAYLIST, 2);
            y = ay;
            int i = 0;
            for (Module m : list) {
                String text = m.name + m.hudSuffix();
                int tw = mc.textRenderer.getWidth(text);
                int color = hud.rainbow.value ? rainbow(i) : Theme.accent();
                int right = ax + widest;
                if (system) {
                    ctx.drawText(mc.textRenderer, text, right - tw - 2, y + 1, color, false);
                } else {
                    ctx.fill(right - tw - 4, y, right, y + 10, 0x66000000);
                    ctx.fill(right - tw - 5, y, right - tw - 4, y + 10, color);
                    ctx.drawText(mc.textRenderer, text, right - tw - 2, y + 1, color, true);
                }
                y += 10;
                i++;
            }
        }

        if (hud.targetInfo.value && ModuleManager.killAura != null
                && ModuleManager.killAura.isEnabled() && ModuleManager.killAura.current != null) {
            LivingEntity t = ModuleManager.killAura.current;
            String s = "Цель: " + t.getName().getString() + "  §c"
                    + String.format("%.1f", t.getHealth()) + "§f/" + (int) t.getMaxHealth();
            int sw = mc.textRenderer.getWidth(s);
            int x = HudLayout.x(HudLayout.TARGET_INFO, ctx.getScaledWindowWidth() / 2 - sw / 2, sw + 6, 12);
            int yy = HudLayout.y(HudLayout.TARGET_INFO, ctx.getScaledWindowHeight() / 2 + 14);
            ctx.fill(x - 3, yy - 2, x + mc.textRenderer.getWidth(s) + 3, yy + 10, 0x77000000);
            ctx.drawText(mc.textRenderer, s, x, yy, 0xFFFFFFFF, true);
        }

        if (hud.coords.value) {
            var p = mc.player;
            String pos = String.format("XYZ %.0f %.0f %.0f", p.getX(), p.getY(), p.getZ());
            String fps = mc.getCurrentFps() + " FPS";
            int bottom = ctx.getScaledWindowHeight();
            int cw = Math.max(mc.textRenderer.getWidth(pos), mc.textRenderer.getWidth(fps)) + 4;
            int cx = HudLayout.x("Coords", 3, cw, 20);
            int cy = HudLayout.y("Coords", bottom - 20);
            ctx.drawText(mc.textRenderer, pos, cx, cy, 0xFFE8E8F0, true);
            ctx.drawText(mc.textRenderer, fps, cx, cy + 10, 0xFF9A9AB0, true);
        }

        if (hud.binds.value) bindsHud(ctx, mc, hud);
        if (hud.potions.value) potionsHud(ctx, mc, hud);
    }

    // ------------------------------------------------------------ бинды

    private static void bindsHud(DrawContext ctx, MinecraftClient mc, ru.duo.aura.modules.HudList hud) {
        java.util.List<String[]> rows = new java.util.ArrayList<>();
        for (Module m : ModuleManager.MODULES) {
            if (m.key == org.lwjgl.glfw.GLFW.GLFW_KEY_UNKNOWN) continue;
            rows.add(new String[]{m.name, keyLabel(m.key),
                    net.minecraft.client.util.InputUtil.isKeyPressed(mc.getWindow(), m.key) ? "1" : "0"});
        }
        if (rows.isEmpty()) return;

        int wMax = 0;
        for (String[] r : rows) wMax = Math.max(wMax,
                mc.textRenderer.getWidth(r[0]) + mc.textRenderer.getWidth(r[1]) + 16);
        int w = wMax + 12, h = rows.size() * 10 + 16;
        int x = HudLayout.x("Binds", ctx.getScaledWindowWidth() - w - 4, w, h);
        int y = HudLayout.y("Binds", ctx.getScaledWindowHeight() - h - 40);

        Draw.round(ctx, x, y, x + w, y + h, 4, Theme.alpha(Theme.panel(), 190));
        Draw.round(ctx, x, y, x + 2, y + h, 1, Theme.accent());
        ctx.drawText(mc.textRenderer, "Бинды", x + 7, y + 4, Theme.accent(), false);
        int ly = y + 15;
        for (String[] r : rows) {
            boolean on = r[2].equals("1");
            ctx.drawText(mc.textRenderer, r[0], x + 7, ly, on ? 0xFF7DFFA0 : Theme.text(), false);
            ctx.drawText(mc.textRenderer, "[" + r[1] + "]",
                    x + w - mc.textRenderer.getWidth("[" + r[1] + "]") - 7, ly,
                    on ? 0xFF7DFFA0 : Theme.textDim(), false);
            ly += 10;
        }
    }

    private static final java.util.Map<Integer, String> KEY_CACHE = new java.util.HashMap<>();

    private static String keyLabel(int k) {
        String c = KEY_CACHE.get(k);
        if (c != null) return c;
        String out = keyLabelRaw(k);
        if (KEY_CACHE.size() < 128) KEY_CACHE.put(k, out);
        return out;
    }

    private static String keyLabelRaw(int k) {
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_UNKNOWN) return "—";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) return "RShift";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT) return "LShift";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCtrl";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_CONTROL) return "LCtrl";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_ALT) return "RAlt";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_ALT) return "LAlt";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_SPACE) return "Space";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_TAB) return "Tab";
        if (k == org.lwjgl.glfw.GLFW.GLFW_KEY_GRAVE_ACCENT) return "~";
        if (k >= org.lwjgl.glfw.GLFW.GLFW_KEY_F1 && k <= org.lwjgl.glfw.GLFW.GLFW_KEY_F12)
            return "F" + (k - org.lwjgl.glfw.GLFW.GLFW_KEY_F1 + 1);
        String n = org.lwjgl.glfw.GLFW.glfwGetKeyName(k, 0);
        return n == null ? String.valueOf(k) : n.toUpperCase();
    }

    // ------------------------------------------------------------ зелья

    private static void potionsHud(DrawContext ctx, MinecraftClient mc, ru.duo.aura.modules.HudList hud) {
        var effects = mc.player.getStatusEffects();
        if (effects.isEmpty()) return;

        java.util.List<String[]> rows = new java.util.ArrayList<>();
        java.util.List<Integer> colors = new java.util.ArrayList<>();
        for (var e : effects) {
            String name = e.getEffectType().value().getName().getString();
            int amp = e.getAmplifier();
            String lvl = amp > 0 ? " " + roman(amp + 1) : "";
            int dur = e.getDuration();
            String time = dur > 20 * 60 * 60 ? "∞" : String.format("%d:%02d", dur / 20 / 60, dur / 20 % 60);
            rows.add(new String[]{name + lvl, time});
            colors.add(0xFF000000 | (e.getEffectType().value().getColor() & 0xFFFFFF));
        }

        int wMax = 0;
        for (String[] r : rows) wMax = Math.max(wMax,
                mc.textRenderer.getWidth(r[0]) + mc.textRenderer.getWidth(r[1]) + 16);
        int w = wMax + 12, h = rows.size() * 10 + 16;
        int x = HudLayout.x("Potions", 4, w, h);
        int y = HudLayout.y("Potions", ctx.getScaledWindowHeight() - h - 4);

        Draw.round(ctx, x, y, x + w, y + h, 4, Theme.alpha(Theme.panel(), 190));
        Draw.round(ctx, x, y, x + 2, y + h, 1, Theme.accent());
        ctx.drawText(mc.textRenderer, "Зелья", x + 7, y + 4, Theme.accent(), false);
        int ly = y + 15;
        for (int i = 0; i < rows.size(); i++) {
            String[] r = rows.get(i);
            ctx.drawText(mc.textRenderer, r[0], x + 7, ly, colors.get(i), false);
            ctx.drawText(mc.textRenderer, r[1],
                    x + w - mc.textRenderer.getWidth(r[1]) - 7, ly, Theme.textDim(), false);
            ly += 10;
        }
    }

    private static String roman(int n) {
        String[] r = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII"};
        return n >= 1 && n <= r.length ? r[n - 1] : String.valueOf(n);
    }

    private static int rainbow(int offset) {
        float hue = ((System.currentTimeMillis() / 12 + offset * 60L) % 3600) / 3600.0f;
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(hue, 0.65f, 1.0f) & 0xFFFFFF);
    }
}
