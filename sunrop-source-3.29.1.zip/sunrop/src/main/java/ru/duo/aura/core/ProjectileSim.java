package ru.duo.aura.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

public final class ProjectileSim {

    public static final class Result {
        public final List<Vec3d> path = new ArrayList<>();
        public Vec3d land;
        public int ticks;
    }

    private ProjectileSim() {}

    public static Result simulate(Vec3d pos, Vec3d vel, double gravity, double drag, int maxTicks) {
        Result r = new Result();
        MinecraftClient mc = MinecraftClient.getInstance();
        double x = pos.x, y = pos.y, z = pos.z;
        double vx = vel.x, vy = vel.y, vz = vel.z;
        r.path.add(new Vec3d(x, y, z));
        for (int t = 0; t < maxTicks; t++) {
            double nx = x + vx, ny = y + vy, nz = z + vz;
            if (mc.world != null) {
                BlockHitResult hit = mc.world.raycast(new RaycastContext(
                        new Vec3d(x, y, z), new Vec3d(nx, ny, nz),
                        RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
                if (hit.getType() != HitResult.Type.MISS) {
                    r.land = hit.getPos();
                    r.path.add(r.land);
                    r.ticks = t + 1;
                    return r;
                }
            }
            x = nx; y = ny; z = nz;
            vx *= drag; vy *= drag; vz *= drag;
            vy -= gravity;
            r.path.add(new Vec3d(x, y, z));
            r.ticks = t + 1;
            if (y < -120 || y > 420) break;
        }
        r.land = new Vec3d(x, y, z);
        return r;
    }
}
