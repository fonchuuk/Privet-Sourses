package ru.duo.aura.core;

public final class Tps {

    private static final long[] TICKS = new long[24];
    private static int idx = 0, count = 0;
    private static double tps = 20;

    private Tps() {}

    public static void onTick() {
        long now = System.currentTimeMillis();
        TICKS[idx % TICKS.length] = now;
        idx++;
        if (count < TICKS.length) count++;
        if (count >= 2) {
            int newest = (idx - 1) % TICKS.length;
            int oldest = (idx - count + TICKS.length * 2) % TICKS.length;
            long dt = TICKS[newest] - TICKS[oldest];
            if (dt > 0) tps = Math.min(20.0, (count - 1) * 1000.0 / dt);
        }
    }

    public static double get() { return tps; }
}
