package ru.duo.aura.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.CritHelper;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class TriggerBot extends Module {

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 20, 1));
    public final Setting.Num reactionMin = add(new Setting.Num("Reaction min (ms)", 40, 0, 600, 10));
    public final Setting.Num reactionMax = add(new Setting.Num("Reaction max (ms)", 100, 0, 900, 10));
    public final Setting.Mode weapon = add(new Setting.Mode("Weapon only", 0,
            "ANY", "SWORD", "SWORD+AXE", "ANY WEAPON"));
    public final Setting.Bool lineOfSight = add(new Setting.Bool("Line of sight", false));
    public final Setting.Num maxRange = add(new Setting.Num("Max range", 3.2, 1.0, 4.5, 0.1));
    public final Setting.Mode crits = add(new Setting.Mode("Crits", 0, "OFF", "WAIT", "JUMP"));
    public final Setting.Bool unsprint = add(new Setting.Bool("Unsprint", true));
    public final Setting.Bool cooldown = add(new Setting.Bool("Vanilla cooldown", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));
    public final Setting.Bool animals = add(new Setting.Bool("Animals", true));
    public final Setting.Bool players = add(new Setting.Bool("Players", true));

    private int timer = 0;
    private Entity lastTarget = null;
    private long aimedSince = 0;
    private long lastSeen = 0;
    private long reactionNeeded = 0;
    private final java.util.Random rnd = new java.util.Random();

    public LivingEntity current = null;
    public float reactionProgress = 0f;

    public TriggerBot() {
        super("TriggerBot", "Бьёт то, на что наведён прицел", Category.SWORD, GLFW.GLFW_KEY_G);
    }

    @Override
    public String hudSuffix() {
        return crits.is("OFF") ? "" : " §7[" + crits.get() + "]";
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (p.isSpectator() || !p.isAlive()) return;

        if (timer > 0) { timer--; return; }

        long now = System.currentTimeMillis();

        if (!weaponOk(p)) { softReset(now); return; }

        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) { softReset(now); return; }

        Entity e = ((EntityHitResult) hit).getEntity();
        if (!(e instanceof LivingEntity le) || !le.isAlive()) { softReset(now); return; }
        if (!valid(le, p)) { softReset(now); return; }
        if (p.distanceTo(le) > maxRange.value) { softReset(now); return; }
        if (lineOfSight.value && !p.canSee(le)) { softReset(now); return; }

        if (lastTarget != le) {
            if (lastTarget == null || now - lastSeen > 350) {
                double lo = Math.min(reactionMin.value, reactionMax.value);
                double hi = Math.max(reactionMin.value, reactionMax.value);
                aimedSince = now;
                reactionNeeded = (long) (lo + rnd.nextDouble() * (hi - lo));
            }
            lastTarget = le;
        }
        lastSeen = now;
        current = le;
        reactionProgress = reactionNeeded <= 0 ? 1f
                : Math.min(1f, (now - aimedSince) / (float) reactionNeeded);
        ru.duo.aura.core.TargetTracker.set(le, "TriggerBot");
        if (now - aimedSince < reactionNeeded) return;

        float cd = p.getAttackCooldownProgress(0.0f);
        if (cooldown.value && cd < 0.92f) {
            if (crits.is("JUMP") && cd >= jumpCd() && CritHelper.canJump(p)) p.jump();
            return;
        }
        if (!ready(p)) return;

        mc.interactionManager.attackEntity(p, le);
        p.swingHand(Hand.MAIN_HAND);
        timer = delay.asInt() + (delay.asInt() > 0 ? rnd.nextInt(2) : 0);
    }

    private float jumpCd() {
        return cooldown.value ? 0.75f : 0f;
    }

    private void softReset(long now) {
        if (lastTarget == null) return;
        if (now - lastSeen > 350) hardReset();
    }

    private void hardReset() {
        lastTarget = null;
        current = null;
        reactionProgress = 0f;
        ru.duo.aura.core.TargetTracker.clear("TriggerBot");
    }

    private boolean ready(ClientPlayerEntity p) {
        String mode = crits.get();
        if ("OFF".equalsIgnoreCase(mode)) {
            if (unsprint.value && p.isSprinting()) p.setSprinting(false);
            return true;
        }
        if (canCritNow(p)) {
            if (unsprint.value && p.isSprinting()) p.setSprinting(false);
            return true;
        }
        if ("JUMP".equalsIgnoreCase(mode) && p.getAttackCooldownProgress(0.0f) >= jumpCd()
                && CritHelper.canJump(p)) p.jump();
        return false;
    }

    private boolean canCritNow(ClientPlayerEntity p) {
        if (p.isOnGround() || p.fallDistance <= 0.0f || p.getVelocity().y >= 0.0) return false;
        return !p.isClimbing() && !p.isTouchingWater() && !p.isInLava()
                && !p.hasVehicle() && !p.isGliding();
    }

    @Override
    public void onDisable() {
        hardReset();
        timer = 0;
    }

    private boolean weaponOk(ClientPlayerEntity p) {
        var stack = p.getMainHandStack();
        if (stack.isEmpty()) return weapon.is("ANY");
        boolean sword = stack.isIn(net.minecraft.registry.tag.ItemTags.SWORDS);
        boolean axe = stack.isIn(net.minecraft.registry.tag.ItemTags.AXES);
        boolean trident = stack.isOf(net.minecraft.item.Items.TRIDENT)
                || stack.isOf(net.minecraft.item.Items.MACE);
        return switch (weapon.get()) {
            case "SWORD" -> sword;
            case "SWORD+AXE" -> sword || axe;
            case "ANY WEAPON" -> sword || axe || trident;
            default -> true;
        };
    }

    private boolean valid(LivingEntity e, ClientPlayerEntity self) {
        if (e instanceof PlayerEntity pl) {
            if (ru.duo.aura.core.ModuleManager.friendManager != null
                    && ru.duo.aura.core.ModuleManager.friendManager.isEnabled()
                    && ru.duo.aura.core.ModuleManager.friendManager.protectFromAura.value
                    && ru.duo.aura.core.Friends.is(pl.getName().getString())) return false;
            return players.value && !self.isTeammate(pl);
        }
        if (e instanceof AnimalEntity) return animals.value;
        return mobs.value;
    }
}
