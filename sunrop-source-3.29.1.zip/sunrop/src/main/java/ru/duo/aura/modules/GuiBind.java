package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/**
 * Клавиша открытия ClickGUI. Это не режим, а бинд: нажал — открылось окно,
 * модуль сразу гаснет обратно. Клавиша меняется в карточке «Клавиша».
 */
public class GuiBind extends Module {

    public GuiBind() {
        super("ClickGUI", "Клавиша открытия меню клиента", Category.CLIENT, GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override
    public void onEnable() {
        if (mc != null) {
            ru.specclient.Lang.current = ru.duo.aura.core.Lang.russian
                    ? ru.specclient.Lang.L.RU : ru.specclient.Lang.L.EN;
            mc.setScreen(new ru.specclient.gui.ClickGuiScreen());
        }
        setEnabled(false);
    }
}
