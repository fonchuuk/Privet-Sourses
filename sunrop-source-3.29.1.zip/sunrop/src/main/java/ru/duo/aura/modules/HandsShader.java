package ru.duo.aura.modules;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class HandsShader extends Module {

    public final Setting.Mode color = add(new Setting.Mode("Color", 0,
            "ACCENT", "NEBULA", "RAINBOW", "WHITE", "RED", "GREEN", "BLUE", "PURPLE"));
    public final Setting.Num strength = add(new Setting.Num("Tint strength", 0.55, 0.05, 1.0, 0.05));
    public final Setting.Num glow = add(new Setting.Num("Glow", 0.6, 0.0, 1.0, 0.05));
    public final Setting.Num particles = add(new Setting.Num("Particles", 0.5, 0.0, 1.0, 0.05));
    public final Setting.Num hueSpeed = add(new Setting.Num("Rainbow speed", 0.6, 0.1, 3.0, 0.1));

    private int tick;

    public HandsShader() {
        super("HandsShader", "Подсветка и частицы в руках", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    public float[] rgb() {
        if (color.is("RAINBOW")) {
            float h = (System.currentTimeMillis() % (long) (6000 / Math.max(0.1, hueSpeed.value))) / (float) (6000 / Math.max(0.1, hueSpeed.value));
            return hsv(h);
        }
        if (color.is("NEBULA")) {
            long t = System.currentTimeMillis();
            float h = ((t % 4200) / 4200f + 0.62f) % 1f;
            float[] c = hsv(h);
            return new float[]{c[0] * 1.15f, c[1] * 1.15f, c[2] * 1.15f};
        }
        return switch (color.get()) {
            case "WHITE" -> new float[]{1f, 1f, 1f};
            case "RED" -> new float[]{1f, 0.25f, 0.25f};
            case "GREEN" -> new float[]{0.3f, 1f, 0.4f};
            case "BLUE" -> new float[]{0.3f, 0.5f, 1f};
            case "PURPLE" -> new float[]{0.8f, 0.35f, 1f};
            default -> new float[]{0.55f, 0.75f, 1f};
        };
    }

    private static float[] hsv(float h) {
        float r = Math.abs(h * 6 - 3) - 1;
        float g = 2 - Math.abs(h * 6 - 2);
        float b = 2 - Math.abs(h * 6 - 4);
        return new float[]{clamp01(r), clamp01(g), clamp01(b)};
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        if (particles.value <= 0.01) return;
        if (++tick % 2 != 0) return;
        if (p.getMainHandStack().isEmpty() && p.getOffHandStack().isEmpty()) return;

        float[] c = rgb();
        int n = (int) (particles.value * 3);
        for (int i = 0; i < n; i++) {
            double hx = p.getX() + (Math.random() - 0.5) * 0.7;
            double hy = p.getY() + 1.15 + (Math.random() - 0.5) * 0.55;
            double hz = p.getZ() + (Math.random() - 0.5) * 0.7;
            mc.particleManager.addParticle(ParticleTypes.ELECTRIC_SPARK,
                    hx, hy, hz,
                    (Math.random() - 0.5) * 0.04, 0.02 + Math.random() * 0.03, (Math.random() - 0.5) * 0.04);
        }
        if (p.handSwinging && p.handSwingProgress > 0.05f) {
            mc.particleManager.addParticle(ParticleTypes.END_ROD,
                    p.getX(), p.getY() + 1.2, p.getZ(),
                    (Math.random() - 0.5) * 0.1, 0.02, (Math.random() - 0.5) * 0.1);
        }
    }
}
