package ru.specclient.module;

import java.util.ArrayList;
import java.util.List;
import ru.specclient.gui.Anim;
import ru.specclient.module.setting.Setting;

public class Module {
    public final String name;
    public final Category category;
    public boolean enabled;
    public boolean expanded;
    public final List<Setting> settings = new ArrayList<>();
    public final Anim toggle = new Anim(0f, 19f);
    public final Anim expand = new Anim(0f, 13f);
    public final Anim hover = new Anim(0f, 16f);
    public final Anim enableGlow = new Anim(0f, 10f);
    public final ru.duo.aura.core.Module src;

    public Module(ru.duo.aura.core.Module src, Category category) {
        this.src = src;
        this.name = src.name;
        this.category = category;
        this.enabled = src.isEnabled();
    }

    public Module with(Setting setting) { this.settings.add(setting); return this; }

    public void setEnabled(boolean v) {
        if (this.src.isEnabled() != v) this.src.toggle();
        this.enabled = v;
        this.toggle.set(v ? 1f : 0f);
        this.enableGlow.set(v ? 1f : 0f);
    }

    public void toggleEnabled() { setEnabled(!this.enabled); }

    public void setExpanded(boolean v) {
        if (this.settings.isEmpty()) v = false;
        this.expanded = v;
        this.expand.set(v ? 1f : 0f);
    }

    public boolean hasSettings() { return !this.settings.isEmpty(); }

    public float settingsHeight() {
        if (this.settings.isEmpty()) return 0f;
        float h = 4f;
        for (Setting s : this.settings) h += s.height() + 6f;
        return h + 1f;
    }

    public void update(float dt) {
        this.enabled = this.src.isEnabled();
        this.toggle.set(this.enabled ? 1f : 0f);
        this.enableGlow.set(this.enabled ? 1f : 0f);
        this.toggle.update(dt);
        this.expand.update(dt);
        this.hover.update(dt);
        this.enableGlow.update(dt);
        for (Setting s : this.settings) s.update(dt);
    }
}
