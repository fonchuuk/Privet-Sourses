package ru.specclient.module.setting;

public class KeySetting extends Setting {
    public final ru.duo.aura.core.Setting.Key src;
    public boolean capturing;

    public KeySetting(ru.duo.aura.core.Setting.Key src) {
        super(src.name);
        this.src = src;
        this.capturing = false;
    }

    @Override public float height() { return 11f; }
}
