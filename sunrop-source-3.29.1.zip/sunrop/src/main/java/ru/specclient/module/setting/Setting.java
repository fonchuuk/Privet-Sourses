package ru.specclient.module.setting;

import ru.specclient.gui.Anim;

public abstract class Setting {
    public final String id;
    public final Anim hover = new Anim(0f, 16f);

    protected Setting(String id) { this.id = id; }

    public String label() { return ru.duo.aura.core.Lang.t(this.id); }

    public abstract float height();

    public void update(float dt) { this.hover.update(dt); }
}
