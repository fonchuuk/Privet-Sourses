package ru.specclient.module.setting;

import ru.specclient.gui.Anim;

public class NumberSetting extends Setting {
    public final ru.duo.aura.core.Setting.Num src;
    public final Anim knob = new Anim(0f, 18f);

    public NumberSetting(ru.duo.aura.core.Setting.Num src) {
        super(src.name);
        this.src = src;
        this.knob.snap((float) src.percent());
    }

    public String display() { return this.src.display(); }

    public void setProgress(double p) { this.src.setFromPercent(Math.max(0, Math.min(1, p))); }

    @Override public float height() { return 18f; }

    @Override public void update(float dt) {
        super.update(dt);
        this.knob.set((float) this.src.percent());
        this.knob.update(dt);
    }
}
