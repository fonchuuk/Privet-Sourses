package ru.specclient.module;

public enum Category {
    SWORD("Sword"), CRYSTAL("Crystal"), OPTIMIZER("Optimizer"),
    FARM("Farm"), RENDER("Render"), CLIENT("Client");

    public final String title;

    Category(String title) { this.title = title; }

    public String label() { return ru.duo.aura.core.Lang.t(this.title); }
}
