package ru.specclient.module;

import java.util.ArrayList;
import java.util.List;
import ru.specclient.module.setting.BoolSetting;
import ru.specclient.module.setting.ModeSetting;
import ru.specclient.module.setting.NumberSetting;

public final class ModuleManager {
    private static final List<Module> SHIMS = new ArrayList<>();
    private static boolean built;

    private static void build() {
        if (built) return;
        built = true;
        for (ru.duo.aura.core.Module m : ru.duo.aura.core.ModuleManager.MODULES) {
            Category cat;
            try { cat = Category.valueOf(m.category.name()); }
            catch (IllegalArgumentException e) { cat = Category.CLIENT; }
            Module sm = new Module(m, cat);
            for (ru.duo.aura.core.Setting s : m.settings) {
                if (s instanceof ru.duo.aura.core.Setting.Bool b) sm.with(new BoolSetting(b));
                else if (s instanceof ru.duo.aura.core.Setting.Num n) sm.with(new NumberSetting(n));
                else if (s instanceof ru.duo.aura.core.Setting.Mode mo) sm.with(new ModeSetting(mo));
                else if (s instanceof ru.duo.aura.core.Setting.Key k) sm.with(new ru.specclient.module.setting.KeySetting(k));
            }
            SHIMS.add(sm);
        }
    }

    public static void rebuild() {
        built = false;
        SHIMS.clear();
    }

    public static List<Module> byCategory(Category c) {
        build();
        List<Module> out = new ArrayList<>();
        for (Module m : SHIMS) if (m.category == c) out.add(m);
        return out;
    }

    public static void update(float dt) {
        build();
        ru.specclient.Lang.current = ru.duo.aura.core.Lang.russian
                ? ru.specclient.Lang.L.RU : ru.specclient.Lang.L.EN;
        for (Module m : SHIMS) m.update(dt);
    }
}
