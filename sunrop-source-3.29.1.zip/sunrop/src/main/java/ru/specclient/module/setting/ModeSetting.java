package ru.specclient.module.setting;

import ru.specclient.gui.Anim;

public class ModeSetting extends Setting {
    public final ru.duo.aura.core.Setting.Mode src;
    public final Anim slide = new Anim(0f, 14f);
    public int index;

    public ModeSetting(ru.duo.aura.core.Setting.Mode src) {
        super(src.name);
        this.src = src;
        this.index = src.index;
        this.slide.snap(src.index);
    }

    public int count() { return this.src.modes.length; }

    public String option(int i) { return this.src.modes[i]; }

    public void select(int i) {
        if (i < 0) i = this.src.modes.length - 1;
        else if (i >= this.src.modes.length) i = 0;
        this.src.index = i;
        this.index = i;
    }

    @Override public float height() { return 23f; }

    @Override public void update(float dt) {
        super.update(dt);
        this.index = this.src.index;
        this.slide.set(this.src.index);
        this.slide.update(dt);
    }
}
