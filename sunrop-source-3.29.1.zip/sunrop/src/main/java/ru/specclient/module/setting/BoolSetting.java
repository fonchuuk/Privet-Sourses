package ru.specclient.module.setting;

import ru.specclient.gui.Anim;

public class BoolSetting extends Setting {
    public final ru.duo.aura.core.Setting.Bool src;
    public final Anim anim = new Anim(0f, 16f);

    public BoolSetting(ru.duo.aura.core.Setting.Bool src) {
        super(src.name);
        this.src = src;
        this.anim.snap(src.value ? 1f : 0f);
    }

    public void toggle() { this.src.toggle(); }

    @Override public float height() { return 9f; }

    @Override public void update(float dt) {
        super.update(dt);
        this.anim.set(this.src.value ? 1f : 0f);
        this.anim.update(dt);
    }
}
