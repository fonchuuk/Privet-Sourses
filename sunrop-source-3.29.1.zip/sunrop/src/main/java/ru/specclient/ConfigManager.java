package ru.specclient;

public final class ConfigManager {

    public static void save() {
        ru.duo.aura.ConfigFile.save();
    }

    public static String toJson() {
        StringBuilder sb = new StringBuilder("# sunrop-clipboard:1\n");
        for (ru.duo.aura.core.Module m : ru.duo.aura.core.ModuleManager.MODULES) {
            sb.append("M;").append(m.name).append(';').append(m.isEnabled() ? 1 : 0)
                    .append(';').append(m.key).append('\n');
            for (ru.duo.aura.core.Setting s : m.settings) {
                sb.append("S;").append(m.name).append(';').append(s.name).append(';')
                        .append(s.serialize()).append('\n');
            }
        }
        return sb.toString();
    }

    public static boolean fromJson(String clip) {
        if (clip == null || !clip.startsWith("# sunrop-clipboard:1")) return false;
        for (String line : clip.split("\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] p = line.split(";", 4);
            if (p.length < 3) continue;
            ru.duo.aura.core.Module m = find(p[1]);
            if (m == null) continue;
            if (p[0].equals("M") && p.length >= 4) {
                try { m.key = Integer.parseInt(p[3].trim()); } catch (NumberFormatException ignored) {}
                boolean on = p[2].equals("1");
                if (on != m.isEnabled()) m.toggle();
            } else if (p[0].equals("S") && p.length == 4) {
                for (ru.duo.aura.core.Setting s : m.settings) {
                    if (s.name.equals(p[2])) { s.deserialize(p[3]); break; }
                }
            }
        }
        return true;
    }

    private static ru.duo.aura.core.Module find(String name) {
        for (ru.duo.aura.core.Module m : ru.duo.aura.core.ModuleManager.MODULES)
            if (m.name.equals(name)) return m;
        return null;
    }
}
