/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.CharInput
 *  net.minecraft.KeyInput
 *  net.minecraft.Click
 *  net.minecraft.Text
 *  net.minecraft.DrawContext
 *  net.minecraft.MathHelper
 *  net.minecraft.Screen
 *  org.joml.Matrix3x2fStack
 */
package ru.specclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.joml.Matrix3x2fStack;
import ru.specclient.ConfigManager;
import ru.specclient.Lang;
import ru.specclient.SpecClientMod;
import ru.specclient.gui.Anim;
import ru.specclient.gui.Fonts;
import ru.specclient.gui.R2;
import ru.specclient.module.Category;
import ru.specclient.module.Module;
import ru.specclient.module.ModuleManager;
import ru.specclient.module.setting.BoolSetting;
import ru.specclient.module.setting.ModeSetting;
import ru.specclient.module.setting.NumberSetting;
import ru.specclient.module.setting.Setting;

public class ClickGuiScreen
extends Screen {
    private static final float PAD_X = 22.0f;
    private static final float HEADER_H = 88.0f;
    private static final float FOOTER_H = 52.0f;
    private static final float CARD_H = 22.0f;
    private static final float CARD_GAP = 6.5f;
    private static final float INNER = 7.0f;
    private static final float RADIUS = 9.0f;
    private static final float TOGGLE_W = 20.0f;
    private static final float TOGGLE_H = 10.0f;
    private static final float TOGGLE_MARGIN = 8.0f;
    private float panelX;
    private float panelY;
    private float panelW;
    private float panelH;
    private float contentTop;
    private float contentBottom;
    private float colPitch;
    private float cardW;
    private float searchX;
    private float searchY;
    private float searchW;
    private float searchH;
    private float importX;
    private float importW;
    private float exportX;
    private float exportW;
    private float boostX;
    private float boostW;
    private final Anim boostHover = new Anim(0.0f, 16.0f);
    private float langX;
    private float langW;
    private float btnY;
    private float btnH;
    private final Anim openAnim = new Anim(0.0f, 12.0f);
    private boolean closing;
    private float time;
    private float dt;
    private long lastFrame;
    private String query = "";
    private boolean searchFocused;
    private final Anim searchAnim = new Anim(0.0f, 16.0f);
    private final Anim[] scrollAnim = new Anim[Category.values().length];
    private final float[] scrollTarget = new float[Category.values().length];
    private final float[] contentH = new float[Category.values().length];
    private final Anim importHover = new Anim(0.0f, 17.0f);
    private final Anim exportHover = new Anim(0.0f, 17.0f);
    private final Anim langSlide = new Anim(0.0f, 17.0f);
    private NumberSetting dragging;
    private ru.specclient.module.setting.KeySetting capturingKey;
    private float dragTrackX;
    private float dragTrackW;
    private String toastText = "";
    private float toastLife;
    private final Anim toastAnim = new Anim(0.0f, 14.0f);
    private int mouseX;
    private int mouseY;
    private boolean errorLogged;
    private final List<CardRect> cards = new ArrayList<CardRect>();
    private static final net.minecraft.util.Identifier MENU_BG =
            net.minecraft.util.Identifier.of("specclient", "textures/gui/menu_bg.png");
    private static final Category[] CATS = Category.values();
    private String visQuery = null;
    private final List<Module>[] visCache = new List[CATS.length];

    public ClickGuiScreen() {
        super((Text)Text.literal((String)"SpecClient"));
        for (int i = 0; i < this.scrollAnim.length; ++i) {
            this.scrollAnim[i] = new Anim(0.0f, 15.0f);
        }
    }

    protected void init() {
        this.lastFrame = 0L;
        this.openAnim.set(1.0f);
        this.langSlide.snap(Lang.current == Lang.L.EN ? 0.0f : 1.0f);
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        if (!this.closing) {
            this.closing = true;
            this.openAnim.set(0.0f);
            this.searchFocused = false;
            ConfigManager.save();
        }
    }

    public void removed() {
        ConfigManager.save();
    }

    private void tickTime() {
        long now = System.nanoTime();
        if (this.lastFrame == 0L) {
            this.lastFrame = now;
        }
        this.dt = Math.min(0.1f, (float)(now - this.lastFrame) / 1.0E9f);
        this.lastFrame = now;
        this.time += this.dt;
    }

    private List<Module> visible(Category category) {
        String q = this.query.trim().toLowerCase(Locale.ROOT);
        if (this.visQuery == null || !q.equals(this.visQuery)) {
            this.visQuery = q;
            for (int i = 0; i < CATS.length; ++i) this.visCache[i] = null;
        }
        int idx = category.ordinal();
        List<Module> cached = this.visCache[idx];
        if (cached != null) return cached;
        ArrayList<Module> out = new ArrayList<Module>();
        for (Module m : ModuleManager.byCategory(CATS[idx])) {
            if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(m);
        }
        this.visCache[idx] = out;
        return out;
    }

    private void layout() {
        this.panelW = MathHelper.clamp((float)((float)this.width * 0.9f), (float)300.0f, (float)580.0f);
        this.panelH = MathHelper.clamp((float)((float)this.height * 0.86f), (float)196.0f, (float)350.0f);
        this.panelX = Math.round(((float)this.width - this.panelW) * 0.5f);
        this.panelY = Math.round(((float)this.height - this.panelH) * 0.5f);
        this.contentTop = this.panelY + 88.0f;
        this.contentBottom = this.panelY + this.panelH - 52.0f;
        Category[] cats = CATS;
        this.colPitch = (this.panelW - 44.0f) / (float)cats.length;
        this.cardW = this.colPitch - 14.5f;
        this.searchW = MathHelper.clamp((float)(this.panelW * 0.35f), (float)150.0f, (float)210.0f);
        this.searchH = 18.0f;
        this.searchX = this.panelX + (this.panelW - this.searchW) * 0.5f;
        this.searchY = this.panelY + this.panelH - 42.0f;
        this.btnY = this.panelY + 48.0f;
        this.btnH = 15.0f;
        this.langW = 42.0f;
        this.langX = this.panelX + this.panelW - 22.0f - this.langW;
        this.exportW = (float)R2.width(Fonts.ui(Lang.exportBtn())) + 13.0f;
        this.exportX = this.langX - 7.0f - this.exportW;
        this.importW = (float)R2.width(Fonts.ui(Lang.importBtn())) + 13.0f;
        this.importX = this.exportX - 6.0f - this.importW;
        this.boostW = (float)R2.width(Fonts.ui(Lang.boostBtn())) + 13.0f;
        this.boostX = this.importX - 6.0f - this.boostW;
        int ci = 0;
        for (int i = 0; i < cats.length; ++i) {
            float colX = this.panelX + 22.0f + (float)i * this.colPitch;
            float y = this.contentTop - this.scrollAnim[i].get();
            float total = 0.0f;
            for (Module m : this.visible(cats[i])) {
                float h = 22.0f + m.expand.get() * m.settingsHeight();
                if (ci < this.cards.size()) {
                    CardRect c = this.cards.get(ci);
                    c.module = m; c.col = i; c.x = colX; c.y = y; c.w = this.cardW; c.h = h;
                } else {
                    this.cards.add(new CardRect(m, i, colX, y, this.cardW, h));
                }
                ++ci;
                y += h + 6.5f;
                total += h + 6.5f;
            }
            this.contentH[i] = Math.max(0.0f, total - 6.5f);
        }
        while (this.cards.size() > ci) this.cards.remove(this.cards.size() - 1);
    }

    private float maxScroll(int col) {
        return Math.max(0.0f, this.contentH[col] - (this.contentBottom - this.contentTop));
    }

    public void render(DrawContext ctx, int mx, int my, float delta) {
        block3: {
            try {
                this.renderGui(ctx, mx, my, delta);
            }
            catch (Throwable error) {
                R2.globalAlpha = 1.0f;
                if (!this.errorLogged) {
                    this.errorLogged = true;
                    SpecClientMod.LOGGER.error("[SpecClient] \u041e\u0448\u0438\u0431\u043a\u0430 \u043e\u0442\u0440\u0438\u0441\u043e\u0432\u043a\u0438 \u043c\u0435\u043d\u044e \u2014 \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e GUI \u0432\u043c\u0435\u0441\u0442\u043e \u043a\u0440\u0430\u0448\u0430", error);
                }
                if (this.client == null) break block3;
                this.client.setScreen(null);
            }
        }
    }

    private void renderGui(DrawContext ctx, int mx, int my, float delta) {
        this.mouseX = mx;
        this.mouseY = my;
        this.tickTime();
        this.updateAnimations();
        this.layout();
        if (this.closing && this.openAnim.get() < 0.015f) {
            if (this.client != null) {
                this.client.setScreen(null);
            }
            return;
        }
        this.renderBackground(ctx, mx, my, delta);
        float t = Anim.easeOutCubic(this.openAnim.get());
        R2.globalAlpha = Anim.clamp01(this.openAnim.get() * 1.25f);
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        float cx = this.panelX + this.panelW * 0.5f;
        float cy = this.panelY + this.panelH * 0.5f;
        float scale = 0.95f + 0.05f * t;
        m.translate(cx, cy);
        m.scale(scale, scale);
        m.translate(-cx, -cy);
        m.translate(0.0f, (1.0f - t) * 12.0f);
        this.drawPanel(ctx);
        m.popMatrix();
        R2.globalAlpha = 1.0f;
    }

    private void updateAnimations() {
        this.openAnim.update(this.dt);
        this.searchAnim.set(this.searchFocused ? 1.0f : 0.0f);
        this.searchAnim.update(this.dt);
        this.importHover.update(this.dt);
        this.exportHover.update(this.dt);
        this.boostHover.update(this.dt);
        this.langSlide.update(this.dt);
        this.toastAnim.update(this.dt);
        for (int i = 0; i < this.scrollAnim.length; ++i) {
            this.scrollAnim[i].set(this.scrollTarget[i]);
            this.scrollAnim[i].update(this.dt);
        }
        ModuleManager.update(this.dt);
        if (this.toastLife > 0.0f) {
            this.toastLife -= this.dt;
            if (this.toastLife <= 0.0f) {
                this.toastAnim.set(0.0f);
            }
        }
    }

    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        float a = Anim.clamp01(this.openAnim.get() * 1.2f);
        float scale = Math.max((float) this.width / 1920.0f, (float) this.height / 1080.0f);
        int dw = (int) (1920.0f * scale);
        int dh = (int) (1080.0f * scale);
        int dx = (int) (((float) this.width - dw) * 0.5f);
        int dy = (int) (((float) this.height - dh) * 0.5f);
        ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, MENU_BG,
                dx, dy, 0.0f, 0.0f, dw, dh, 1920, 1080, R2.alpha(-1, a));
        ctx.fill(0, 0, this.width, this.height, R2.alpha(-16777216, 0.30f * a));
        ctx.fillGradient(0, 0, this.width, (int)((float)this.height * 0.28f), R2.alpha(-16777216, 0.22f * a), 0);
        ctx.fillGradient(0, (int)((float)this.height * 0.72f), this.width, this.height, 0, R2.alpha(-16777216, 0.30f * a));
    }

    private void drawAmbience(DrawContext ctx) {
    }

    private void clipBlobs(DrawContext ctx, float x0, float y0, float x1, float y1) {
        if (x1 - x0 < 1.0f || y1 - y0 < 1.0f) {
            return;
        }
        ctx.enableScissor((int)Math.floor(x0), (int)Math.floor(y0), (int)Math.ceil(x1), (int)Math.ceil(y1));
        this.blob(ctx, 0.18f + 0.11f * this.sin(0.30f), 0.22f + 0.12f * this.cos(0.24f), 0.85f, this.wheel(0.00f, 0.60f, 0.72f), 0.3f);
        this.blob(ctx, 0.82f + 0.10f * this.cos(0.21f), 0.18f + 0.12f * this.sin(0.27f), 0.7f, this.wheel(0.25f, 0.55f, 0.68f), 0.26f);
        this.blob(ctx, 0.66f + 0.12f * this.sin(0.18f), 0.86f + 0.10f * this.cos(0.22f), 0.95f, this.wheel(0.50f, 0.55f, 0.62f), 0.24f);
        this.blob(ctx, 0.12f + 0.11f * this.cos(0.17f), 0.88f + 0.09f * this.sin(0.19f), 0.65f, this.wheel(0.75f, 0.60f, 0.70f), 0.22f);
        this.dust(ctx);
        ctx.disableScissor();
    }

    private float sin(float speed) {
        return (float)Math.sin(this.time * speed);
    }

    private float cos(float speed) {
        return (float)Math.cos(this.time * speed);
    }

    private int wheel(float phase, float sat, float bri) {
        float hue = (this.time * 0.045f + phase) % 1.0f;
        if (hue < 0.0f) {
            hue += 1.0f;
        }
        return java.awt.Color.HSBtoRGB(hue, sat, bri) & 0xFFFFFF;
    }

    private void blob(DrawContext ctx, float fx, float fy, float fr, int rgb, float alpha) {
        float r = Math.max(this.panelW, this.panelH) * fr * 0.34f;
        int color = (int)(Anim.clamp01(alpha) * R2.globalAlpha * 255.0f) << 24 | rgb & 0xFFFFFF;
        R2.glow(ctx, this.panelX + this.panelW * fx, this.panelY + this.panelH * fy, r, color);
    }

    private void dust(DrawContext ctx) {
        for (int i = 0; i < 8; ++i) {
            float seedX = (float)i * 73.13f % 1.0f;
            float seedY = (float)i * 37.77f % 1.0f;
            float speed = 0.006f + (float)(i * 13 % 7) * 0.0022f;
            float x = this.panelX + (seedX + (float)Math.sin(this.time * 0.08f + (float)i) * 0.012f) * this.panelW;
            float y = this.panelY + ((seedY - this.time * speed) % 1.0f + 1.0f) % 1.0f * this.panelH;
            float rr = 0.5f + (float)(i * 17 % 5) * 0.2f;
            float alpha = 0.07f + (float)(i * 29 % 9) * 0.016f;
            R2.circle(ctx, x, y, rr, R2.c(0xFF000000 | this.wheel((float)i * 0.045f, 0.22f, 0.72f), alpha));
        }
    }

    private void drawPanel(DrawContext ctx) {
        R2.shadow(ctx, this.panelX, this.panelY, this.panelW, this.panelH, 9.0f, R2.c(-16777216, 0.55f));
        R2.round(ctx, this.panelX, this.panelY, this.panelW, this.panelH, 9.0f, R2.c(-15064784));
        R2.round(ctx, this.panelX + 1.0f, this.panelY + 1.0f, this.panelW - 2.0f, this.panelH - 2.0f, 8.0f, R2.c(0x14FFFFFF));
        R2.round(ctx, this.panelX + 2.0f, this.panelY + 2.0f, this.panelW - 4.0f, this.panelH - 4.0f, 7.0f, R2.c(-603452655));
        this.drawAmbience(ctx);
        R2.round(ctx, this.panelX + 2.0f, this.panelY + 2.0f, this.panelW - 4.0f, 78.0f, 7.0f, R2.c(-1978920679, 0.5f));
        this.drawTitle(ctx);
        this.drawTopButtons(ctx);
        this.drawColumns(ctx);
        this.drawSearch(ctx);
        this.drawToast(ctx);
    }

    private void drawTitle(DrawContext ctx) {
        Text spec = Fonts.title("Spec");
        Text client = Fonts.title("Client");
        float total = R2.width(spec) + R2.width(client);
        float tx = this.panelX + (this.panelW - total) * 0.5f;
        float ty = this.panelY + 42.0f;
        float pulse = 0.65f + 0.35f * (float)Math.sin(this.time * 1.1f);
        R2.glow(ctx, this.panelX + this.panelW * 0.5f, ty + 5.0f, 54.0f, R2.c(0x20000000 | this.wheel(0.10f, 0.55f, 0.85f), pulse));
        R2.text(ctx, spec, tx, ty, R2.c(-12877066));
        R2.text(ctx, client, tx + (float)R2.width(spec), ty, R2.c(-1446410));
    }

    private void drawTopButtons(DrawContext ctx) {
        boolean impHover = R2.hover(this.mouseX, this.mouseY, this.importX, this.btnY, this.importW, this.btnH);
        boolean bstHover = R2.hover(this.mouseX, this.mouseY, this.boostX, this.btnY, this.boostW, this.btnH);
        boolean expHover = R2.hover(this.mouseX, this.mouseY, this.exportX, this.btnY, this.exportW, this.btnH);
        this.boostHover.set(bstHover ? 1.0f : 0.0f);
        this.importHover.set(impHover ? 1.0f : 0.0f);
        this.exportHover.set(expHover ? 1.0f : 0.0f);
        boolean optOn = ru.duo.aura.core.ModuleManager.optimizer != null
                && ru.duo.aura.core.ModuleManager.optimizer.isEnabled();
        this.drawButton(ctx, this.boostX, this.boostW, Lang.boostBtn(),
                Math.max(this.boostHover.get(), optOn ? 0.55f : 0.0f));
        if (optOn) {
            R2.round(ctx, this.boostX + 3.0f, this.btnY + this.btnH - 2.5f, this.boostW - 6.0f, 1.5f, 1.0f, R2.c(-12877066));
        }
        this.drawButton(ctx, this.importX, this.importW, Lang.importBtn(), this.importHover.get());
        this.drawButton(ctx, this.exportX, this.exportW, Lang.exportBtn(), this.exportHover.get());
        R2.panel(ctx, this.langX, this.btnY, this.langW, this.btnH, 5.0f, R2.c(-15722975), R2.c(-14472390), 1.0f);
        float half = (this.langW - 2.0f) * 0.5f;
        float sel = this.langSlide.get();
        R2.round(ctx, this.langX + 1.0f + sel * half, this.btnY + 1.0f, half, this.btnH - 2.0f, 4.0f, R2.c(-12877066));
        int enColor = R2.c(R2.mix(-6774349, -1, 1.0f - sel));
        int ruColor = R2.c(R2.mix(-6774349, -1, sel));
        R2.textCentered(ctx, Fonts.tiny("EN"), this.langX + 1.0f + half * 0.5f, this.btnY + 4.8f, enColor);
        R2.textCentered(ctx, Fonts.tiny("RU"), this.langX + 1.0f + half * 1.5f, this.btnY + 4.8f, ruColor);
    }

    private void drawButton(DrawContext ctx, float x, float w, String label, float hover) {
        int bg = R2.mix(-15722975, -15130321, hover);
        int border = R2.mix(-14472390, -14326805, hover * 0.75f);
        R2.panel(ctx, x, this.btnY, w, this.btnH, 5.0f, R2.c(bg), R2.c(border), 1.0f);
        int color = R2.c(R2.mix(-6774349, -1446410, hover));
        R2.textCentered(ctx, Fonts.ui(label), x + w * 0.5f, this.btnY + 4.5f, color);
    }

    private void drawColumns(DrawContext ctx) {
        Category[] cats = CATS;
        for (int i = 0; i < cats.length; ++i) {
            float colX = this.panelX + 22.0f + (float)i * this.colPitch;
            R2.text(ctx, Fonts.tiny(cats[i].label()), colX + 1.0f, this.contentTop - 13.0f, R2.c(-8156003));
            if (i >= cats.length - 1) continue;
            this.vSeparator(ctx, colX + this.colPitch - 7.5f, this.contentTop - 17.0f, this.contentBottom);
        }
        if (this.cards.isEmpty()) {
            R2.textCentered(ctx, Fonts.ui(Lang.nothingFound()), this.panelX + this.panelW * 0.5f, this.contentTop + 26.0f, R2.c(-11774619));
            return;
        }
        int top = (int)Math.floor(this.contentTop - 4.0f);
        int bottom = (int)Math.ceil(this.contentBottom + 4.0f);
        ctx.enableScissor((int)this.panelX + 2, top, (int)(this.panelX + this.panelW) - 2, bottom);
        for (CardRect card : this.cards) {
            if (card.y > this.contentBottom + 8.0f || card.y + card.h < this.contentTop - 8.0f) {
                card.module.hover.set(0.0f);
                continue;
            }
            this.drawCard(ctx, card);
        }
        ctx.disableScissor();
    }

    private void vSeparator(DrawContext ctx, float x, float y0, float y1) {
        float fade = 16.0f;
        int steps = 6;
        for (int i = 0; i < steps; ++i) {
            float a = ((float)i + 0.5f) / (float)steps;
            float h = fade / (float)steps;
            R2.rect(ctx, x, y0 + (float)i * h, x + 0.9f, y0 + (float)(i + 1) * h, R2.c(-15328217, a));
            R2.rect(ctx, x, y1 - (float)(i + 1) * h, x + 0.9f, y1 - (float)i * h, R2.c(-15328217, a));
        }
        R2.rect(ctx, x, y0 + fade, x + 0.9f, y1 - fade, R2.c(-15328217));
    }

    private void drawCard(DrawContext ctx, CardRect card) {
        Module m = card.module;
        float x = card.x;
        float y = card.y;
        float w = card.w;
        boolean hovered = R2.hover(this.mouseX, this.mouseY, x, y, w, 22.0f) && (float)this.mouseY >= this.contentTop - 4.0f && (float)this.mouseY <= this.contentBottom + 4.0f;
        m.hover.set(hovered ? 1.0f : 0.0f);
        float hv = m.hover.get();
        float en = m.enableGlow.get();
        float ex = m.expand.get();
        int bgOff = R2.mix(-15986666, -15591131, hv);
        int bgOn = R2.mix(-15656147, -15326405, hv);
        int bg = R2.mix(bgOff, bgOn, en);
        int border = R2.mix(-15262423, -14204049, en);
        if (en > 0.01f) {
            R2.softGlow(ctx, x + w * 0.5f, y + 11.0f, w * 0.72f, R2.c(507216630, en));
        }
        R2.panel(ctx, x, y, w, card.h, 5.0f, R2.c(bg), R2.c(border), 1.0f);
        int nameColor = R2.c(R2.mix(-3747874, -1446410, Math.max(en, hv * 0.6f)));
        R2.text(ctx, Fonts.bold(m.name), x + 7.0f, y + 7.0f, nameColor);
        float tx = x + w - 8.0f - 20.0f;
        float ty = y + 6.0f;
        this.drawToggle(ctx, tx, ty, 20.0f, 10.0f, m.toggle.get(), hv);
        float chevVisible = Math.max(hv, ex);
        if (m.hasSettings() && chevVisible > 0.01f) {
            int chevColor = R2.c(R2.mix(-11774619, -6774349, chevVisible), chevVisible);
            this.chevron(ctx, tx - 10.0f, y + 11.0f - 0.5f, ex, chevColor);
        }
        if (ex > 0.004f) {
            this.drawSettings(ctx, card, ex);
        }
    }

    private void drawToggle(DrawContext ctx, float x, float y, float w, float h, float t, float hv) {
        int off = R2.mix(-13946307, -13024945, hv);
        int track = R2.mix(off, -12877066, t);
        R2.round(ctx, x, y, w, h, h * 0.5f, R2.c(track));
        float knobR = h * 0.5f - 1.5f;
        float knobX = x + h * 0.5f + t * (w - h);
        R2.circle(ctx, knobX, y + h * 0.5f + 0.35f, knobR, R2.c(-16777216, 0.25f));
        R2.circle(ctx, knobX, y + h * 0.5f, knobR, R2.c(R2.mix(-3945770, -722948, t)));
    }

    private void chevron(DrawContext ctx, float cx, float cy, float t, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        m.rotate((float)Math.PI * Anim.easeOutCubic(t));
        R2.rotRect(ctx, -1.25f, 0.0f, 3.9f, 1.15f, 0.7853982f, color);
        R2.rotRect(ctx, 1.25f, 0.0f, 3.9f, 1.15f, -0.7853982f, color);
        m.popMatrix();
    }

    private void drawSettings(DrawContext ctx, CardRect card, float ex) {
        Module m = card.module;
        float x = card.x;
        float w = card.w;
        float clipTop = card.y + 22.0f;
        float clipBottom = card.y + card.h;
        ctx.enableScissor((int)Math.floor(x), (int)Math.floor(clipTop), (int)Math.ceil(x + w), (int)Math.ceil(clipBottom));
        float sy = card.y + 22.0f + 4.0f;
        int index = 0;
        for (Setting s : m.settings) {
            float stagger = Anim.clamp01((ex - (float)index * 0.055f) / 0.55f);
            float a = Anim.easeOutCubic(stagger);
            float rowY = sy - (1.0f - a) * (7.0f + (float)index * 1.5f);
            if (s instanceof ModeSetting) {
                ModeSetting mode = (ModeSetting)s;
                this.drawMode(ctx, mode, x, rowY, w, a);
            } else if (s instanceof NumberSetting) {
                NumberSetting number = (NumberSetting)s;
                this.drawSlider(ctx, number, x, rowY, w, a);
            } else if (s instanceof ru.specclient.module.setting.KeySetting ks) {
                this.drawKeyRow(ctx, ks, x, rowY, w, a);
            } else if (s instanceof BoolSetting) {
                BoolSetting bool = (BoolSetting)s;
                this.drawCheckbox(ctx, bool, x, rowY, w, a);
            }
            sy += s.height() + 6.0f;
            ++index;
        }
        ctx.disableScissor();
    }

    private void drawMode(DrawContext ctx, ModeSetting s, float x, float y, float w, float a) {
        R2.text(ctx, Fonts.tiny(s.label()), x + 7.0f, y, R2.c(-8156003, a));
        float bx = x + 7.0f;
        float by = y + 10.0f;
        float bw = w - 14.0f;
        float bh = 13.0f;
        R2.panel(ctx, bx, by, bw, bh, 4.0f, R2.c(-16184044, a), R2.c(-14998992, a), 1.0f);
        String cur = s.option(Math.max(0, Math.min(s.count() - 1, s.index)));
        int arr = R2.c(-6774349, a);
        float acy = by + bh * 0.5f;
        R2.rect(ctx, bx + 5.0f, acy - 0.5f, bx + 11.0f, acy + 0.5f, arr);
        R2.rect(ctx, bx + 6.0f, acy - 1.5f, bx + 7.0f, acy + 1.5f, arr);
        R2.rect(ctx, bx + bw - 11.0f, acy - 0.5f, bx + bw - 5.0f, acy + 0.5f, arr);
        R2.rect(ctx, bx + bw - 7.0f, acy - 1.5f, bx + bw - 6.0f, acy + 1.5f, arr);
        R2.textCentered(ctx, Fonts.tiny(cur), bx + bw * 0.5f, by + 4.0f, R2.c(-1, a));
    }

    private void drawSlider(DrawContext ctx, NumberSetting s, float x, float y, float w, float a) {
        R2.text(ctx, Fonts.tiny(s.label()), x + 7.0f, y, R2.c(-8156003, a));
        R2.textRight(ctx, Fonts.tiny(s.display()), x + w - 7.0f, y, R2.c(-8540417, a));
        float tx = x + 7.0f;
        float tw = w - 14.0f;
        float ty = y + 14.0f;
        float th = 3.0f;
        R2.round(ctx, tx, ty, tw, th, th * 0.5f, R2.c(-14538185, a));
        float p = Anim.clamp01(s.knob.get());
        R2.round(ctx, tx, ty, Math.max(th, tw * p), th, th * 0.5f, R2.c(-12877066, a));
        float kx = tx + tw * p;
        boolean active = this.dragging == s;
        float r = active ? 3.9f : 3.3f;
        R2.circle(ctx, kx, ty + th * 0.5f, r + 2.0f, R2.c(1429963510, a * 0.45f));
        R2.circle(ctx, kx, ty + th * 0.5f + 0.4f, r, R2.c(-16777216, a * 0.3f));
        R2.circle(ctx, kx, ty + th * 0.5f, r, R2.c(-722948, a));
    }

    private void drawCheckbox(DrawContext ctx, BoolSetting s, float x, float y, float w, float a) {
        float v = s.anim.get();
        float bx = x + 7.0f;
        float by = y + 0.5f;
        float size = 7.5f;
        int fill = R2.mix(-16118251, -12877066, v);
        int border = R2.mix(-14011582, -12877066, v);
        R2.panel(ctx, bx, by, size, size, 2.2f, R2.c(fill, a), R2.c(border, a), 1.0f);
        if (v > 0.03f) {
            this.check(ctx, bx + size * 0.5f, by + size * 0.5f, 3.8f * v, R2.c(-1, a * v));
        }
        int color = R2.c(R2.mix(-6774349, -1446410, 0.25f + 0.75f * v), a);
        R2.text(ctx, Fonts.ui(s.label()), bx + size + 5.0f, y + 1.0f, color);
    }

    private void check(DrawContext ctx, float cx, float cy, float s, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy - 0.3f);
        m.rotate(-0.7853982f);
        float th = 1.15f;
        R2.rect(ctx, -s * 0.55f, s * 0.18f, s * 0.75f, s * 0.18f + th, color);
        R2.rect(ctx, -s * 0.55f, -s * 0.6f, -s * 0.55f + th, s * 0.18f + th, color);
        m.popMatrix();
    }

    private void drawKeyRow(DrawContext ctx, ru.specclient.module.setting.KeySetting ks, float x, float y, float w, float a) {
        String label = ks.capturing ? ks.label() + " ..." : ks.label();
        R2.text(ctx, Fonts.tiny(label), x + 7.0f, y + 1.5f, R2.c(-8156003, a));
        String keyName = ks.capturing ? "?" : ks.src.display();
        float kw = (float) R2.width(Fonts.tiny(keyName)) + 10.0f;
        float kx = x + w - 7.0f - kw;
        R2.round(ctx, kx, y, kw, 11.0f, 3.0f, R2.c(ks.capturing ? -12877066 : -16184044, a));
        R2.textCentered(ctx, Fonts.tiny(keyName), kx + kw * 0.5f, y + 3.0f, R2.c(-1, a));
    }

    private void drawSearch(DrawContext ctx) {
        float focus = this.searchAnim.get();
        int border = R2.mix(-15065044, -13672530, focus);
        if (focus > 0.02f) {
            R2.softGlow(ctx, this.searchX + this.searchW * 0.5f, this.searchY + this.searchH * 0.5f, this.searchW * 0.55f, R2.c(1429963510, focus * 0.35f));
        }
        R2.panel(ctx, this.searchX, this.searchY, this.searchW, this.searchH, 6.0f, R2.c(-16184045), R2.c(border), 1.0f);
        float icx = this.searchX + 12.0f;
        float icy = this.searchY + this.searchH * 0.5f - 0.6f;
        int iconColor = R2.c(R2.mix(-11774619, -6774349, focus));
        R2.circle(ctx, icx, icy, 2.9f, iconColor);
        R2.circle(ctx, icx, icy, 2.0f, R2.c(-16184045));
        R2.rotRect(ctx, icx + 2.9f, icy + 2.9f, 3.0f, 1.0f, 0.7853982f, iconColor);
        boolean empty = this.query.isEmpty();
        Text shown = Fonts.ui(empty ? Lang.search() : this.query);
        int color = R2.c(empty ? -11774619 : -1446410);
        R2.text(ctx, shown, this.searchX + 20.0f, this.searchY + 6.0f, color);
        if (this.searchFocused && (int)(this.time * 2.0f) % 2 == 0) {
            float caretX = this.searchX + 20.0f + (empty ? 0.0f : (float)R2.width(shown)) + 1.5f;
            R2.rect(ctx, caretX, this.searchY + 4.5f, caretX + 0.9f, this.searchY + this.searchH - 4.5f, R2.c(-8540417));
        }
    }

    private void drawToast(DrawContext ctx) {
        float a = this.toastAnim.get();
        if (a < 0.01f || this.toastText.isEmpty()) {
            return;
        }
        Text text = Fonts.ui(this.toastText);
        float w = (float)R2.width(text) + 20.0f;
        float h = 17.0f;
        float x = this.panelX + this.panelW - 22.0f - w;
        float y = this.panelY + this.panelH - 66.0f + (1.0f - a) * 10.0f;
        R2.panel(ctx, x, y, w, h, 5.0f, R2.c(-15985886, a), R2.c(-14326805, a * 0.8f), 1.0f);
        R2.circle(ctx, x + 9.0f, y + h * 0.5f, 2.2f, R2.c(-12877066, a));
        R2.text(ctx, text, x + 15.0f, y + 5.5f, R2.c(-1446410, a));
    }

    private void toast(String message) {
        this.toastText = message;
        this.toastLife = 2.4f;
        this.toastAnim.snap(0.0f);
        this.toastAnim.set(1.0f);
    }

    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int button = click.button();
        this.layout();
        if (R2.hover(mx, my, this.searchX, this.searchY, this.searchW, this.searchH)) {
            this.searchFocused = true;
            if (button == 1) {
                this.query = "";
            }
            return true;
        }
        this.searchFocused = false;
        if (R2.hover(mx, my, this.boostX, this.btnY, this.boostW, this.btnH)) {
            ru.duo.aura.core.Module opt = ru.duo.aura.core.ModuleManager.optimizer;
            if (opt != null) {
                opt.toggle();
                this.toast(opt.isEnabled() ? Lang.boostOn() : Lang.boostOff());
            }
            return true;
        }
        if (R2.hover(mx, my, this.importX, this.btnY, this.importW, this.btnH)) {
            this.doImport();
            return true;
        }
        if (R2.hover(mx, my, this.exportX, this.btnY, this.exportW, this.btnH)) {
            this.doExport();
            return true;
        }
        if (R2.hover(mx, my, this.langX, this.btnY, this.langW, this.btnH)) {
            boolean en = mx < (double)(this.langX + this.langW * 0.5f);
            Lang.current = en ? Lang.L.EN : Lang.L.RU;
            this.langSlide.set(en ? 0.0f : 1.0f);
            ConfigManager.save();
            return true;
        }
        if (my < (double)(this.contentTop - 6.0f) || my > (double)(this.contentBottom + 4.0f)) {
            return true;
        }
        for (CardRect card : this.cards) {
            if (mx < (double)card.x || mx > (double)(card.x + card.w)) continue;
            Module m = card.module;
            if (my >= (double)card.y && my <= (double)(card.y + 22.0f)) {
                boolean onChevron;
                float toggleX = card.x + card.w - 8.0f - 20.0f;
                boolean bl = onChevron = m.hasSettings() && mx >= (double)(toggleX - 16.0f) && mx < (double)(toggleX - 3.0f);
                if (button == 1 || onChevron) {
                    m.setExpanded(!m.expanded);
                } else if (button == 0) {
                    m.toggleEnabled();
                }
                return true;
            }
            if (!m.expanded || !(my > (double)(card.y + 22.0f)) || !(my <= (double)(card.y + card.h))) continue;
            this.handleSettingClick(card, mx, my, button);
            return true;
        }
        return true;
    }

    private void handleSettingClick(CardRect card, double mx, double my, int button) {
        Module m = card.module;
        float x = card.x;
        float w = card.w;
        float sy = card.y + 22.0f + 4.0f;
        for (Setting s : m.settings) {
            float h = s.height();
            if (my >= (double)(sy - 2.0f) && my <= (double)(sy + h + 2.0f)) {
                if (s instanceof ModeSetting) {
                    ModeSetting mode = (ModeSetting)s;
                    float bx = x + 7.0f;
                    float bw = w - 14.0f;
                    mode.select(button == 1 ? mode.index - 1 : mode.index + 1);
                } else if (s instanceof NumberSetting) {
                    NumberSetting number = (NumberSetting)s;
                    float tx = x + 7.0f;
                    float tw = w - 14.0f;
                    this.dragging = number;
                    this.dragTrackX = tx;
                    this.dragTrackW = tw;
                    number.setProgress((mx - (double)tx) / (double)tw);
                } else if (s instanceof ru.specclient.module.setting.KeySetting ks) {
                    this.capturingKey = ks;
                    ks.capturing = true;
                } else if (s instanceof BoolSetting) {
                    BoolSetting bool = (BoolSetting)s;
                    bool.toggle();
                }
                return;
            }
            sy += h + 6.0f;
        }
    }

    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (this.dragging != null) {
            this.dragging.setProgress(((float)this.mouseX - this.dragTrackX) / this.dragTrackW);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    public boolean mouseReleased(Click click) {
        if (this.dragging != null) {
            this.dragging = null;
            return true;
        }
        return super.mouseReleased(click);
    }

    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int col;
        this.layout();
        if (my >= (double)(this.contentTop - 14.0f) && my <= (double)(this.contentBottom + 8.0f) && (col = (int)Math.floor((mx - (double)this.panelX - 22.0) / (double)this.colPitch)) >= 0 && col < this.scrollTarget.length) {
            this.scrollTarget[col] = MathHelper.clamp((float)(this.scrollTarget[col] - (float)vertical * 18.0f), (float)0.0f, (float)this.maxScroll(col));
            return true;
        }
        return true;
    }

    public boolean keyPressed(KeyInput input) {
        if (this.capturingKey != null) {
            int k = input.key();
            if (k != 256) {
                this.capturingKey.src.value = k;
                this.toast("Key: " + ru.duo.aura.core.Setting.Key.keyName(k));
            }
            this.capturingKey.capturing = false;
            this.capturingKey = null;
            return true;
        }
        int key = input.key();
        if (key == 344 || key == 256) {
            this.close();
            return true;
        }
        if (this.searchFocused) {
            if (key == 259) {
                if (!this.query.isEmpty()) {
                    this.query = this.query.substring(0, this.query.length() - 1);
                }
                return true;
            }
            if (key == 257 || key == 335) {
                this.searchFocused = false;
                return true;
            }
            if (key == 86 && (input.modifiers() & 2) != 0 && this.client != null) {
                this.query = this.query + this.client.keyboard.getClipboard();
                return true;
            }
        }
        return super.keyPressed(input);
    }

    public boolean charTyped(CharInput input) {
        if (this.searchFocused && input.isValidChar()) {
            this.query = this.query + input.asString();
            return true;
        }
        return super.charTyped(input);
    }

    private void doExport() {
        if (this.client == null) {
            return;
        }
        this.client.keyboard.setClipboard(ConfigManager.toJson());
        ConfigManager.save();
        this.toast(Lang.copied());
    }

    private void doImport() {
        if (this.client == null) {
            return;
        }
        String clipboard = this.client.keyboard.getClipboard();
        if (ConfigManager.fromJson(clipboard)) {
            this.langSlide.set(Lang.current == Lang.L.EN ? 0.0f : 1.0f);
            ConfigManager.save();
            this.toast(Lang.imported());
        } else {
            this.toast(Lang.importFailed());
        }
    }

    private static final class CardRect {
        Module module;
        int col;
        float x;
        float y;
        float w;
        float h;

        CardRect(Module module, int col, float x, float y, float w, float h) {
            this.module = module;
            this.col = col;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }
}
