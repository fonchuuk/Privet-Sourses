/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.RenderPipelines
 *  net.minecraft.Text
 *  net.minecraft.Identifier
 *  net.minecraft.MinecraftClient
 *  net.minecraft.DrawContext
 *  net.minecraft.StyledText
 *  org.joml.Matrix3x2fStack
 */
package ru.specclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;


import org.joml.Matrix3x2fStack;
import ru.specclient.gui.Anim;

public final class R2 {
    public static final Identifier BLOB = Identifier.of((String)"specclient", (String)"textures/gui/blob.png");
    public static float globalAlpha = 1.0f;

    private R2() {
    }

    public static int alpha(int color, float mul) {
        int a = (int)((float)(color >>> 24 & 0xFF) * Anim.clamp01(mul) + 0.5f);
        return a << 24 | color & 0xFFFFFF;
    }

    public static int c(int color) {
        return globalAlpha >= 0.999f ? color : R2.alpha(color, globalAlpha);
    }

    public static int c(int color, float mul) {
        return R2.alpha(color, mul * globalAlpha);
    }

    public static int mix(int a, int b, float t) {
        t = Anim.clamp01(t);
        int aa = (int)Anim.lerp(a >>> 24 & 0xFF, b >>> 24 & 0xFF, t);
        int ar = (int)Anim.lerp(a >> 16 & 0xFF, b >> 16 & 0xFF, t);
        int ag = (int)Anim.lerp(a >> 8 & 0xFF, b >> 8 & 0xFF, t);
        int ab = (int)Anim.lerp(a & 0xFF, b & 0xFF, t);
        return aa << 24 | ar << 16 | ag << 8 | ab;
    }

    private static void span(DrawContext ctx, float x0, float x1, int y, int h, int color) {
        if (x1 <= x0 || h <= 0 || color >>> 24 == 0) {
            return;
        }
        int a0 = (int)Math.ceil(x0);
        int a1 = (int)Math.floor(x1);
        if (a1 <= a0) {
            int px = (int)Math.floor((x0 + x1) * 0.5f);
            ctx.fill(px, y, px + 1, y + h, R2.alpha(color, x1 - x0));
            return;
        }
        float lf = (float)a0 - x0;
        float rf = x1 - (float)a1;
        if (lf > 0.004f) {
            ctx.fill(a0 - 1, y, a0, y + h, R2.alpha(color, lf));
        }
        ctx.fill(a0, y, a1, y + h, color);
        if (rf > 0.004f) {
            ctx.fill(a1, y, a1 + 1, y + h, R2.alpha(color, rf));
        }
    }

    public static void rect(DrawContext ctx, float x0, float y0, float x1, float y1, int color) {
        if (x1 <= x0 || y1 <= y0 || color >>> 24 == 0) {
            return;
        }
        int b0 = (int)Math.ceil(y0);
        int b1 = (int)Math.floor(y1);
        if (b1 <= b0) {
            int py = (int)Math.floor((y0 + y1) * 0.5f);
            R2.span(ctx, x0, x1, py, 1, R2.alpha(color, y1 - y0));
            return;
        }
        float tf = (float)b0 - y0;
        float bf = y1 - (float)b1;
        if (tf > 0.004f) {
            R2.span(ctx, x0, x1, b0 - 1, 1, R2.alpha(color, tf));
        }
        R2.span(ctx, x0, x1, b0, b1 - b0, color);
        if (bf > 0.004f) {
            R2.span(ctx, x0, x1, b1, 1, R2.alpha(color, bf));
        }
    }

    public static void rectWH(DrawContext ctx, float x, float y, float w, float h, int color) {
        R2.rect(ctx, x, y, x + w, y + h, color);
    }

    public static void round(DrawContext ctx, float x, float y, float w, float h, float r, int color) {
        if (w <= 0.0f || h <= 0.0f || color >>> 24 == 0) {
            return;
        }
        if ((r = Math.max(0.0f, Math.min(r, Math.min(w, h) * 0.5f))) < 0.35f) {
            R2.rectWH(ctx, x, y, w, h, color);
            return;
        }
        float top = y;
        float bottom = y + h;
        float cxl = x + r;
        float cxr = x + w - r;
        R2.corners(ctx, top, top + r, top + r, cxl, cxr, r, color, true);
        R2.rect(ctx, x, top + r, x + w, bottom - r, color);
        R2.corners(ctx, bottom - r, bottom, bottom - r, cxl, cxr, r, color, false);
    }

    private static void corners(DrawContext ctx, float from, float to, float cy, float cxl, float cxr, float r, int color, boolean top) {
        int y0 = (int)Math.floor(from);
        int y1 = (int)Math.ceil(to);
        int step = Math.max(2, Math.round(r / 5.0f));
        for (int py = y0; py < y1; py += step) {
            float rowTop = Math.max((float)py, from);
            float rowBot = Math.min((float)(py + step), to);
            if (rowBot - rowTop <= 0.004f) continue;
            float mid = (rowTop + rowBot) * 0.5f;
            float dy = top ? cy - mid : mid - cy;
            float inner = r * r - dy * dy;
            float dx = r - (float)Math.sqrt(Math.max(0.0f, inner));
            R2.rect(ctx, cxl - r + dx, rowTop, cxr + r - dx, rowBot, color);
        }
    }

    public static void panel(DrawContext ctx, float x, float y, float w, float h, float r, int fill, int border, float thickness) {
        if (border >>> 24 != 0) {
            R2.round(ctx, x, y, w, h, r, border);
            R2.round(ctx, x + thickness, y + thickness, w - 2.0f * thickness, h - 2.0f * thickness, Math.max(0.0f, r - thickness), fill);
        } else {
            R2.round(ctx, x, y, w, h, r, fill);
        }
    }

    public static void circle(DrawContext ctx, float cx, float cy, float r, int color) {
        R2.round(ctx, cx - r, cy - r, r * 2.0f, r * 2.0f, r, color);
    }

    public static void ring(DrawContext ctx, float cx, float cy, float r, float thickness, int color, int inside) {
        R2.circle(ctx, cx, cy, r, color);
        R2.circle(ctx, cx, cy, Math.max(0.0f, r - thickness), inside);
    }

    public static void rotRect(DrawContext ctx, float cx, float cy, float w, float h, float angleRad, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        m.rotate(angleRad);
        R2.rect(ctx, -w * 0.5f, -h * 0.5f, w * 0.5f, h * 0.5f, color);
        m.popMatrix();
    }

    public static void glow(DrawContext ctx, float cx, float cy, float radius, int color) {
        int d = Math.max(2, Math.round(radius * 2.0f));
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BLOB, Math.round(cx - radius), Math.round(cy - radius), 0.0f, 0.0f, d, d, d, d, color);
    }

    public static void softGlow(DrawContext ctx, float cx, float cy, float radius, int color) {
        if (radius <= 1.0f || color >>> 24 == 0) return;
        R2.circle(ctx, cx, cy, radius, R2.alpha(color, 0.22f));
        R2.circle(ctx, cx, cy, radius * 0.62f, R2.alpha(color, 0.28f));
        R2.circle(ctx, cx, cy, radius * 0.34f, R2.alpha(color, 0.34f));
    }

    public static void shadow(DrawContext ctx, float x, float y, float w, float h, float spread, int color) {
        int steps = 1;
        for (int i = steps; i >= 1; --i) {
            float g = spread * (float)i / (float)steps;
            float a = (1.0f - (float)i / ((float)steps + 1.0f)) * 0.5f;
            R2.round(ctx, x - g, y - g + 1.5f, w + g * 2.0f, h + g * 2.0f, 10.0f + g, R2.alpha(color, a));
        }
    }

    public static void text(DrawContext ctx, Text txt, float x, float y, int color) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(Math.round(x), Math.round(y));
        ctx.drawText(MinecraftClient.getInstance().textRenderer, txt, 0, 0, color, false);
        m.popMatrix();
    }

    public static void textCentered(DrawContext ctx, Text txt, float cx, float y, int color) {
        R2.text(ctx, txt, cx - (float)R2.width(txt) * 0.5f, y, color);
    }

    public static void textRight(DrawContext ctx, Text txt, float right, float y, int color) {
        R2.text(ctx, txt, right - (float)R2.width(txt), y, color);
    }

    private static final java.util.Map<Text, Integer> WIDTHS = new java.util.HashMap<>();

    public static int width(Text txt) {
        Integer w = WIDTHS.get(txt);
        if (w != null) return w;
        if (WIDTHS.size() > 768) WIDTHS.clear();
        w = MinecraftClient.getInstance().textRenderer.getWidth(txt);
        WIDTHS.put(txt, w);
        return w;
    }

    public static boolean hover(double mx, double my, float x, float y, float w, float h) {
        return mx >= (double)x && mx < (double)(x + w) && my >= (double)y && my < (double)(y + h);
    }
}
