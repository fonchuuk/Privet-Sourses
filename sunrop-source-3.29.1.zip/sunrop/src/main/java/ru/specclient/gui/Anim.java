/*
 * Decompiled with CFR 0.152.
 */
package ru.specclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;


public final class Anim {
    private float value;
    private float target;
    private final float speed;

    public Anim(float value) {
        this(value, 14.0f);
    }

    public Anim(float value, float speed) {
        this.value = value;
        this.target = value;
        this.speed = speed;
    }

    public void set(float target) {
        this.target = target;
    }

    public void snap(float v) {
        this.value = v;
        this.target = v;
    }

    public float get() {
        return this.value;
    }

    public float getTarget() {
        return this.target;
    }

    public boolean isIdle() {
        return Math.abs(this.target - this.value) < 8.0E-4f;
    }

    public void update(float dt) {
        if (dt <= 0.0f) {
            return;
        }
        float f = 1.0f - (float)Math.exp(-this.speed * Math.min(dt, 0.2f));
        this.value += (this.target - this.value) * f;
        if (Math.abs(this.target - this.value) < 8.0E-4f) {
            this.value = this.target;
        }
    }

    public static float easeOutCubic(float t) {
        float u = 1.0f - Anim.clamp01(t);
        return 1.0f - u * u * u;
    }

    public static float easeOutQuint(float t) {
        float u = 1.0f - Anim.clamp01(t);
        return 1.0f - u * u * u * u * u;
    }

    public static float easeInOutCubic(float t) {
        return (t = Anim.clamp01(t)) < 0.5f ? 4.0f * t * t * t : 1.0f - (float)Math.pow(-2.0f * t + 2.0f, 3.0) / 2.0f;
    }

    public static float easeOutBack(float t) {
        t = Anim.clamp01(t);
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        float u = t - 1.0f;
        return 1.0f + c3 * u * u * u + c1 * u * u;
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float clamp01(float v) {
        return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
    }
}
