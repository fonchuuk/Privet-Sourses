/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.StyleSpriteSource
 *  net.minecraft.StyleSpriteSource$class_11721
 *  net.minecraft.Text
 *  net.minecraft.Style
 *  net.minecraft.Identifier
 */
package ru.specclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;



public final class Fonts {
    public static final Identifier UI = Identifier.of((String)"specclient", (String)"ui");
    public static final Identifier UI_BOLD = Identifier.of((String)"specclient", (String)"ui_bold");
    public static final Identifier UI_TINY = Identifier.of((String)"specclient", (String)"ui_tiny");
    public static final Identifier UI_TITLE = Identifier.of((String)"specclient", (String)"ui_title");
    private static final Style S_UI = Style.EMPTY.withFont((StyleSpriteSource)new StyleSpriteSource.Font(UI));
    private static final Style S_BOLD = Style.EMPTY.withFont((StyleSpriteSource)new StyleSpriteSource.Font(UI_BOLD));
    private static final Style S_TINY = Style.EMPTY.withFont((StyleSpriteSource)new StyleSpriteSource.Font(UI_TINY));
    private static final Style S_TITLE = Style.EMPTY.withFont((StyleSpriteSource)new StyleSpriteSource.Font(UI_TITLE));

    private static final java.util.Map<String, Text> C_UI = new java.util.HashMap<>();
    private static final java.util.Map<String, Text> C_BOLD = new java.util.HashMap<>();
    private static final java.util.Map<String, Text> C_TINY = new java.util.HashMap<>();
    private static final java.util.Map<String, Text> C_TITLE = new java.util.HashMap<>();

    private Fonts() {
    }

    private static Text get(java.util.Map<String, Text> map, String s, Style style) {
        Text t = map.get(s);
        if (t == null) {
            if (map.size() > 512) map.clear();
            t = Text.literal((String)s).setStyle(style);
            map.put(s, t);
        }
        return t;
    }

    public static Text ui(String s) {
        return get(C_UI, s, S_UI);
    }

    public static Text bold(String s) {
        return get(C_BOLD, s, S_BOLD);
    }

    public static Text tiny(String s) {
        return get(C_TINY, s, S_TINY);
    }

    public static Text title(String s) {
        return get(C_TITLE, s, S_TITLE);
    }
}
