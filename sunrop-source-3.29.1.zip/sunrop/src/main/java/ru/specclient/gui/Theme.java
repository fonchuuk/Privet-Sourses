/*
 * Decompiled with CFR 0.152.
 */
package ru.specclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;


public final class Theme {
    public static final int PANEL_BG = -603452655;
    public static final int PANEL_BG_TOP = -1978920679;
    public static final int PANEL_BORDER = -15064784;
    public static final int PANEL_INNER_LINE = 0x14FFFFFF;
    public static final int CARD_BG = -15986666;
    public static final int CARD_BG_HOVER = -15591131;
    public static final int CARD_BORDER = -15262423;
    public static final int CARD_ON_BG = -15656147;
    public static final int CARD_ON_BG_HOVER = -15326405;
    public static final int CARD_ON_BORDER = -14204049;
    public static final int TEXT = -1446410;
    public static final int TEXT_DIM = -6774349;
    public static final int TEXT_LABEL = -8156003;
    public static final int TEXT_MUTED = -11774619;
    public static final int ACCENT = -12877066;
    public static final int ACCENT_DEEP = -14326805;
    public static final int ACCENT_LIGHT = -8540417;
    public static final int ACCENT_GLOW = 1429963510;
    public static final int TOGGLE_OFF = -13946307;
    public static final int TOGGLE_OFF_HOVER = -13024945;
    public static final int KNOB = -722948;
    public static final int KNOB_OFF = -3945770;
    public static final int SEG_BG = -16184044;
    public static final int SEG_BORDER = -14998992;
    public static final int TRACK = -14538185;
    public static final int SEPARATOR = -15328217;
    public static final int FIELD_BG = -16184045;
    public static final int FIELD_BORDER = -15065044;
    public static final int FIELD_BORDER_FOCUS = -13672530;
    public static final int BTN_BG = -15722975;
    public static final int BTN_BG_HOVER = -15130321;
    public static final int BTN_BORDER = -14472390;

    private Theme() {
    }
}
