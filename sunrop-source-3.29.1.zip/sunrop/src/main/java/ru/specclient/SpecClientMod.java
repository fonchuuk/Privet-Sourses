package ru.specclient;

public final class SpecClientMod {
    public static final Logger LOGGER = new Logger();
    public static final class Logger {
        public void error(String msg, Throwable t) {
            System.err.println(msg);
            if (t != null) t.printStackTrace();
        }
    }
}
