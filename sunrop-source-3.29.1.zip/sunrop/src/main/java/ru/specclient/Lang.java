package ru.specclient;

public final class Lang {
    public enum L { EN, RU }
    public static L current = L.EN;
    public static String pick(String en, String ruTxt) { return ru.duo.aura.core.Lang.russian ? ruTxt : en; }
    public static String importBtn() { return pick("Import", "Импорт"); }
    public static String boostBtn() { return pick("Boost", "Буст"); }
    public static String boostOn() { return pick("Game optimized", "Игра ускорена"); }
    public static String boostOff() { return pick("Settings restored", "Настройки восстановлены"); }
    public static String exportBtn() { return pick("Export", "Экспорт"); }
    public static String nothingFound() { return pick("Nothing found", "Ничего не найдено"); }
    public static String search() { return pick("Search modules...", "Поиск модулей..."); }
    public static String copied() { return pick("Config copied", "Конфиг скопирован"); }
    public static String imported() { return pick("Imported", "Импортирован"); }
    public static String importFailed() { return pick("Import failed", "Ошибка импорта"); }
}
